export type SensorId = 
  | 'ad8232_ecg' 
  | 'max30102_ppg' 
  | 'mlx90614_temp' 
  | 'resp_calc' 
  | 'glucose_module';

export type SensorStatus = 
  | 'DISCONNECTED' 
  | 'CONNECTING' 
  | 'CONNECTED' 
  | 'MEASURING' 
  | 'DATA SENT';

export interface SensorInfo {
  id: SensorId;
  name: string;
  hardwareModel: string;
  busType: 'ADC (Analog)' | 'I2C (0x57)' | 'I2C (0x5A)' | 'Firmware Algorithm' | 'Electrochemical ADC';
  parameters: string[];
  status: SensorStatus;
  isSimulatedOnly?: boolean;
}

export interface PatientVitals {
  heartRate: number; // BPM
  spo2: number; // %
  temperature: number; // °C
  respiratoryRate: number; // breaths/min
  bloodGlucose: number; // mg/dL
  timestamp: string;
}

export interface BlePacket {
  id: string;
  timestamp: string;
  serviceUuid: string;
  characteristicUuid: string;
  rawHex: string;
  decoded: {
    hr: number;
    spo2: number;
    temp: number;
    resp: number;
    glucose: number;
  };
}

export type Esp32Status = 'OFFLINE' | 'INITIALIZING' | 'ONLINE';
export type BleStatus = 'DISCONNECTED' | 'ADVERTISING' | 'CONNECTING' | 'CONNECTED';
export type DataTransferMode = 'IDLE' | 'BUFFERING' | 'TRANSMITTING' | 'LIVE';

export interface MeasurementStep {
  step: number;
  label: string;
  description: string;
  activeSensorId?: SensorId;
}
