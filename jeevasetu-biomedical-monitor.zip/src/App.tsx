import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Activity, 
  Cpu, 
  Radio, 
  Smartphone, 
  ShieldAlert, 
  CheckCircle, 
  Sparkles, 
  Layers, 
  ArrowRight,
  Info,
  Sliders,
  Terminal,
  Heart
} from 'lucide-react';
import { 
  SensorId, 
  SensorStatus, 
  PatientVitals, 
  Esp32Status, 
  BleStatus, 
  DataTransferMode 
} from './types';
import { HardwareDiagram } from './components/HardwareDiagram';
import { BleTransmissionBridge } from './components/BleTransmissionBridge';
import { JeevaSetuMobileApp } from './components/JeevaSetuMobileApp';
import { SimulationControls } from './components/SimulationControls';
import { MeasurementStepIndicator, MEASUREMENT_STEPS } from './components/MeasurementStepIndicator';

const INITIAL_SENSOR_STATUSES: Record<SensorId, SensorStatus> = {
  ad8232_ecg: 'CONNECTED',
  max30102_ppg: 'CONNECTED',
  mlx90614_temp: 'CONNECTED',
  resp_calc: 'CONNECTED',
  glucose_module: 'CONNECTED',
};

export default function App() {
  // Physiological Parameter States (Simulated Hardware Output)
  const [heartRate, setHeartRate] = useState<number>(74);
  const [spo2, setSpo2] = useState<number>(98);
  const [temperature, setTemperature] = useState<number>(36.8);
  const [respiratoryRate, setRespiratoryRate] = useState<number>(16);
  const [bloodGlucose, setBloodGlucose] = useState<number>(95);

  // Hardware & Communication States
  const [sensorStatuses, setSensorStatuses] = useState<Record<SensorId, SensorStatus>>(INITIAL_SENSOR_STATUSES);
  const [esp32Status, setEsp32Status] = useState<Esp32Status>('ONLINE');
  const [bleStatus, setBleStatus] = useState<BleStatus>('CONNECTED');
  const [batteryLevel] = useState<number>(87);
  const [dataTransferState, setDataTransferState] = useState<DataTransferMode>('LIVE');
  
  // Measurement Process State
  const [isMeasuring, setIsMeasuring] = useState<boolean>(false);
  const [currentStep, setCurrentStep] = useState<number>(10);
  const [progressPercent, setProgressPercent] = useState<number>(100);
  const [activeSensorHighlight, setActiveSensorHighlight] = useState<SensorId | undefined>(undefined);

  // Mobile App Received Vitals Record
  const [receivedVitals, setReceivedVitals] = useState<PatientVitals | null>({
    heartRate: 74,
    spo2: 98,
    temperature: 36.8,
    respiratoryRate: 16,
    bloodGlucose: 95,
    timestamp: 'Just now (Live)',
  });

  const stepTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Subtle physiological variance micro-generator to make live streaming authentic
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isMeasuring) {
        // Minor natural baseline noise (±0.3 BPM, ±0.1°C)
        setHeartRate((prev) => {
          const delta = (Math.random() - 0.5) * 0.4;
          return Math.max(40, Math.min(180, Number((prev + delta).toFixed(1))));
        });
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [isMeasuring]);

  // Synchronize app display when sliders are adjusted in live mode
  useEffect(() => {
    if (dataTransferState === 'LIVE' || !isMeasuring) {
      setReceivedVitals((prev) => prev ? ({
        ...prev,
        heartRate: Math.round(heartRate),
        spo2: Math.round(spo2),
        temperature: Number(temperature.toFixed(1)),
        respiratoryRate: Math.round(respiratoryRate),
        bloodGlucose: Math.round(bloodGlucose),
      }) : null);
    }
  }, [heartRate, spo2, temperature, respiratoryRate, bloodGlucose, dataTransferState, isMeasuring]);

  // Start 10-Stage Measurement Execution Sequence
  const handleStartMeasurement = useCallback(() => {
    if (isMeasuring) return;
    setIsMeasuring(true);
    setCurrentStep(1);
    setProgressPercent(10);
    setDataTransferState('BUFFERING');

    // 1. Reset all sensors to CONNECTING/MEASURING
    setSensorStatuses({
      ad8232_ecg: 'CONNECTING',
      max30102_ppg: 'CONNECTING',
      mlx90614_temp: 'CONNECTING',
      resp_calc: 'CONNECTING',
      glucose_module: 'CONNECTING',
    });

    // Slight dynamic randomization for fresh measurement
    const newHr = Math.round(68 + Math.random() * 18);
    const newSpo2 = Math.round(96 + Math.random() * 3);
    const newTemp = Number((36.4 + Math.random() * 0.8).toFixed(1));
    const newResp = Math.round(14 + Math.random() * 5);
    const newGlucose = Math.round(82 + Math.random() * 35);

    setHeartRate(newHr);
    setSpo2(newSpo2);
    setTemperature(newTemp);
    setRespiratoryRate(newResp);
    setBloodGlucose(newGlucose);

    // Sequence stages with realistic timing
    const stepDelays = [
      { step: 1, duration: 700, action: () => {
        setActiveSensorHighlight(undefined);
      }},
      { step: 2, duration: 800, action: () => {
        setSensorStatuses({
          ad8232_ecg: 'CONNECTED',
          max30102_ppg: 'CONNECTED',
          mlx90614_temp: 'CONNECTED',
          resp_calc: 'CONNECTED',
          glucose_module: 'CONNECTED',
        });
      }},
      { step: 3, duration: 900, action: () => {
        setActiveSensorHighlight('ad8232_ecg');
        setSensorStatuses(prev => ({ ...prev, ad8232_ecg: 'MEASURING' }));
      }},
      { step: 4, duration: 900, action: () => {
        setActiveSensorHighlight('max30102_ppg');
        setSensorStatuses(prev => ({ ...prev, max30102_ppg: 'MEASURING' }));
      }},
      { step: 5, duration: 800, action: () => {
        setActiveSensorHighlight('mlx90614_temp');
        setSensorStatuses(prev => ({ ...prev, mlx90614_temp: 'MEASURING' }));
      }},
      { step: 6, duration: 800, action: () => {
        setActiveSensorHighlight('resp_calc');
        setSensorStatuses(prev => ({ ...prev, resp_calc: 'MEASURING' }));
      }},
      { step: 7, duration: 800, action: () => {
        setActiveSensorHighlight('glucose_module');
        setSensorStatuses(prev => ({ ...prev, glucose_module: 'MEASURING' }));
      }},
      { step: 8, duration: 800, action: () => {
        setActiveSensorHighlight(undefined);
        setSensorStatuses({
          ad8232_ecg: 'DATA SENT',
          max30102_ppg: 'DATA SENT',
          mlx90614_temp: 'DATA SENT',
          resp_calc: 'DATA SENT',
          glucose_module: 'DATA SENT',
        });
        setDataTransferState('TRANSMITTING');
      }},
      { step: 9, duration: 900, action: () => {
        setDataTransferState('TRANSMITTING');
      }},
      { step: 10, duration: 800, action: () => {
        setDataTransferState('LIVE');
        const now = new Date();
        const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
        
        setReceivedVitals({
          heartRate: newHr,
          spo2: newSpo2,
          temperature: newTemp,
          respiratoryRate: newResp,
          bloodGlucose: newGlucose,
          timestamp: `Acquired at ${timeStr}`,
        });
        
        setIsMeasuring(false);
      }},
    ];

    let currentDelay = 0;
    stepDelays.forEach(({ step, duration, action }) => {
      currentDelay += duration;
      setTimeout(() => {
        setCurrentStep(step);
        setProgressPercent(step * 10);
        action();
      }, currentDelay);
    });
  }, [isMeasuring]);

  const handleStopMeasurement = () => {
    if (stepTimerRef.current) clearTimeout(stepTimerRef.current);
    setIsMeasuring(false);
    setDataTransferState('LIVE');
    setSensorStatuses(INITIAL_SENSOR_STATUSES);
    setActiveSensorHighlight(undefined);
  };

  const handleReset = () => {
    handleStopMeasurement();
    setHeartRate(74);
    setSpo2(98);
    setTemperature(36.8);
    setRespiratoryRate(16);
    setBloodGlucose(95);
    setCurrentStep(10);
    setProgressPercent(100);
    setReceivedVitals({
      heartRate: 74,
      spo2: 98,
      temperature: 36.8,
      respiratoryRate: 16,
      bloodGlucose: 95,
      timestamp: 'Reset default',
    });
  };

  const handleSetHealthyPreset = () => {
    const hr = Math.round(65 + Math.random() * 20);
    const sp = Math.round(97 + Math.random() * 2);
    const temp = Number((36.5 + Math.random() * 0.6).toFixed(1));
    const resp = Math.round(14 + Math.random() * 4);
    const glu = Math.round(80 + Math.random() * 30);

    setHeartRate(hr);
    setSpo2(sp);
    setTemperature(temp);
    setRespiratoryRate(resp);
    setBloodGlucose(glu);
  };

  const handleSetAbnormalPreset = () => {
    // Select one of realistic abnormal clinical profiles
    const profiles = [
      { hr: 125, sp: 91, temp: 38.9, resp: 26, glu: 175 }, // Fever / Sepsis survey flag
      { hr: 48, sp: 94, temp: 35.8, resp: 10, glu: 62 },  // Bradycardia / Hypothermia
      { hr: 140, sp: 88, temp: 37.1, resp: 28, glu: 240 }, // Acute Hypoxia / Tachycardia / Hyperglycemia
    ];
    const picked = profiles[Math.floor(Math.random() * profiles.length)];
    setHeartRate(picked.hr);
    setSpo2(picked.sp);
    setTemperature(picked.temp);
    setRespiratoryRate(picked.resp);
    setBloodGlucose(picked.glu);
  };

  return (
    <div className="min-h-screen bg-[#070d14] text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      
      {/* Top Main Navigation Bar */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-8 py-3">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-emerald-500/20">
              <Activity className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black tracking-tight text-white font-mono">
                  JeevaSetu Simulator
                </h1>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                  HARDWARE ↔ BLE ↔ MOBILE APP
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Portable multi-parameter biomedical survey prototype & mobile sync engine
              </p>
            </div>
          </div>

          {/* Core Concept Pipeline Breadcrumb */}
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 text-[11px] font-mono text-slate-300">
            <span className="text-emerald-400 font-semibold">PATIENT</span>
            <ArrowRight className="w-3 h-3 text-slate-500" />
            <span className="text-cyan-400">SENSORS</span>
            <ArrowRight className="w-3 h-3 text-slate-500" />
            <span className="text-amber-400">ESP32</span>
            <ArrowRight className="w-3 h-3 text-slate-500" />
            <span className="text-sky-400">BLE</span>
            <ArrowRight className="w-3 h-3 text-slate-500" />
            <span className="text-emerald-300 font-semibold">JEEVASETU APP</span>
          </div>
        </div>
      </header>

      {/* Main Content Workspace */}
      <main className="max-w-7xl mx-auto w-full p-4 lg:p-6 flex-1 flex flex-col gap-5">
        
        {/* Step Progression Bar */}
        <MeasurementStepIndicator
          currentStep={currentStep}
          isMeasuring={isMeasuring}
          progressPercent={progressPercent}
        />

        {/* Core Split Demonstration: Hardware on Left, Wireless Bridge in Center, Mobile App on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          
          {/* Left Side: Virtual Hardware & ESP32 (7 Cols on desktop) */}
          <div className="lg:col-span-7 flex flex-col">
            <HardwareDiagram
              sensorStatuses={sensorStatuses}
              esp32Status={esp32Status}
              bleStatus={bleStatus}
              batteryLevel={batteryLevel}
              isMeasuring={isMeasuring}
              heartRate={heartRate}
              spo2={spo2}
              temperature={temperature}
              respiratoryRate={respiratoryRate}
              bloodGlucose={bloodGlucose}
              activeSensorHighlight={activeSensorHighlight}
            />
          </div>

          {/* Right Side: JeevaSetu Mobile App (5 Cols on desktop) */}
          <div className="lg:col-span-5 flex flex-col justify-center items-center relative">
            
            {/* Center Wireless Bridge embedded seamlessly */}
            <div className="w-full mb-3">
              <BleTransmissionBridge
                bleStatus={bleStatus}
                dataTransferState={dataTransferState}
                isMeasuring={isMeasuring}
                heartRate={heartRate}
                spo2={spo2}
                temperature={temperature}
                respiratoryRate={respiratoryRate}
                bloodGlucose={bloodGlucose}
              />
            </div>

            {/* Mobile App Viewport */}
            <JeevaSetuMobileApp
              vitals={receivedVitals}
              liveHeartRate={heartRate}
              liveSpo2={spo2}
              liveTemperature={temperature}
              liveRespiratoryRate={respiratoryRate}
              liveBloodGlucose={bloodGlucose}
              isStreaming={isMeasuring || dataTransferState === 'LIVE'}
              bleStatus={bleStatus}
              dataTransferState={dataTransferState}
              signalQuality="GOOD"
            />
          </div>
        </div>

        {/* Interactive Simulation Controls & Parameter Test Bench */}
        <SimulationControls
          isMeasuring={isMeasuring}
          onStartMeasurement={handleStartMeasurement}
          onStopMeasurement={handleStopMeasurement}
          onReset={handleReset}
          onSetHealthyPreset={handleSetHealthyPreset}
          onSetAbnormalPreset={handleSetAbnormalPreset}
          heartRate={heartRate}
          setHeartRate={setHeartRate}
          spo2={spo2}
          setSpo2={setSpo2}
          temperature={temperature}
          setTemperature={setTemperature}
          respiratoryRate={respiratoryRate}
          setRespiratoryRate={setRespiratoryRate}
          bloodGlucose={bloodGlucose}
          setBloodGlucose={setBloodGlucose}
        />

        {/* Required Prototype & Medical Disclaimer */}
        <footer className="mt-2 p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
          <p className="font-medium text-slate-300">
            JeevaSetu is a student prototype simulation. Sensor values shown are simulated and are not intended for medical diagnosis.
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            Simulated Hardware: AD8232 ECG • MAX30102 Optical PPG/SpO2 • MLX90614 Non-Contact IR • Derived Respiratory Rate • ESP32 BLE 5.0 GATT Pipeline
          </p>
        </footer>
      </main>
    </div>
  );
}
