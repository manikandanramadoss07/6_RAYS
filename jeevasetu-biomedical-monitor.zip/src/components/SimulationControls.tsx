import React from 'react';
import { 
  Play, 
  Square, 
  RotateCcw, 
  Sparkles, 
  AlertOctagon, 
  Sliders, 
  Activity, 
  Heart, 
  Thermometer, 
  Wind, 
  Droplet 
} from 'lucide-react';

interface SimulationControlsProps {
  isMeasuring: boolean;
  onStartMeasurement: () => void;
  onStopMeasurement: () => void;
  onReset: () => void;
  onSetHealthyPreset: () => void;
  onSetAbnormalPreset: () => void;
  heartRate: number;
  setHeartRate: (val: number) => void;
  spo2: number;
  setSpo2: (val: number) => void;
  temperature: number;
  setTemperature: (val: number) => void;
  respiratoryRate: number;
  setRespiratoryRate: (val: number) => void;
  bloodGlucose: number;
  setBloodGlucose: (val: number) => void;
}

export const SimulationControls: React.FC<SimulationControlsProps> = ({
  isMeasuring,
  onStartMeasurement,
  onStopMeasurement,
  onReset,
  onSetHealthyPreset,
  onSetAbnormalPreset,
  heartRate,
  setHeartRate,
  spo2,
  setSpo2,
  temperature,
  setTemperature,
  respiratoryRate,
  setRespiratoryRate,
  bloodGlucose,
  setBloodGlucose,
}) => {
  return (
    <div id="simulation-controls-panel" className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 lg:p-5 shadow-xl backdrop-blur-md">
      
      {/* Top Header & Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold font-mono uppercase tracking-wider text-slate-100">
              Hardware Test Bench & Simulation Controls
            </h3>
            <p className="text-[11px] text-slate-400">
              Trigger acquisition sequence or manually inject physiological parameters
            </p>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {!isMeasuring ? (
            <button
              id="start-measurement-btn"
              onClick={onStartMeasurement}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs tracking-wide shadow-lg shadow-emerald-950/50 transition-all active:scale-95 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>START MEASUREMENT</span>
            </button>
          ) : (
            <button
              id="stop-measurement-btn"
              onClick={onStopMeasurement}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs tracking-wide shadow-lg shadow-rose-950/50 transition-all active:scale-95 cursor-pointer"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>STOP</span>
            </button>
          )}

          <button
            id="reset-btn"
            onClick={onReset}
            disabled={isMeasuring}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 font-semibold text-xs transition-all active:scale-95 cursor-pointer border border-slate-700"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>

          <button
            id="healthy-preset-btn"
            onClick={onSetHealthyPreset}
            disabled={isMeasuring}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-950/80 hover:bg-emerald-900/80 disabled:opacity-50 text-emerald-300 font-semibold text-xs border border-emerald-800 transition-all active:scale-95 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>RANDOM HEALTHY</span>
          </button>

          <button
            id="abnormal-preset-btn"
            onClick={onSetAbnormalPreset}
            disabled={isMeasuring}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-950/80 hover:bg-amber-900/80 disabled:opacity-50 text-amber-300 font-semibold text-xs border border-amber-800 transition-all active:scale-95 cursor-pointer"
          >
            <AlertOctagon className="w-3.5 h-3.5 text-amber-400" />
            <span>RANDOM ABNORMAL</span>
          </button>
        </div>
      </div>

      {/* Manual Slider Adjustments Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 pt-4">
        
        {/* Slider 1: Heart Rate */}
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono mb-1.5">
            <span className="flex items-center gap-1 text-slate-300 font-medium">
              <Heart className="w-3.5 h-3.5 text-rose-500" />
              Heart Rate:
            </span>
            <span className="text-rose-400 font-bold">{Math.round(heartRate)} BPM</span>
          </div>
          <input
            type="range"
            min={40}
            max={180}
            step={1}
            value={heartRate}
            onChange={(e) => setHeartRate(Number(e.target.value))}
            disabled={isMeasuring}
            className="w-full accent-rose-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none disabled:opacity-50"
          />
          <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
            <span>40</span>
            <span>Norm: 60-100</span>
            <span>180</span>
          </div>
        </div>

        {/* Slider 2: SpO2 */}
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono mb-1.5">
            <span className="flex items-center gap-1 text-slate-300 font-medium">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              SpO2 Level:
            </span>
            <span className="text-cyan-400 font-bold">{Math.round(spo2)} %</span>
          </div>
          <input
            type="range"
            min={70}
            max={100}
            step={1}
            value={spo2}
            onChange={(e) => setSpo2(Number(e.target.value))}
            disabled={isMeasuring}
            className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none disabled:opacity-50"
          />
          <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
            <span>70%</span>
            <span>Norm: 95-100%</span>
            <span>100%</span>
          </div>
        </div>

        {/* Slider 3: Temperature */}
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono mb-1.5">
            <span className="flex items-center gap-1 text-slate-300 font-medium">
              <Thermometer className="w-3.5 h-3.5 text-amber-400" />
              Body Temp:
            </span>
            <span className="text-amber-400 font-bold">{temperature.toFixed(1)} °C</span>
          </div>
          <input
            type="range"
            min={34.0}
            max={41.0}
            step={0.1}
            value={temperature}
            onChange={(e) => setTemperature(Number(e.target.value))}
            disabled={isMeasuring}
            className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none disabled:opacity-50"
          />
          <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
            <span>34.0°C</span>
            <span>Norm: 36.1-37.5</span>
            <span>41.0°C</span>
          </div>
        </div>

        {/* Slider 4: Respiratory Rate */}
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
          <div className="flex items-center justify-between text-xs font-mono mb-1.5">
            <span className="flex items-center gap-1 text-slate-300 font-medium">
              <Wind className="w-3.5 h-3.5 text-teal-400" />
              Resp Rate:
            </span>
            <span className="text-teal-400 font-bold">{Math.round(respiratoryRate)} br/min</span>
          </div>
          <input
            type="range"
            min={8}
            max={35}
            step={1}
            value={respiratoryRate}
            onChange={(e) => setRespiratoryRate(Number(e.target.value))}
            disabled={isMeasuring}
            className="w-full accent-teal-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none disabled:opacity-50"
          />
          <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
            <span>8</span>
            <span>Norm: 12-20</span>
            <span>35</span>
          </div>
        </div>

        {/* Slider 5: Blood Glucose */}
        <div className="p-3 rounded-xl bg-slate-950/60 border border-purple-500/30">
          <div className="flex items-center justify-between text-xs font-mono mb-1.5">
            <span className="flex items-center gap-1 text-slate-300 font-medium">
              <Droplet className="w-3.5 h-3.5 text-purple-400" />
              Glucose (Sim):
            </span>
            <span className="text-purple-400 font-bold">{Math.round(bloodGlucose)} mg/dL</span>
          </div>
          <input
            type="range"
            min={40}
            max={350}
            step={1}
            value={bloodGlucose}
            onChange={(e) => setBloodGlucose(Number(e.target.value))}
            disabled={isMeasuring}
            className="w-full accent-purple-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg appearance-none disabled:opacity-50"
          />
          <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1">
            <span>40</span>
            <span>Norm: 70-140</span>
            <span>350</span>
          </div>
        </div>
      </div>
    </div>
  );
};
