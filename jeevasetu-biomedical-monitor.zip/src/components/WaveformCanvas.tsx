import React, { useEffect, useRef } from 'react';
import { getEcgSample, getPpgSample } from '../utils/bioSignals';

interface WaveformCanvasProps {
  type: 'ecg' | 'ppg';
  heartRate: number;
  respiratoryRate: number;
  isActive: boolean;
  color?: string;
  gridColor?: string;
  height?: number;
  showLeadInfo?: boolean;
}

export const WaveformCanvas: React.FC<WaveformCanvasProps> = ({
  type,
  heartRate,
  respiratoryRate,
  isActive,
  color = type === 'ecg' ? '#10b981' : '#06b6d4',
  gridColor = 'rgba(16, 185, 129, 0.12)',
  height = 110,
  showLeadInfo = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const animationFrameId = useRef<number | null>(null);
  const timeOffsetRef = useRef<number>(0);
  const lastTimestampRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI
    const resize = () => {
      if (!containerRef.current || !canvas) return;
      const rect = containerRef.current.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = rect.width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${height}px`;
    };

    resize();
    const observer = new ResizeObserver(resize);
    if (containerRef.current) observer.observe(containerRef.current);

    const render = (now: number) => {
      if (!lastTimestampRef.current) lastTimestampRef.current = now;
      const delta = (now - lastTimestampRef.current) / 1000;
      lastTimestampRef.current = now;

      if (isActive) {
        // Speed in simulated seconds per real second
        timeOffsetRef.current += delta;
      }

      const w = canvas.width / (window.devicePixelRatio || 1);
      const h = height;

      // Clear
      ctx.fillStyle = '#0a1018';
      ctx.fillRect(0, 0, w, h);

      // Draw standard Medical ECG / PPG Grid (25mm/s standard)
      ctx.lineWidth = 0.5;
      ctx.strokeStyle = gridColor;
      const gridSize = 16;
      ctx.beginPath();
      for (let x = 0; x < w; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // Major grid lines
      ctx.lineWidth = 1;
      ctx.strokeStyle = type === 'ecg' ? 'rgba(16, 185, 129, 0.22)' : 'rgba(6, 182, 212, 0.22)';
      ctx.beginPath();
      for (let x = 0; x < w; x += gridSize * 5) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = 0; y < h; y += gridSize * 5) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      // Draw Waveform
      const sweepWindowSec = 3.2; // Show ~3.2 seconds across the width
      const currentTime = timeOffsetRef.current;
      const sweepX = ((currentTime % sweepWindowSec) / sweepWindowSec) * w;

      ctx.lineWidth = 2.2;
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      ctx.strokeStyle = isActive ? color : '#475569';

      ctx.beginPath();
      let started = false;

      for (let x = 0; x < w; x += 1.5) {
        // Erase zone near sweep bar (medical monitor sweep effect)
        const distFromSweep = (x - sweepX + w) % w;
        if (distFromSweep < 24 && distFromSweep > 0) {
          continue; // Erase gap ahead of sweep head
        }

        // Time corresponding to this pixel
        const tPixel = currentTime - ((w - x) / w) * sweepWindowSec;

        let yNorm = 0;
        if (isActive) {
          if (type === 'ecg') {
            const val = getEcgSample(tPixel, heartRate, respiratoryRate);
            // baseline at center (h * 0.58)
            yNorm = h * 0.58 - val * (h * 0.28);
          } else {
            const val = getPpgSample(tPixel, heartRate, respiratoryRate);
            // baseline at bottom (h * 0.8)
            yNorm = h * 0.82 - val * (h * 0.62);
          }
        } else {
          // Flatline or subtle baseline
          yNorm = h * 0.58 + Math.sin(tPixel * 2) * 1.5;
        }

        if (!started || distFromSweep < 26) {
          ctx.moveTo(x, yNorm);
          started = true;
        } else {
          ctx.lineTo(x, yNorm);
        }
      }
      ctx.stroke();

      // Draw glow line for high-tech aesthetic
      if (isActive) {
        ctx.shadowBlur = 8;
        ctx.shadowColor = color;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      // Draw Sweep Head Cursor
      if (isActive) {
        const grad = ctx.createLinearGradient(sweepX - 20, 0, sweepX + 2, 0);
        grad.addColorStop(0, 'rgba(16, 185, 129, 0)');
        grad.addColorStop(1, color);
        ctx.fillStyle = grad;
        ctx.fillRect(sweepX - 4, 0, 4, h);
      }

      animationFrameId.current = requestAnimationFrame(render);
    };

    animationFrameId.current = requestAnimationFrame(render);

    return () => {
      if (animationFrameId.current) cancelAnimationFrame(animationFrameId.current);
      observer.disconnect();
    };
  }, [type, heartRate, respiratoryRate, isActive, color, gridColor, height]);

  return (
    <div ref={containerRef} className="relative w-full rounded-lg overflow-hidden border border-slate-800 bg-[#070d14] shadow-inner">
      <canvas ref={canvasRef} className="block w-full" />
      {showLeadInfo && (
        <div className="absolute top-1.5 left-2 flex items-center gap-2 pointer-events-none text-[11px] font-mono font-medium">
          <span className="px-1.5 py-0.5 rounded bg-slate-900/80 border border-slate-700 text-slate-300">
            {type === 'ecg' ? 'AD8232 • Lead II (25mm/s)' : 'MAX30102 • IR/RED PPG'}
          </span>
          <span className={`px-1.5 py-0.5 rounded text-[10px] ${isActive ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60' : 'bg-slate-900 text-slate-500'}`}>
            {isActive ? 'SIGNAL: ACQUIRED' : 'STANDBY'}
          </span>
        </div>
      )}
    </div>
  );
};
