import React from 'react';
import { CheckCircle2, Loader2, PlayCircle, Cpu, Radio, Smartphone, Activity } from 'lucide-react';
import { MeasurementStep } from '../types';

export const MEASUREMENT_STEPS: MeasurementStep[] = [
  { step: 1, label: 'Sensor Integrity Check', description: 'Checking hardware connections & bus readiness', activeSensorId: undefined },
  { step: 2, label: 'Virtual Sensor Handshake', description: 'Initializing AD8232, MAX30102, MLX90614 & Glucose modules', activeSensorId: undefined },
  { step: 3, label: 'ECG Lead II Acquisition', description: 'Acquiring P-QRS-T analog signal via AD8232 ADC', activeSensorId: 'ad8232_ecg' },
  { step: 4, label: 'SpO2 & PPG Acquisition', description: 'Sampling Red/IR optical reflectometry via MAX30102', activeSensorId: 'max30102_ppg' },
  { step: 5, label: 'Temperature Readout', description: 'Reading IR thermopile register via MLX90614 I2C', activeSensorId: 'mlx90614_temp' },
  { step: 6, label: 'Respiratory Calculation', description: 'Extracting respiration frequency from PPG/ECG wander', activeSensorId: 'resp_calc' },
  { step: 7, label: 'Blood Glucose Reading', description: 'Sampling simulated electrochemical measurement module', activeSensorId: 'glucose_module' },
  { step: 8, label: 'ESP32 Firmware Processing', description: 'Filtering signals, compiling telemetry packet & checksum', activeSensorId: undefined },
  { step: 9, label: 'BLE 5.0 Transmission', description: 'Transmitting encrypted GATT packet to JeevaSetu Mobile', activeSensorId: undefined },
  { step: 10, label: 'App Interface Auto-Fill', description: 'Vitals successfully decoded & displayed for Patient JS-001', activeSensorId: undefined },
];

interface MeasurementStepIndicatorProps {
  currentStep: number; // 0 to 10
  isMeasuring: boolean;
  progressPercent: number;
}

export const MeasurementStepIndicator: React.FC<MeasurementStepIndicatorProps> = ({
  currentStep,
  isMeasuring,
  progressPercent,
}) => {
  const activeStepObj = currentStep > 0 && currentStep <= 10 ? MEASUREMENT_STEPS[currentStep - 1] : null;

  return (
    <div id="measurement-stepper" className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold font-mono text-slate-100 uppercase tracking-wider">
              10-Stage Measurement & Data-Flow Pipeline
            </h4>
            <p className="text-[11px] text-slate-400">
              {isMeasuring 
                ? `Step ${currentStep}/10: ${activeStepObj?.label}` 
                : (currentStep === 10 ? 'Survey Complete • Vitals Streamed to App' : 'Ready to start survey acquisition sequence')}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-xs font-mono font-bold text-sky-400">
              {progressPercent}%
            </span>
          </div>
          <div className="w-28 sm:w-36 h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
            <div 
              className="h-full bg-gradient-to-r from-emerald-500 via-sky-400 to-teal-400 transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Horizontal step pills */}
      <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-1.5 mt-3">
        {MEASUREMENT_STEPS.map((s) => {
          const isDone = currentStep > s.step;
          const isCurrent = currentStep === s.step && isMeasuring;

          return (
            <div
              key={s.step}
              className={`p-1.5 rounded-lg border text-[10px] font-mono transition-all flex flex-col justify-between ${
                isCurrent
                  ? 'bg-sky-950/80 border-sky-400 text-sky-200 ring-1 ring-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.3)] animate-pulse'
                  : isDone
                  ? 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300'
                  : 'bg-slate-950/60 border-slate-800 text-slate-500'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold">S{s.step}</span>
                {isCurrent && <Loader2 className="w-2.5 h-2.5 animate-spin text-sky-400" />}
                {isDone && <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />}
              </div>
              <div className="truncate mt-0.5 font-medium leading-tight">
                {s.label.split(' ')[0]}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
