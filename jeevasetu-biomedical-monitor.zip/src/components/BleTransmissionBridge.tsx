import React from 'react';
import { Radio, ArrowRight, Zap, Wifi, Layers, ShieldCheck, Activity } from 'lucide-react';
import { DataTransferMode, BleStatus } from '../types';

interface BleTransmissionBridgeProps {
  bleStatus: BleStatus;
  dataTransferState: DataTransferMode;
  isMeasuring: boolean;
  heartRate: number;
  spo2: number;
  temperature: number;
  respiratoryRate: number;
  bloodGlucose: number;
}

export const BleTransmissionBridge: React.FC<BleTransmissionBridgeProps> = ({
  bleStatus,
  dataTransferState,
  isMeasuring,
  heartRate,
  spo2,
  temperature,
  respiratoryRate,
  bloodGlucose,
}) => {
  return (
    <div id="ble-bridge" className="flex flex-col items-center justify-center p-2 lg:p-3 relative z-20">
      {/* Pipeline Container */}
      <div className="flex flex-row lg:flex-col items-center gap-3 w-full justify-center">
        
        {/* Wireless Protocol Badge */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-sky-500/30 text-sky-300 text-[11px] font-mono shadow-lg">
          <Radio className={`w-3.5 h-3.5 ${isMeasuring ? 'text-sky-400 animate-spin' : 'text-sky-400'}`} />
          <span className="font-semibold">BLE 5.0 GATT</span>
        </div>

        {/* Animated Data Stream Flow */}
        <div className="relative flex items-center justify-center w-28 lg:w-full h-10 lg:h-36">
          {/* Main vertical/horizontal data pipe line */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 -translate-x-1/2 w-1 bg-slate-800 rounded-full overflow-hidden">
            {isMeasuring && (
              <div className="w-full h-1/2 bg-gradient-to-b from-transparent via-sky-400 to-emerald-400 animate-[bounce_1.5s_infinite]" />
            )}
          </div>

          <div className="lg:hidden absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 bg-slate-800 rounded-full overflow-hidden">
            {isMeasuring && (
              <div className="h-full w-1/2 bg-gradient-to-r from-transparent via-sky-400 to-emerald-400 animate-[pulse_1.5s_infinite]" />
            )}
          </div>

          {/* Flying Data Packets */}
          {isMeasuring && (
            <div className="relative z-10 flex flex-col items-center gap-1">
              <div className="px-2 py-0.5 rounded bg-sky-950/90 text-sky-300 border border-sky-500 text-[10px] font-mono shadow-[0_0_12px_rgba(56,189,248,0.4)] animate-pulse flex items-center gap-1">
                <Zap className="w-2.5 h-2.5 text-amber-400" />
                <span>TX: 20Hz</span>
              </div>
              <div className="hidden lg:flex flex-col items-center text-[9px] font-mono text-slate-400">
                <span>RSSI: -58 dBm</span>
                <span className="text-emerald-400">GATT NOTIFY</span>
              </div>
            </div>
          )}

          {!isMeasuring && (
            <div className="relative z-10 text-[10px] font-mono text-slate-500 bg-slate-950/80 px-2 py-1 rounded border border-slate-800">
              STANDBY
            </div>
          )}
        </div>

        {/* Signal arrows */}
        <div className="flex lg:flex-col items-center gap-1 text-slate-600">
          <ArrowRight className="w-4 h-4 hidden lg:block rotate-90 text-sky-400/70 animate-bounce" />
          <ArrowRight className="w-4 h-4 lg:hidden text-sky-400/70 animate-pulse" />
        </div>

        {/* Status indicator pill */}
        <div className="hidden lg:flex flex-col items-center gap-0.5 text-center">
          <span className="text-[10px] font-mono text-slate-400">STATUS</span>
          <span className="text-[11px] font-mono font-bold text-emerald-400">
            {bleStatus === 'CONNECTED' ? 'ENCRYPTED' : bleStatus}
          </span>
        </div>
      </div>
    </div>
  );
};
