import React from 'react';
import { Activity, Cpu, Radio, Battery, Zap, Thermometer, Droplet, Heart, Wind, ShieldAlert, CheckCircle2, RefreshCw } from 'lucide-react';
import { SensorId, SensorStatus, Esp32Status, BleStatus } from '../types';

interface HardwareDiagramProps {
  sensorStatuses: Record<SensorId, SensorStatus>;
  esp32Status: Esp32Status;
  bleStatus: BleStatus;
  batteryLevel: number;
  isMeasuring: boolean;
  heartRate: number;
  spo2: number;
  temperature: number;
  respiratoryRate: number;
  bloodGlucose: number;
  activeSensorHighlight?: SensorId;
}

export const HardwareDiagram: React.FC<HardwareDiagramProps> = ({
  sensorStatuses,
  esp32Status,
  bleStatus,
  batteryLevel,
  isMeasuring,
  heartRate,
  spo2,
  temperature,
  respiratoryRate,
  bloodGlucose,
  activeSensorHighlight,
}) => {
  const getStatusColor = (status: SensorStatus) => {
    switch (status) {
      case 'DISCONNECTED':
        return 'bg-slate-800 text-slate-400 border-slate-700';
      case 'CONNECTING':
        return 'bg-amber-950/80 text-amber-300 border-amber-600 animate-pulse';
      case 'CONNECTED':
        return 'bg-blue-950/80 text-blue-300 border-blue-600';
      case 'MEASURING':
        return 'bg-emerald-950/90 text-emerald-300 border-emerald-500 ring-2 ring-emerald-500/40 animate-pulse';
      case 'DATA SENT':
        return 'bg-teal-950/90 text-teal-300 border-teal-500';
      default:
        return 'bg-slate-800 text-slate-400';
    }
  };

  const getStatusLed = (status: SensorStatus) => {
    switch (status) {
      case 'DISCONNECTED':
        return 'bg-rose-500/40';
      case 'CONNECTING':
        return 'bg-amber-400 animate-ping';
      case 'CONNECTED':
        return 'bg-blue-400';
      case 'MEASURING':
        return 'bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse';
      case 'DATA SENT':
        return 'bg-teal-400 shadow-[0_0_6px_#2dd4bf]';
      default:
        return 'bg-slate-500';
    }
  };

  return (
    <div id="hardware-diagram-container" className="flex flex-col h-full bg-slate-900/90 rounded-2xl border border-slate-800 p-4 lg:p-5 shadow-2xl backdrop-blur-md relative overflow-hidden">
      {/* PCB circuit background grid texture */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />

      {/* Header bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold tracking-wide uppercase text-slate-100 font-mono">
                JeevaSetu Hardware Architecture
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-800 font-mono">
                REV 2.1 PROTOTYPE
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Multi-parameter survey telemetry unit with ESP32 edge processing
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-950/80 border border-slate-800 text-slate-300">
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
            <span>{batteryLevel}%</span>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-950/80 border border-slate-800">
            <span className={`w-2 h-2 rounded-full ${esp32Status === 'ONLINE' ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-rose-500'}`} />
            <span className="text-slate-300">ESP32: {esp32Status}</span>
          </div>
        </div>
      </div>

      {/* Main Hardware layout grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mt-4 flex-1 relative z-10">
        
        {/* Left Column: Physical Sensor Modules */}
        <div className="md:col-span-6 flex flex-col gap-3 justify-between">
          <div className="text-[11px] font-mono font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <span>Biomedical Sensors (Data Acquisition)</span>
            <span className="h-px flex-1 bg-slate-800"></span>
          </div>

          {/* Sensor 1: AD8232 ECG */}
          <div className={`p-3 rounded-xl border transition-all duration-300 ${
            activeSensorHighlight === 'ad8232_ecg' 
              ? 'bg-emerald-950/30 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.15)] ring-1 ring-emerald-500/50' 
              : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${getStatusLed(sensorStatuses.ad8232_ecg)}`} />
                <div className="p-1.5 rounded-md bg-rose-500/10 text-rose-400 border border-rose-500/20">
                  <Heart className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-200 font-mono">AD8232 Single-Lead ECG</div>
                  <div className="text-[10px] text-slate-400 font-mono">Analog Front-End • 3-Electrode (RA/LA/RL)</div>
                </div>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${getStatusColor(sensorStatuses.ad8232_ecg)}`}>
                {sensorStatuses.ad8232_ecg}
              </span>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono">
              <span className="text-slate-400">Signal: <strong className="text-emerald-400">P-QRS-T Waveform</strong></span>
              <span className="text-slate-300">Derived HR: <strong className="text-rose-400">{sensorStatuses.ad8232_ecg === 'MEASURING' || sensorStatuses.ad8232_ecg === 'DATA SENT' ? `${Math.round(heartRate)} BPM` : '--'}</strong></span>
              <span className="text-[10px] text-slate-500 bg-slate-900 px-1.5 py-0.5 rounded">Pin ADC1_CH0</span>
            </div>
          </div>

          {/* Sensor 2: MAX30102 Pulse Oximeter */}
          <div className={`p-3 rounded-xl border transition-all duration-300 ${
            activeSensorHighlight === 'max30102_ppg' 
              ? 'bg-cyan-950/30 border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.15)] ring-1 ring-cyan-500/50' 
              : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${getStatusLed(sensorStatuses.max30102_ppg)}`} />
                <div className="p-1.5 rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Activity className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-200 font-mono">MAX30102 Pulse Oximeter</div>
                  <div className="text-[10px] text-slate-400 font-mono">Optical Biosensor • Red (660nm) & IR (880nm)</div>
                </div>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${getStatusColor(sensorStatuses.max30102_ppg)}`}>
                {sensorStatuses.max30102_ppg}
              </span>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono">
              <span className="text-slate-400">SpO2: <strong className="text-cyan-400">{sensorStatuses.max30102_ppg === 'MEASURING' || sensorStatuses.max30102_ppg === 'DATA SENT' ? `${Math.round(spo2)}%` : '--'}</strong></span>
              <span className="text-slate-300">PPG: <strong className="text-sky-400">{sensorStatuses.max30102_ppg === 'MEASURING' || sensorStatuses.max30102_ppg === 'DATA SENT' ? 'Pulsing' : 'Standby'}</strong></span>
              <span className="text-[10px] text-slate-500 bg-slate-900 px-1.5 py-0.5 rounded">I2C (0x57)</span>
            </div>
          </div>

          {/* Sensor 3: MLX90614 Non-Contact Temp */}
          <div className={`p-3 rounded-xl border transition-all duration-300 ${
            activeSensorHighlight === 'mlx90614_temp' 
              ? 'bg-amber-950/30 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.15)] ring-1 ring-amber-500/50' 
              : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${getStatusLed(sensorStatuses.mlx90614_temp)}`} />
                <div className="p-1.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  <Thermometer className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-200 font-mono">MLX90614 IR Thermometer</div>
                  <div className="text-[10px] text-slate-400 font-mono">Medical-grade Non-Contact IR Thermopile</div>
                </div>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${getStatusColor(sensorStatuses.mlx90614_temp)}`}>
                {sensorStatuses.mlx90614_temp}
              </span>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono">
              <span className="text-slate-400">Body Temp: <strong className="text-amber-400">{sensorStatuses.mlx90614_temp === 'MEASURING' || sensorStatuses.mlx90614_temp === 'DATA SENT' ? `${temperature.toFixed(1)} °C` : '--'}</strong></span>
              <span className="text-slate-500 text-[10px]">Medical range 32-42°C</span>
              <span className="text-[10px] text-slate-500 bg-slate-900 px-1.5 py-0.5 rounded">I2C (0x5A)</span>
            </div>
          </div>

          {/* Sensor 4: Blood Glucose Module (Clearly Labeled SIMULATED) */}
          <div className={`p-3 rounded-xl border transition-all duration-300 ${
            activeSensorHighlight === 'glucose_module' 
              ? 'bg-purple-950/30 border-purple-500 shadow-[0_0_15px_rgba(168,85,247,0.15)] ring-1 ring-purple-500/50' 
              : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
          }`}>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${getStatusLed(sensorStatuses.glucose_module)}`} />
                <div className="p-1.5 rounded-md bg-purple-500/10 text-purple-400 border border-purple-500/20">
                  <Droplet className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-200 font-mono">Blood Glucose Module</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      SIMULATED
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">Electrochemical Amperometric Reader</div>
                </div>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${getStatusColor(sensorStatuses.glucose_module)}`}>
                {sensorStatuses.glucose_module}
              </span>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono">
              <span className="text-slate-400">Glucose: <strong className="text-purple-400">{sensorStatuses.glucose_module === 'MEASURING' || sensorStatuses.glucose_module === 'DATA SENT' ? `${Math.round(bloodGlucose)} mg/dL` : '--'}</strong></span>
              <span className="text-[10px] text-amber-400/90 font-medium">Virtual strip input</span>
              <span className="text-[10px] text-slate-500 bg-slate-900 px-1.5 py-0.5 rounded">SPI/ADC</span>
            </div>
          </div>
        </div>

        {/* Right Column: ESP32 Microcontroller Core + Firmware Processing */}
        <div className="md:col-span-6 flex flex-col justify-between gap-3">
          <div className="text-[11px] font-mono font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-2">
            <span>Processing Unit & Wireless Hub</span>
            <span className="h-px flex-1 bg-slate-800"></span>
          </div>

          {/* Central ESP32 Microcontroller Board representation */}
          <div className="p-4 rounded-xl bg-slate-950 border-2 border-slate-800 flex-1 flex flex-col justify-between shadow-xl relative overflow-hidden">
            {/* PCB Trace decorative background */}
            <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-100 font-mono">ESP32-WROOM-32</h3>
                    <p className="text-[10px] text-slate-400 font-mono">240MHz Dual-Core Xtensa LX6</p>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1">
                  <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-700/80">
                    STATUS: {esp32Status}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">
                    BLE: <strong className="text-sky-400">{bleStatus}</strong>
                  </span>
                </div>
              </div>

              {/* Hardware Pin Mapping Matrix */}
              <div className="grid grid-cols-2 gap-2 my-3 text-[10px] font-mono">
                <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800/90">
                  <div className="text-slate-500 text-[9px] uppercase tracking-wider mb-1">Hardware Bus Lines</div>
                  <div className="text-slate-300 flex justify-between">
                    <span>I2C SDA/SCL:</span>
                    <span className="text-cyan-400">GPIO21 / GPIO22</span>
                  </div>
                  <div className="text-slate-300 flex justify-between">
                    <span>ADC1 (ECG/Glu):</span>
                    <span className="text-emerald-400">GPIO36 (VP) / GPIO39</span>
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800/90">
                  <div className="text-slate-500 text-[9px] uppercase tracking-wider mb-1">Wireless Stack</div>
                  <div className="text-slate-300 flex justify-between">
                    <span>Protocol:</span>
                    <span className="text-sky-400">BLE 5.0 GATT</span>
                  </div>
                  <div className="text-slate-300 flex justify-between">
                    <span>Adv Name:</span>
                    <span className="text-amber-300">JeevaSetu-001</span>
                  </div>
                </div>
              </div>

              {/* Firmware Component: Respiratory Rate Derived Algorithm (Rule: Derivation from PPG/ECG) */}
              <div className={`p-3 rounded-lg border transition-all ${
                activeSensorHighlight === 'resp_calc' 
                  ? 'bg-teal-950/40 border-teal-500 ring-1 ring-teal-500/50 shadow-md' 
                  : 'bg-slate-900/80 border-slate-800'
              }`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-1 rounded bg-teal-500/10 text-teal-400">
                      <Wind className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-200 font-mono">Respiratory Rate Engine (Firmware)</div>
                      <div className="text-[10px] text-slate-400">
                        Derived from PPG baseline modulation & ECG R-peak wander (EDR)
                      </div>
                    </div>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase ${getStatusColor(sensorStatuses.resp_calc)}`}>
                    {sensorStatuses.resp_calc}
                  </span>
                </div>

                <div className="mt-2 pt-1.5 border-t border-slate-800 flex items-center justify-between text-[11px] font-mono">
                  <span className="text-slate-400">Calculated RR:</span>
                  <strong className="text-teal-300 text-xs">
                    {sensorStatuses.resp_calc === 'MEASURING' || sensorStatuses.resp_calc === 'DATA SENT' 
                      ? `${Math.round(respiratoryRate)} breaths/min` 
                      : '--'}
                  </strong>
                  <span className="text-[9px] text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                    No physical sensor needed
                  </span>
                </div>
              </div>
            </div>

            {/* Embedded Live BLE Telemetry Stream preview on ESP32 */}
            <div className="mt-3 pt-2.5 border-t border-slate-800/80">
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Radio className={`w-3 h-3 ${isMeasuring ? 'text-sky-400 animate-pulse' : 'text-slate-500'}`} />
                  BLE Advertising & Transmission
                </span>
                <span className="text-slate-400">Payload: <strong className="text-emerald-400 font-mono">10 Bytes</strong></span>
              </div>
              <div className="p-2 rounded bg-slate-950 font-mono text-[10px] text-slate-400 border border-slate-800/60 overflow-x-auto whitespace-nowrap">
                <span className="text-slate-500">TX &gt; </span>
                <span className="text-amber-300">0xAA 0x55 </span>
                <span className="text-rose-400">HR:{Math.round(heartRate).toString(16).toUpperCase()} </span>
                <span className="text-cyan-400">SpO2:{Math.round(spo2).toString(16).toUpperCase()} </span>
                <span className="text-amber-400">T:{Math.round(temperature * 10).toString(16).toUpperCase()} </span>
                <span className="text-teal-400">RR:{Math.round(respiratoryRate).toString(16).toUpperCase()} </span>
                <span className="text-purple-400">GLU:{Math.round(bloodGlucose).toString(16).toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Disclaimer Banner */}
      <div className="mt-3.5 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 relative z-10">
        <div className="flex items-center gap-1.5 text-amber-400/90">
          <ShieldAlert className="w-3.5 h-3.5 flex-shrink-0" />
          <span className="text-[10px] leading-tight">
            <strong>Simulation Prototype:</strong> All physiological sensor outputs are simulated for prototype verification and educational demonstrations.
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-[10px] font-mono text-slate-400">
          <span>ESP32 FIRMWARE v1.4.2</span>
        </div>
      </div>
    </div>
  );
};
