import React, { useState } from 'react';
import { 
  Heart, 
  Activity, 
  Thermometer, 
  Wind, 
  Droplet, 
  Wifi, 
  Battery, 
  Radio, 
  User, 
  ShieldCheck, 
  CheckCircle, 
  Clock, 
  RefreshCw, 
  FileText,
  AlertTriangle
} from 'lucide-react';
import { WaveformCanvas } from './WaveformCanvas';
import { PatientVitals, DataTransferMode, BleStatus } from '../types';

interface JeevaSetuMobileAppProps {
  vitals: PatientVitals | null;
  liveHeartRate: number;
  liveSpo2: number;
  liveTemperature: number;
  liveRespiratoryRate: number;
  liveBloodGlucose: number;
  isStreaming: boolean;
  bleStatus: BleStatus;
  dataTransferState: DataTransferMode;
  signalQuality?: 'POOR' | 'MODERATE' | 'GOOD';
}

export const JeevaSetuMobileApp: React.FC<JeevaSetuMobileAppProps> = ({
  vitals,
  liveHeartRate,
  liveSpo2,
  liveTemperature,
  liveRespiratoryRate,
  liveBloodGlucose,
  isStreaming,
  bleStatus,
  dataTransferState,
  signalQuality = 'GOOD',
}) => {
  const [activeTab, setActiveTab] = useState<'ecg' | 'ppg'>('ecg');

  // Values to display: live values when streaming or filled received vitals
  const displayHr = vitals ? vitals.heartRate : (isStreaming ? liveHeartRate : null);
  const displaySpo2 = vitals ? vitals.spo2 : (isStreaming ? liveSpo2 : null);
  const displayTemp = vitals ? vitals.temperature : (isStreaming ? liveTemperature : null);
  const displayResp = vitals ? vitals.respiratoryRate : (isStreaming ? liveRespiratoryRate : null);
  const displayGlucose = vitals ? vitals.bloodGlucose : (isStreaming ? liveBloodGlucose : null);

  const getVitalsStatus = () => {
    if (!displayHr) return { text: 'Awaiting Acquisition', color: 'text-slate-400', bg: 'bg-slate-800' };
    if (displayHr < 50 || displayHr > 110 || (displaySpo2 && displaySpo2 < 92) || (displayTemp && displayTemp > 38.0)) {
      return { text: 'Abnormal Vitals Detected', color: 'text-amber-400', bg: 'bg-amber-950/80 border-amber-800' };
    }
    return { text: 'Normal Physiological Range', color: 'text-emerald-400', bg: 'bg-emerald-950/80 border-emerald-800' };
  };

  const statusInfo = getVitalsStatus();

  return (
    <div id="mobile-app-mockup" className="relative mx-auto w-full max-w-[420px] bg-slate-950 rounded-[36px] border-[6px] border-slate-800 p-3 shadow-2xl shadow-emerald-950/20 text-slate-100 flex flex-col font-sans overflow-hidden">
      
      {/* Mobile Device Speaker & Notch */}
      <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-800 rounded-full flex items-center justify-center gap-2 z-30">
        <div className="w-10 h-1.5 bg-slate-900 rounded-full" />
        <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700" />
      </div>

      {/* Top Mobile Status Bar */}
      <div className="flex items-center justify-between px-3 pt-3 pb-1 text-[11px] font-medium text-slate-400 select-none z-20">
        <span>09:41 AM</span>
        <div className="flex items-center gap-1.5">
          <Wifi className="w-3 h-3 text-slate-300" />
          <Radio className="w-3 h-3 text-sky-400" />
          <div className="flex items-center text-[10px] gap-0.5">
            <span>98%</span>
            <Battery className="w-3.5 h-3.5 text-emerald-400" />
          </div>
        </div>
      </div>

      {/* App Header & Branding */}
      <div className="mt-1 bg-gradient-to-r from-emerald-900/40 via-slate-900 to-sky-950/40 rounded-2xl p-3 border border-emerald-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-950 font-black text-sm shadow-md shadow-emerald-500/20">
              JS
            </div>
            <div>
              <h1 className="text-sm font-black tracking-tight text-white flex items-center gap-1.5">
                JeevaSetu
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  MOBILE APP
                </span>
              </h1>
              <p className="text-[10px] text-slate-400">Portable Medical Survey Portal</p>
            </div>
          </div>

          <div className="flex flex-col items-end">
            <span className="flex items-center gap-1 text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              {dataTransferState === 'LIVE' ? 'LIVE' : (isStreaming ? 'STREAMING' : 'READY')}
            </span>
          </div>
        </div>

        {/* Hardware Connection Card */}
        <div className="mt-2.5 pt-2 border-t border-slate-800/80 grid grid-cols-3 gap-1.5 text-[10px] font-mono">
          <div className="p-1.5 rounded bg-slate-900/90 border border-slate-800">
            <div className="text-slate-500 text-[9px]">DEVICE:</div>
            <div className="text-slate-200 font-bold truncate">JeevaSetu-ESP32-001</div>
          </div>
          <div className="p-1.5 rounded bg-slate-900/90 border border-slate-800">
            <div className="text-slate-500 text-[9px]">CONNECTION:</div>
            <div className="text-emerald-400 font-bold">{bleStatus}</div>
          </div>
          <div className="p-1.5 rounded bg-slate-900/90 border border-slate-800">
            <div className="text-slate-500 text-[9px]">DATA TRANSFER:</div>
            <div className="text-sky-400 font-bold">{dataTransferState}</div>
          </div>
        </div>
      </div>

      {/* Patient Profile Card (JS-001 Demo Patient) */}
      <div className="mt-2.5 p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
            <User className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-100">Demo Patient</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                ID: JS-001
              </span>
            </div>
            <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
              <span>Age: 42 • Male</span>
              <span>•</span>
              <span className="flex items-center gap-1 text-slate-400">
                <Clock className="w-3 h-3 text-slate-500" />
                {vitals?.timestamp || (isStreaming ? 'Measuring live...' : 'Survey pending')}
              </span>
            </div>
          </div>
        </div>

        <div className="text-right">
          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${statusInfo.bg} ${statusInfo.color}`}>
            {statusInfo.text}
          </span>
        </div>
      </div>

      {/* Real-time Waveform Display */}
      <div className="mt-2.5">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('ecg')}
              className={`text-[11px] font-mono px-2.5 py-1 rounded-lg transition-all ${
                activeTab === 'ecg'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 font-bold'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              ECG Lead II
            </button>
            <button
              onClick={() => setActiveTab('ppg')}
              className={`text-[11px] font-mono px-2.5 py-1 rounded-lg transition-all ${
                activeTab === 'ppg'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 font-bold'
                  : 'bg-slate-900 text-slate-400 border border-slate-800'
              }`}
            >
              PPG (Pulse Wave)
            </button>
          </div>

          <div className="flex items-center gap-2 text-[10px] font-mono">
            <span className="text-slate-400">Signal:</span>
            <span className="text-emerald-400 font-bold">{signalQuality}</span>
          </div>
        </div>

        <WaveformCanvas
          type={activeTab}
          heartRate={displayHr || liveHeartRate}
          respiratoryRate={displayResp || liveRespiratoryRate}
          isActive={isStreaming || !!vitals}
          height={115}
          color={activeTab === 'ecg' ? '#10b981' : '#06b6d4'}
        />
      </div>

      {/* Patient Vitals Grid (Auto-populated from Hardware / BLE) */}
      <div className="mt-2.5 grid grid-cols-2 gap-2">
        
        {/* Metric 1: Heart Rate */}
        <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span className="flex items-center gap-1 font-medium">
              <Heart className={`w-3.5 h-3.5 text-rose-500 ${isStreaming ? 'animate-bounce' : ''}`} />
              Heart Rate (ECG/PPG)
            </span>
          </div>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-2xl font-black font-mono tracking-tight text-white">
              {displayHr !== null ? Math.round(displayHr) : '--'}
            </span>
            <span className="text-[11px] font-mono text-slate-400">BPM</span>
          </div>
          <div className="text-[9px] font-mono text-slate-400 mt-0.5">
            Normal: 60–100 BPM
          </div>
        </div>

        {/* Metric 2: SpO2 */}
        <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span className="flex items-center gap-1 font-medium">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              Blood Oxygen (SpO2)
            </span>
          </div>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-2xl font-black font-mono tracking-tight text-cyan-300">
              {displaySpo2 !== null ? Math.round(displaySpo2) : '--'}
            </span>
            <span className="text-[11px] font-mono text-slate-400">%</span>
          </div>
          <div className="text-[9px] font-mono text-slate-400 mt-0.5">
            Target: 95–100 %
          </div>
        </div>

        {/* Metric 3: Body Temperature */}
        <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span className="flex items-center gap-1 font-medium">
              <Thermometer className="w-3.5 h-3.5 text-amber-400" />
              Body Temperature
            </span>
          </div>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-2xl font-black font-mono tracking-tight text-amber-300">
              {displayTemp !== null ? displayTemp.toFixed(1) : '--'}
            </span>
            <span className="text-[11px] font-mono text-slate-400">°C</span>
          </div>
          <div className="text-[9px] font-mono text-slate-400 mt-0.5">
            Normal: 36.1–37.5 °C
          </div>
        </div>

        {/* Metric 4: Respiratory Rate */}
        <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span className="flex items-center gap-1 font-medium">
              <Wind className="w-3.5 h-3.5 text-teal-400" />
              Respiratory Rate
            </span>
          </div>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-2xl font-black font-mono tracking-tight text-teal-300">
              {displayResp !== null ? Math.round(displayResp) : '--'}
            </span>
            <span className="text-[11px] font-mono text-slate-400">br/min</span>
          </div>
          <div className="text-[9px] font-mono text-teal-400/80 mt-0.5">
            Derived from PPG/ECG
          </div>
        </div>

        {/* Metric 5: Blood Glucose (Clearly Labeled SIMULATED) */}
        <div className="col-span-2 p-2.5 rounded-xl bg-slate-900/90 border border-purple-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400">
              <Droplet className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-slate-200">Blood Glucose</span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  SIMULATED
                </span>
              </div>
              <div className="text-[9px] text-slate-400 font-mono">Fasting Normal: 70–140 mg/dL</div>
            </div>
          </div>

          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-black font-mono tracking-tight text-purple-300">
              {displayGlucose !== null ? Math.round(displayGlucose) : '--'}
            </span>
            <span className="text-[11px] font-mono text-slate-400">mg/dL</span>
          </div>
        </div>
      </div>

      {/* Bottom App Navigation / Sync bar */}
      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
        <span className="flex items-center gap-1 text-slate-300">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          Record ID: JS-REC-2026-884
        </span>
        <span className="text-slate-400">Survey Unit #04</span>
      </div>

      {/* Mobile Device Home Bar */}
      <div className="mx-auto mt-2 w-28 h-1 bg-slate-700 rounded-full" />
    </div>
  );
};
