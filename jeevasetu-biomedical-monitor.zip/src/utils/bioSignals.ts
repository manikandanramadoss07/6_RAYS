/**
 * Biomedical signal synthesis utilities for authentic real-time simulation.
 * Computes realistic ECG (P-QRS-T) and PPG waveforms with rate modulation.
 */

export function getEcgSample(tSeconds: number, heartRateBpm: number, respRateBpm: number = 16): number {
  const cycleDuration = 60 / Math.max(30, Math.min(220, heartRateBpm));
  const phase = (tSeconds % cycleDuration) / cycleDuration; // 0 to 1

  // Respiration baseline wander (EDR: ECG-derived respiration modulation)
  const respFreqHz = respRateBpm / 60;
  const baselineWander = 0.06 * Math.sin(2 * Math.PI * respFreqHz * tSeconds);
  const microNoise = (Math.sin(tSeconds * 377) + Math.cos(tSeconds * 521)) * 0.012;

  // Gaussian wave helper
  const gaussian = (p: number, center: number, width: number, height: number) => {
    const diff = p - center;
    return height * Math.exp(-(diff * diff) / (2 * width * width));
  };

  // Standard Lead-II P-QRS-T morphology
  const pWave = gaussian(phase, 0.18, 0.035, 0.22);
  const qWave = gaussian(phase, 0.32, 0.012, -0.25);
  const rPeak = gaussian(phase, 0.35, 0.015, 1.45);
  const sWave = gaussian(phase, 0.38, 0.014, -0.42);
  const tWave = gaussian(phase, 0.58, 0.070, 0.38);
  const uWave = gaussian(phase, 0.74, 0.040, 0.04);

  return pWave + qWave + rPeak + sWave + tWave + uWave + baselineWander + microNoise;
}

export function getPpgSample(tSeconds: number, heartRateBpm: number, respRateBpm: number = 16): number {
  const cycleDuration = 60 / Math.max(30, Math.min(220, heartRateBpm));
  const phase = (tSeconds % cycleDuration) / cycleDuration; // 0 to 1

  // Respiration induced baseline variation (RIIV/RIPV)
  const respFreqHz = respRateBpm / 60;
  const respModulation = 0.08 * Math.sin(2 * Math.PI * respFreqHz * tSeconds);

  // Systolic component
  const systolic = Math.exp(-Math.pow((phase - 0.25) / 0.12, 2)) * 1.0;
  // Dicrotic notch and diastolic wave
  const diastolic = Math.exp(-Math.pow((phase - 0.52) / 0.14, 2)) * 0.42;
  const dicroticDip = -Math.exp(-Math.pow((phase - 0.40) / 0.04, 2)) * 0.15;

  const rawPpg = systolic + diastolic + dicroticDip + respModulation;
  return Math.max(0, rawPpg);
}

export function formatHexByte(val: number): string {
  return val.toString(16).padStart(2, '0').toUpperCase();
}

export function generateBleHexPayload(hr: number, spo2: number, temp: number, resp: number, glucose: number): string {
  // Packet structure:
  // [0xAA (Header), 0x55 (Sync), HR_HEX, SpO2_HEX, Temp_Int_HEX, Temp_Dec_HEX, Resp_HEX, Glu_High_HEX, Glu_Low_HEX, Checksum]
  const tempInt = Math.floor(temp);
  const tempDec = Math.round((temp - tempInt) * 10);
  const gluHigh = Math.floor(glucose / 256);
  const gluLow = glucose % 256;
  
  const bytes = [
    0xAA,
    0x55,
    Math.round(hr) & 0xFF,
    Math.round(spo2) & 0xFF,
    tempInt & 0xFF,
    tempDec & 0xFF,
    Math.round(resp) & 0xFF,
    gluHigh & 0xFF,
    gluLow & 0xFF,
  ];

  const checksum = bytes.reduce((acc, b) => (acc + b) & 0xFF, 0);
  bytes.push(checksum);

  return bytes.map(b => formatHexByte(b)).join(' ');
}
