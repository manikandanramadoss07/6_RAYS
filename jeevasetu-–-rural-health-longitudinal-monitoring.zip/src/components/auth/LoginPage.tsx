import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { useTheme } from '../../context/ThemeContext';
import { PatientOtpModal } from './PatientOtpModal';
import {
  Stethoscope,
  MapPin,
  Phone,
  ShieldCheck,
  Building2,
  Lock,
  User,
  ArrowRight,
  Globe,
  Sun,
  Moon,
  Laptop,
  Check,
  Sparkles,
  AlertCircle,
  HeartPulse,
} from 'lucide-react';
import { LanguageCode } from '../../types';

interface LoginPageProps {
  onOpenSihDemoGuide?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onOpenSihDemoGuide }) => {
  const { loginDoctor, loginSurveyor, loginAdmin } = useAuth();
  const { language, setLanguage, languages, t } = useLanguage();
  const { theme, isDark, setTheme, toggleTheme } = useTheme();

  const [activeModal, setActiveModal] = useState<'doctor' | 'surveyor' | 'admin' | null>(null);
  const [isPatientOtpOpen, setIsPatientOtpOpen] = useState<boolean>(false);
  const [showThemeMenu, setShowThemeMenu] = useState<boolean>(false);

  // Form states
  const [username, setUsername] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (activeModal === 'doctor') {
        const res = await loginDoctor(username || 'dr.priya');
        if (!res.success) setError(res.error || 'Invalid credentials');
      } else if (activeModal === 'surveyor') {
        const res = await loginSurveyor(username || 'asha.anita');
        if (!res.success) setError(res.error || 'Invalid credentials');
      } else if (activeModal === 'admin') {
        const res = await loginAdmin(username || 'admin.bmo');
        if (!res.success) setError(res.error || 'Invalid credentials');
      }
    } catch (err) {
      setError('An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  const openQuickLogin = (role: 'doctor' | 'surveyor' | 'admin', defaultUser: string) => {
    setUsername(defaultUser);
    setPassword('••••••••');
    setActiveModal(role);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Top Banner Stripe */}
      <div className="h-1.5 w-full bg-gradient-to-r from-amber-500 via-white to-emerald-600"></div>

      {/* Navigation & Controls Bar */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-700 text-white flex items-center justify-center font-bold">
            <Building2 className="w-4 h-4 text-amber-300" />
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            {t('govMission', 'Government of India Mission')}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Language Switcher */}
          <div className="relative inline-block text-left">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              className="px-2.5 py-1.5 text-xs font-medium bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-lg shadow-xs focus:outline-hidden"
            >
              {languages.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.nativeName} ({l.name})
                </option>
              ))}
            </select>
          </div>

          {/* Theme Selector (Light / Dark / System) */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowThemeMenu(!showThemeMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 shadow-xs transition-all"
              title={`Current theme: ${theme} mode. Click to change.`}
            >
              {isDark ? (
                <Sun className="w-3.5 h-3.5 text-amber-400" />
              ) : (
                <Moon className="w-3.5 h-3.5 text-indigo-600" />
              )}
              <span className="hidden sm:inline capitalize">
                {theme === 'system' ? 'System' : isDark ? 'Dark' : 'Light'}
              </span>
            </button>

            {showThemeMenu && (
              <div
                className="absolute right-0 mt-2 w-44 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in slide-in-from-top-2"
                onMouseLeave={() => setShowThemeMenu(false)}
              >
                <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                  Theme / रंग रूप
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setTheme('light');
                    setShowThemeMenu(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                    theme === 'light'
                      ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-bold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Sun className="w-4 h-4 text-amber-500" />
                    <span>Light Mode</span>
                  </div>
                  {theme === 'light' && <Check className="w-3.5 h-3.5 text-amber-600" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setTheme('dark');
                    setShowThemeMenu(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                    theme === 'dark'
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Moon className="w-4 h-4 text-indigo-500" />
                    <span>Dark Mode</span>
                  </div>
                  {theme === 'dark' && <Check className="w-3.5 h-3.5 text-indigo-500" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setTheme('system');
                    setShowThemeMenu(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                    theme === 'system'
                      ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 font-bold'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Laptop className="w-4 h-4 text-sky-500" />
                    <span>System Default</span>
                  </div>
                  {theme === 'system' && <Check className="w-3.5 h-3.5 text-sky-500" />}
                </button>
              </div>
            )}
          </div>


          {/* SIH Scenario Shortcut */}
          {onOpenSihDemoGuide && (
            <button
              type="button"
              onClick={onOpenSihDemoGuide}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-100 dark:bg-amber-950/80 text-amber-900 dark:text-amber-300 border border-amber-300 dark:border-amber-700 shadow-xs hover:bg-amber-200 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>SIH Demo Guide</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Hero & 3 Distinct Login Cards */}
      <div className="flex-1 flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8 py-8 sm:py-12 max-w-5xl mx-auto w-full">
        {/* Branding Header */}
        <div className="text-center max-w-2xl mb-8 sm:mb-12 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-800/80 text-indigo-700 dark:text-indigo-300 text-xs font-semibold mb-3">
            <HeartPulse className="w-3.5 h-3.5 text-rose-500" />
            <span>Rural Health Longitudinal Monitoring Platform</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            {t('appName', 'JeevaSetu')}
          </h1>
          <p className="text-base sm:text-lg text-indigo-600 dark:text-indigo-400 font-semibold mt-1">
            {t('govMission', 'Government of India Mission')}
          </p>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 mt-2 font-medium">
            "{t('tagline', 'Bridging Community Health to Continuous Care.')}"
          </p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1 max-w-md mx-auto">
            {t('prototypeNote', 'SIH Healthcare Innovation Demonstration Prototype')}
          </p>
        </div>

        {/* THREE DISTINCT LOGIN CARDS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 sm:gap-6 w-full mb-8">
          {/* 1. DOCTOR LOGIN CARD */}
          <div
            id="login-card-doctor"
            className="bg-white dark:bg-slate-900 rounded-2xl p-6 border-2 border-indigo-100 dark:border-slate-800 shadow-md hover:shadow-xl hover:border-indigo-400 dark:hover:border-indigo-600 transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <Stethoscope className="w-6 h-6" />
              </div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {t('doctorLogin', 'Doctor Login')}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                {t('doctorLoginDesc', 'Secure clinical dashboard, longitudinal trend charts & doctor-only clinical risk score review.')}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <button
                type="button"
                onClick={() => openQuickLogin('doctor', 'dr.priya')}
                className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-sm flex items-center justify-center gap-1.5 transition-all"
              >
                <span>{t('doctorLogin', 'Doctor Sign In')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <div className="text-[11px] text-center text-slate-400">
                Demo: <span className="font-semibold text-slate-600 dark:text-slate-300">Dr. Priya Sharma, MD</span>
              </div>
            </div>
          </div>

          {/* 2. SURVEYOR / FIELD WORKER LOGIN CARD */}
          <div
            id="login-card-surveyor"
            className="bg-white dark:bg-slate-900 rounded-2xl p-6 border-2 border-emerald-100 dark:border-slate-800 shadow-md hover:shadow-xl hover:border-emerald-400 dark:hover:border-emerald-600 transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <MapPin className="w-6 h-6" />
              </div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {t('surveyorLogin', 'Surveyor Login')}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                {t('surveyorLoginDesc', 'Field health surveys, auto Unique Patient ID generation, biomedical measurements & offline synchronization.')}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <button
                type="button"
                onClick={() => openQuickLogin('surveyor', 'asha.anita')}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-sm flex items-center justify-center gap-1.5 transition-all"
              >
                <span>{t('surveyorLogin', 'Surveyor Sign In')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <div className="text-[11px] text-center text-slate-400">
                Demo: <span className="font-semibold text-slate-600 dark:text-slate-300">Anita Devi (ASHA Worker)</span>
              </div>
            </div>
          </div>

          {/* 3. PATIENT LOGIN CARD (MOBILE + OTP ONLY) */}
          <div
            id="login-card-patient"
            className="bg-white dark:bg-slate-900 rounded-2xl p-6 border-2 border-sky-100 dark:border-slate-800 shadow-md hover:shadow-xl hover:border-sky-400 dark:hover:border-sky-600 transition-all flex flex-col justify-between group"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <Phone className="w-6 h-6" />
              </div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                {t('patientLogin', 'Patient Login')}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                {t('patientLoginDesc', 'Instant access via Mobile Number + OTP. No usernames or passwords required for rural accessibility.')}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <button
                type="button"
                onClick={() => setIsPatientOtpOpen(true)}
                className="w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-sm flex items-center justify-center gap-1.5 transition-all"
              >
                <span>{t('patientLogin', 'Mobile + OTP Login')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <div className="text-[11px] text-center text-slate-400">
                Demo Phone: <span className="font-semibold text-slate-600 dark:text-slate-300">9876543210</span>
              </div>
            </div>
          </div>
        </div>

        {/* Supervisor / Admin Gateway & Quick Demo Bar */}
        <div className="w-full bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                {t('adminLogin', 'PHC Block Supervisor / Admin')}
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Community health statistics, village-wise surveys, surveyor tracking & sync logs.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => openQuickLogin('admin', 'admin.bmo')}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 transition-all shrink-0"
          >
            <span>Admin Sign In</span>
          </button>
        </div>
      </div>

      {/* DOCTOR / SURVEYOR / ADMIN LOGIN MODAL */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className={`p-6 text-white text-center relative ${
              activeModal === 'doctor' ? 'bg-gradient-to-r from-indigo-600 to-indigo-800' :
              activeModal === 'surveyor' ? 'bg-gradient-to-r from-emerald-600 to-emerald-800' :
              'bg-gradient-to-r from-amber-600 to-amber-800'
            }`}>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="absolute top-4 right-4 text-white/80 hover:text-white text-sm px-2 py-1 rounded-md bg-white/10 hover:bg-white/20 transition-colors"
              >
                ✕
              </button>

              <div className="w-12 h-12 rounded-full bg-white/15 mx-auto flex items-center justify-center mb-2 shadow-inner">
                {activeModal === 'doctor' ? <Stethoscope className="w-6 h-6 text-white" /> :
                 activeModal === 'surveyor' ? <MapPin className="w-6 h-6 text-white" /> :
                 <ShieldCheck className="w-6 h-6 text-white" />}
              </div>

              <h3 className="text-xl font-bold">
                {activeModal === 'doctor' ? t('doctorLogin', 'Doctor Login') :
                 activeModal === 'surveyor' ? t('surveyorLogin', 'Surveyor Login') :
                 t('adminLogin', 'Supervisor Login')}
              </h3>
              <p className="text-xs opacity-90 mt-1">
                {activeModal === 'doctor' ? 'Clinical evaluation and longitudinal records' :
                 activeModal === 'surveyor' ? 'Field health surveys and patient registration' :
                 'Block-level administrative monitoring'}
              </p>
            </div>

            {/* Modal Form */}
            <div className="p-6">
              {error && (
                <div className="mb-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    {t('usernameOrEmail', 'Username or Email')}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder={activeModal === 'doctor' ? 'dr.priya' : activeModal === 'surveyor' ? 'asha.anita' : 'admin.bmo'}
                      className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      required
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      {t('password', 'Password')}
                    </label>
                    <span className="text-[11px] text-slate-400 hover:underline cursor-pointer">
                      {t('forgotPassword', 'Forgot?')}
                    </span>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={`w-full py-3 px-4 rounded-xl text-white font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-2 ${
                    activeModal === 'doctor' ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/20' :
                    activeModal === 'surveyor' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20' :
                    'bg-amber-600 hover:bg-amber-700 shadow-amber-600/20'
                  }`}
                >
                  <span>{t('loginButton', 'Sign In')}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* Quick 1-Click Demo Profiles */}
              <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                  1-Click Prototype Credentials
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {activeModal === 'doctor' && (
                    <>
                      <button
                        type="button"
                        onClick={() => { setUsername('dr.priya'); setPassword('demo123'); }}
                        className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                      >
                        Dr. Priya (MD)
                      </button>
                      <button
                        type="button"
                        onClick={() => { setUsername('dr.arvind'); setPassword('demo123'); }}
                        className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                      >
                        Dr. Arvind (MO)
                      </button>
                    </>
                  )}
                  {activeModal === 'surveyor' && (
                    <>
                      <button
                        type="button"
                        onClick={() => { setUsername('asha.anita'); setPassword('demo123'); }}
                        className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                      >
                        ASHA Anita Devi
                      </button>
                      <button
                        type="button"
                        onClick={() => { setUsername('hw.ramesh'); setPassword('demo123'); }}
                        className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                      >
                        HW Ramesh
                      </button>
                    </>
                  )}
                  {activeModal === 'admin' && (
                    <button
                      type="button"
                      onClick={() => { setUsername('admin.bmo'); setPassword('demo123'); }}
                      className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium"
                    >
                      BMO Dr. Murthy
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PATIENT OTP MODAL */}
      <PatientOtpModal isOpen={isPatientOtpOpen} onClose={() => setIsPatientOtpOpen(false)} />
    </div>
  );
};
