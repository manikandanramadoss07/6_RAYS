import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { StorageService } from '../../services/storageService';
import { Patient } from '../../types';
import { Phone, KeyRound, ArrowRight, UserCheck, RefreshCw, AlertCircle, Sparkles } from 'lucide-react';

interface PatientOtpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PatientOtpModal: React.FC<PatientOtpModalProps> = ({ isOpen, onClose }) => {
  const { loginPatientWithOtp } = useAuth();
  const { t } = useLanguage();

  const [step, setStep] = useState<'mobile' | 'otp' | 'select_profile'>('mobile');
  const [mobile, setMobile] = useState<string>('9876543210'); // Pre-fill with demo shared mobile
  const [otp, setOtp] = useState<string>('');
  const [matchedPatients, setMatchedPatients] = useState<Patient[]>([]);
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const cleanNumber = mobile.replace(/\D/g, '');
    if (cleanNumber.length !== 10) {
      setError('Please enter a valid 10-digit Indian mobile number.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      // Find matching patients in storage
      const found = StorageService.getPatientsByMobile(cleanNumber);
      if (found.length === 0) {
        // Fallback: search all or suggest Lakshmi
        const all = StorageService.getPatients();
        setMatchedPatients([all[0]]);
      } else {
        setMatchedPatients(found);
      }
      setStep('otp');
    }, 400);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!otp || otp.length < 4) {
      setError(t('enterOtp', 'Please enter the 6-digit OTP sent to your phone.'));
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (matchedPatients.length > 1) {
        // Multi-patient selection required!
        setStep('select_profile');
      } else if (matchedPatients.length === 1) {
        // Single patient login
        loginPatientWithOtp(matchedPatients[0].patient_id);
        onClose();
      } else {
        // Default to first patient
        const first = StorageService.getPatients()[0];
        loginPatientWithOtp(first.patient_id);
        onClose();
      }
    }, 400);
  };

  const handleConfirmProfile = () => {
    if (!selectedPatientId) {
      setError('Please select your patient profile.');
      return;
    }
    loginPatientWithOtp(selectedPatientId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header Strip */}
        <div className="bg-gradient-to-r from-sky-600 to-indigo-700 p-6 text-white text-center relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white text-sm px-2 py-1 rounded-md bg-white/10 hover:bg-white/20 transition-colors"
          >
            ✕
          </button>
          <div className="w-12 h-12 rounded-full bg-white/15 mx-auto flex items-center justify-center mb-2 shadow-inner">
            <Phone className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-xl font-bold">{t('patientLogin', 'Patient Portal Login')}</h3>
          <p className="text-xs text-sky-100 mt-1">
            {t('patientLoginDesc', 'Instant access via Mobile Number + OTP (No password needed)')}
          </p>
        </div>

        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1: MOBILE NUMBER INPUT */}
          {step === 'mobile' && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('mobileNumber', 'Mobile Number')}
                </label>
                <div className="flex rounded-xl shadow-xs border border-slate-300 dark:border-slate-700 overflow-hidden focus-within:ring-2 focus-within:ring-sky-500">
                  <span className="inline-flex items-center px-3.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-sm border-r border-slate-300 dark:border-slate-700">
                    +91
                  </span>
                  <input
                    type="tel"
                    maxLength={10}
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="9876543210"
                    className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden font-mono tracking-wider"
                    autoFocus
                    required
                  />
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
                  Try demo number <button type="button" onClick={() => setMobile('9876543210')} className="text-sky-600 dark:text-sky-400 font-semibold underline">9876543210</button> (linked to 2 rural patients).
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold text-sm shadow-md shadow-sky-600/20 transition-all flex items-center justify-center gap-2"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
                <span>{t('sendOtp', 'Send OTP')}</span>
              </button>
            </form>
          )}

          {/* STEP 2: OTP VERIFICATION */}
          {step === 'otp' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="p-3 bg-sky-50 dark:bg-sky-950/40 rounded-xl border border-sky-200 dark:border-sky-800/60 text-xs text-sky-800 dark:text-sky-200 flex items-center justify-between">
                <div>
                  <span>Sent OTP to <strong>+91 {mobile}</strong></span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setStep('mobile');
                    setOtp('');
                  }}
                  className="text-sky-600 dark:text-sky-400 underline font-semibold hover:text-sky-800"
                >
                  {t('changeMobile', 'Change')}
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  {t('enterOtp', 'Enter 6-digit OTP')}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    maxLength={6}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="123456"
                    className="w-full px-4 py-3 text-center tracking-[0.5em] text-lg font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
                    autoFocus
                    required
                  />
                </div>
                <div className="flex items-center justify-between mt-2 text-[11px] text-slate-500">
                  <span>{t('demoOtpHint', 'Demo OTP: enter 123456')}</span>
                  <button
                    type="button"
                    onClick={() => setOtp('123456')}
                    className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
                  >
                    Auto-fill OTP
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
                <span>{t('verifyOtp', 'Verify & Login')}</span>
              </button>
            </form>
          )}

          {/* STEP 3: MULTI-PATIENT PROFILE SELECTOR (Crucial Rural Handling!) */}
          {step === 'select_profile' && (
            <div className="space-y-4">
              <div className="text-xs text-slate-600 dark:text-slate-300">
                <p className="font-semibold text-slate-800 dark:text-slate-100 mb-1">
                  {t('multipleProfilesFound', 'Multiple patients registered under this mobile number:')}
                </p>
                <p className="text-slate-500 text-[11px]">
                  In rural households, multiple family members often share a single phone. Please select your specific identity:
                </p>
              </div>

              <div className="space-y-2">
                {matchedPatients.map((p) => {
                  const isSelected = selectedPatientId === p.patient_id;
                  return (
                    <div
                      key={p.patient_id}
                      onClick={() => setSelectedPatientId(p.patient_id)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/60 dark:border-indigo-500 ring-2 ring-indigo-500/20'
                          : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs ${
                          p.sex === 'Female' ? 'bg-pink-100 text-pink-700 dark:bg-pink-950 dark:text-pink-300' : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                        }`}>
                          {p.name.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900 dark:text-white">{p.name}</div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            {p.patient_id} • {p.age} yrs • {p.sex} • {p.village}
                          </div>
                        </div>
                      </div>
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                        isSelected ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-300 dark:border-slate-600'
                      }`}>
                        {isSelected && <span className="text-xs">✓</span>}
                      </div>
                    </div>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={handleConfirmProfile}
                disabled={!selectedPatientId}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-semibold text-sm shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
              >
                <UserCheck className="w-4 h-4" />
                <span>{t('selectProfile', 'Open Selected Record')}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
