import React, { useState } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  ReferenceArea,
} from 'recharts';
import { Visit } from '../../types';
import { useLanguage } from '../../i18n/LanguageContext';
import { useTheme } from '../../context/ThemeContext';
import { Activity, Heart, Wind, Thermometer, Droplets, ShieldAlert } from 'lucide-react';

interface TrendChartProps {
  visits: Visit[];
  initialParam?: 'spo2' | 'bp' | 'heart_rate' | 'temperature' | 'respiratory_rate' | 'blood_glucose' | 'hemoglobin';
}

type ParameterKey = 'spo2' | 'bp' | 'heart_rate' | 'temperature' | 'respiratory_rate' | 'blood_glucose' | 'hemoglobin';

export const TrendChart: React.FC<TrendChartProps> = ({ visits, initialParam = 'spo2' }) => {
  const { t } = useLanguage();
  const { isDark } = useTheme();
  const [selectedParam, setSelectedParam] = useState<ParameterKey>(initialParam);


  if (!visits || visits.length === 0) {
    return (
      <div className="p-8 text-center bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-dashed border-slate-300 dark:border-slate-800 text-slate-500">
        No visit records available for trend analysis.
      </div>
    );
  }

  // Sort visits chronologically (oldest to newest for plotting)
  const sortedVisits = [...visits].sort((a, b) => {
    const tA = new Date(`${a.date}T${a.time || '00:00'}`).getTime();
    const tB = new Date(`${b.date}T${b.time || '00:00'}`).getTime();
    return tA - tB;
  });

  const chartData = sortedVisits.map((v, index) => {
    const prev = index > 0 ? sortedVisits[index - 1] : null;
    const m = v.measurements;
    const prevM = prev ? prev.measurements : null;

    return {
      visitId: v.visit_id,
      date: v.date,
      time: v.time,
      displayDate: new Date(v.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      workerName: v.worker_name,
      location: v.location,
      spo2: m.spo2,
      spo2Delta: prevM ? m.spo2 - prevM.spo2 : 0,
      bp_systolic: m.bp_systolic,
      bp_diastolic: m.bp_diastolic,
      sysDelta: prevM ? m.bp_systolic - prevM.bp_systolic : 0,
      diaDelta: prevM ? m.bp_diastolic - prevM.bp_diastolic : 0,
      heart_rate: m.heart_rate,
      hrDelta: prevM ? m.heart_rate - prevM.heart_rate : 0,
      temperature: m.temperature,
      tempDelta: prevM ? (m.temperature - prevM.temperature).toFixed(1) : 0,
      respiratory_rate: m.respiratory_rate,
      rrDelta: prevM ? m.respiratory_rate - prevM.respiratory_rate : 0,
      blood_glucose: m.blood_glucose || null,
      glucoseDelta: prevM && m.blood_glucose && prevM.blood_glucose ? m.blood_glucose - prevM.blood_glucose : 0,
      hemoglobin: m.hemoglobin || null,
      hbDelta: prevM && m.hemoglobin && prevM.hemoglobin ? (m.hemoglobin - prevM.hemoglobin).toFixed(1) : 0,
    };
  });

  const paramConfigs: Record<
    ParameterKey,
    {
      title: string;
      unit: string;
      icon: React.ReactNode;
      color: string;
      secondaryColor?: string;
      normalMin?: number;
      normalMax?: number;
      yDomain?: [number, number];
      description: string;
    }
  > = {
    spo2: {
      title: t('spo2', 'Oxygen Saturation (SpO₂)'),
      unit: '%',
      icon: <Wind className="w-4 h-4 text-sky-500" />,
      color: '#0284c7', // Sky blue
      normalMin: 95,
      normalMax: 100,
      yDomain: [85, 100],
      description: 'Standard reference zone: 95% - 100%. Readings ≤ 93% indicate hypoxemia.',
    },
    bp: {
      title: t('bloodPressure', 'Blood Pressure (BP)'),
      unit: 'mmHg',
      icon: <Activity className="w-4 h-4 text-rose-500" />,
      color: '#e11d48', // Rose for Systolic
      secondaryColor: '#6366f1', // Indigo for Diastolic
      yDomain: [50, 190],
      description: 'Normal: <120/<80 mmHg. Stage 1: ≥140/90. Stage 2: ≥160/100 mmHg.',
    },
    heart_rate: {
      title: t('heartRate', 'Heart Rate (Pulse)'),
      unit: 'bpm',
      icon: <Heart className="w-4 h-4 text-emerald-500" />,
      color: '#10b981', // Emerald
      normalMin: 60,
      normalMax: 90,
      yDomain: [40, 130],
      description: 'Standard resting baseline: 60 - 90 bpm. Tachycardia: >100 bpm.',
    },
    temperature: {
      title: t('temperature', 'Body Temperature'),
      unit: '°F',
      icon: <Thermometer className="w-4 h-4 text-amber-500" />,
      color: '#f59e0b', // Amber
      normalMin: 97.5,
      normalMax: 99.0,
      yDomain: [96, 104],
      description: 'Normal: 97.5°F - 99.0°F. Febrile threshold: ≥100.4°F.',
    },
    respiratory_rate: {
      title: t('respiratoryRate', 'Respiratory Rate'),
      unit: 'breaths/min',
      icon: <Wind className="w-4 h-4 text-teal-500" />,
      color: '#14b8a6', // Teal
      normalMin: 12,
      normalMax: 20,
      yDomain: [8, 30],
      description: 'Normal adult resting: 12 - 20 breaths per minute.',
    },
    blood_glucose: {
      title: t('bloodGlucose', 'Blood Glucose'),
      unit: 'mg/dL',
      icon: <Droplets className="w-4 h-4 text-purple-500" />,
      color: '#9333ea', // Purple
      normalMin: 70,
      normalMax: 140,
      yDomain: [50, 300],
      description: 'Fasting: 70-100 mg/dL. Random normal: <140 mg/dL.',
    },
    hemoglobin: {
      title: t('hemoglobin', 'Hemoglobin'),
      unit: 'g/dL',
      icon: <Activity className="w-4 h-4 text-red-600" />,
      color: '#dc2626', // Red
      normalMin: 12.0,
      normalMax: 16.0,
      yDomain: [6, 18],
      description: 'Normal: 12 - 16 g/dL. Moderate anemia: 8 - 10.5 g/dL.',
    },
  };

  const currentConfig = paramConfigs[selectedParam];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
      {/* Parameter Selector Pills */}
      <div className="flex items-center justify-between flex-wrap gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            {currentConfig.icon}
            {currentConfig.title}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{currentConfig.description}</p>
        </div>

        <div className="flex flex-wrap gap-1.5 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-lg">
          {(Object.keys(paramConfigs) as ParameterKey[]).map((key) => {
            const cfg = paramConfigs[key];
            const isSelected = selectedParam === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => setSelectedParam(key)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                  isSelected
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {cfg.title.split(' ')[0]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Chart Canvas */}
      <div className="h-64 sm:h-72 w-full pt-4">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
            <CartesianGrid
              strokeDasharray="3 3"
              stroke={isDark ? '#334155' : '#e2e8f0'}
              vertical={false}
            />
            <XAxis
              dataKey="displayDate"
              tick={{ fontSize: 12, fill: isDark ? '#94a3b8' : '#64748b' }}
              tickLine={false}
              axisLine={{ stroke: isDark ? '#475569' : '#cbd5e1' }}
            />
            <YAxis
              domain={currentConfig.yDomain || ['auto', 'auto']}
              tick={{ fontSize: 12, fill: isDark ? '#94a3b8' : '#64748b' }}
              tickLine={false}
              axisLine={{ stroke: isDark ? '#475569' : '#cbd5e1' }}
              unit={` ${currentConfig.unit}`}
            />


            {/* Reference Normal Range Boundaries */}
            {currentConfig.normalMin !== undefined && (
              <ReferenceLine
                y={currentConfig.normalMin}
                stroke="#10b981"
                strokeDasharray="3 3"
                label={{ value: `Normal Min (${currentConfig.normalMin})`, fill: '#10b981', fontSize: 10 }}
              />
            )}
            {currentConfig.normalMax !== undefined && (
              <ReferenceLine
                y={currentConfig.normalMax}
                stroke="#10b981"
                strokeDasharray="3 3"
                label={{ value: `Normal Max (${currentConfig.normalMax})`, fill: '#10b981', fontSize: 10 }}
              />
            )}

            {selectedParam === 'bp' && (
              <>
                <ReferenceLine y={140} stroke="#f43f5e" strokeDasharray="3 3" label={{ value: 'Sys Limit 140', fill: '#f43f5e', fontSize: 10 }} />
                <ReferenceLine y={90} stroke="#6366f1" strokeDasharray="3 3" label={{ value: 'Dia Limit 90', fill: '#6366f1', fontSize: 10 }} />
              </>
            )}

            {selectedParam === 'spo2' && (
              <ReferenceLine y={93} stroke="#f43f5e" strokeDasharray="3 3" label={{ value: 'Hypoxemia ≤93%', fill: '#f43f5e', fontSize: 10 }} />
            )}

            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-slate-900 text-white text-xs p-3 rounded-lg shadow-xl border border-slate-700 min-w-44 z-50">
                      <div className="font-semibold text-slate-300 border-b border-slate-800 pb-1 mb-1.5 flex justify-between">
                        <span>{data.date} ({data.time})</span>
                        <span className="text-emerald-400">{data.location}</span>
                      </div>
                      
                      {selectedParam === 'bp' ? (
                        <div className="space-y-1">
                          <div className="flex justify-between text-rose-300 font-bold">
                            <span>Systolic BP:</span>
                            <span>{data.bp_systolic} mmHg {data.sysDelta !== 0 && `(Δ ${data.sysDelta > 0 ? '+' : ''}${data.sysDelta})`}</span>
                          </div>
                          <div className="flex justify-between text-indigo-300 font-bold">
                            <span>Diastolic BP:</span>
                            <span>{data.bp_diastolic} mmHg {data.diaDelta !== 0 && `(Δ ${data.diaDelta > 0 ? '+' : ''}${data.diaDelta})`}</span>
                          </div>
                        </div>
                      ) : (
                        <div className="flex justify-between font-bold text-white text-sm">
                          <span>{currentConfig.title}:</span>
                          <span>
                            {data[selectedParam]} {currentConfig.unit}
                          </span>
                        </div>
                      )}

                      <div className="mt-2 pt-1 border-t border-slate-800 text-[10px] text-slate-400">
                        Surveyor: {data.workerName}
                      </div>
                    </div>
                  );
                }
                return null;
              }}
            />

            {selectedParam === 'bp' ? (
              <>
                <Line
                  type="monotone"
                  dataKey="bp_systolic"
                  name="Systolic BP"
                  stroke="#e11d48"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#e11d48', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="bp_diastolic"
                  name="Diastolic BP"
                  stroke="#6366f1"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#6366f1', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 6 }}
                />
              </>
            ) : (
              <Line
                type="monotone"
                dataKey={selectedParam}
                stroke={currentConfig.color}
                strokeWidth={2.5}
                dot={{ r: 4, fill: currentConfig.color, strokeWidth: 2, stroke: '#fff' }}
                activeDot={{ r: 6 }}
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Trajectory Summary Delta Strip */}
      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-center gap-1.5">
          <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500/20 border border-emerald-500"></span>
          <span>Target Reference Band</span>
        </div>
        <div className="text-[11px] text-slate-500">
          Showing {sortedVisits.length} recorded community survey visits over time
        </div>
      </div>
    </div>
  );
};
