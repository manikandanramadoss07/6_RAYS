import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { useTheme } from '../../context/ThemeContext';
import { StorageService } from '../../services/storageService';
import {
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Stethoscope,
  MapPin,
  Phone,
  ShieldCheck,
  RotateCcw,
  Zap,
} from 'lucide-react';

interface SihDemoGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPatientForDoctor?: (patientId: string) => void;
}

export const SihDemoGuideModal: React.FC<SihDemoGuideModalProps> = ({
  isOpen,
  onClose,
  onSelectPatientForDoctor,
}) => {
  const { loginDoctor, loginSurveyor, loginPatientWithOtp, logout } = useAuth();
  const { setLanguage } = useLanguage();
  const { toggleTheme } = useTheme();

  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);

  if (!isOpen) return null;

  const demoSteps = [
    {
      step: 1,
      title: 'Authentication & Landing Screen',
      role: 'Public / All Roles',
      desc: 'Show professional Government of India Mission landing page with 3 distinct login pathways.',
      actionLabel: 'Go to Landing Screen',
      action: () => {
        logout();
        onClose();
      },
    },
    {
      step: 2,
      title: 'Login as Field Surveyor (ASHA Anita Devi)',
      role: 'Surveyor',
      desc: 'Field health worker enters credentials to access the touch-friendly mobile registration and survey pad.',
      actionLabel: '1-Click Surveyor Login',
      action: async () => {
        await loginSurveyor('asha.anita');
        onClose();
      },
    },
    {
      step: 3,
      title: 'Register New Patient (Auto ID: PAT-2026-011)',
      role: 'Surveyor',
      desc: 'Demonstrate registration form validation, auto-generated unique Patient ID, and village assignment.',
      actionLabel: 'Open Surveyor Dashboard',
      action: async () => {
        await loginSurveyor('asha.anita');
        onClose();
      },
    },
    {
      step: 4,
      title: 'Simulate Offline Survey & Sync Queue',
      role: 'Surveyor',
      desc: 'Toggle Offline Mode. Record visit data without internet connection; records accumulate in the local pending sync queue.',
      actionLabel: 'Enable Offline Mode & Open Surveyor',
      action: async () => {
        StorageService.setOfflineMode(true);
        await loginSurveyor('asha.anita');
        onClose();
      },
    },
    {
      step: 5,
      title: 'Restore Connectivity & Sync Records',
      role: 'Surveyor',
      desc: 'Switch to Online Mode and trigger batch sync to upload pending local field surveys to the Central PHC Server.',
      actionLabel: 'Restore Online & Sync',
      action: async () => {
        StorageService.setOfflineMode(false);
        await StorageService.processSyncQueue();
        await loginSurveyor('asha.anita');
        onClose();
      },
    },
    {
      step: 6,
      title: 'Doctor Login (Dr. Priya Sharma, MD)',
      role: 'Doctor',
      desc: 'Physician logs into secure clinical workspace featuring Clinical Review Queue and longitudinal analytics.',
      actionLabel: '1-Click Doctor Login',
      action: async () => {
        await loginDoctor('dr.priya');
        onClose();
      },
    },
    {
      step: 7,
      title: 'Open Lakshmi (PAT-2026-001) Longitudinal Record',
      role: 'Doctor',
      desc: 'Examine multi-visit history (Visit 1: BP 120/80, SpO₂ 96% → Visit 2: BP 140/90, SpO₂ 92% → Visit 3: BP 135/85, SpO₂ 94%).',
      actionLabel: 'Inspect Lakshmi’s Profile & Trends',
      action: async () => {
        await loginDoctor('dr.priya');
        if (onSelectPatientForDoctor) {
          onSelectPatientForDoctor('PAT-2026-001');
        }
        onClose();
      },
    },
    {
      step: 8,
      title: 'Evaluate Doctor-Only Clinical Risk Score (68/100)',
      role: 'Doctor Only',
      desc: 'View trend-based risk calculation: status "Requires Clinical Review" triggered by SpO₂ desaturation (↓), elevated BP (↑), and pulse variance (↑).',
      actionLabel: 'View Risk Score Breakdown',
      action: async () => {
        await loginDoctor('dr.priya');
        if (onSelectPatientForDoctor) {
          onSelectPatientForDoctor('PAT-2026-001');
        }
        onClose();
      },
    },
    {
      step: 9,
      title: 'Author Clinical Note & Mark Review Completed',
      role: 'Doctor',
      desc: 'Add doctor internal diagnostic notes and patient-facing diet/medication instructions.',
      actionLabel: 'Doctor Note Editor',
      action: async () => {
        await loginDoctor('dr.priya');
        if (onSelectPatientForDoctor) {
          onSelectPatientForDoctor('PAT-2026-001');
        }
        onClose();
      },
    },
    {
      step: 10,
      title: 'Patient Login via Mobile Number + OTP ONLY',
      role: 'Patient',
      desc: 'Demonstrate safe patient portal login with mobile (+91 9876543210) + OTP. Profile selection disambiguates shared family phones.',
      actionLabel: 'Login as Patient Lakshmi (OTP)',
      action: () => {
        loginPatientWithOtp('PAT-2026-001');
        onClose();
      },
    },
    {
      step: 11,
      title: 'Confirm Risk Score is Completely Hidden from Patient',
      role: 'Patient View',
      desc: 'Patient views simple, reassuring vital measurements and doctor guidance. No alarming risk percentages or clinical algorithms shown.',
      actionLabel: 'View Safe Patient Portal',
      action: () => {
        loginPatientWithOtp('PAT-2026-001');
        onClose();
      },
    },
    {
      step: 12,
      title: 'Switch Language (10 Indian Languages) & Themes',
      role: 'Accessibility',
      desc: 'Toggle between Hindi, Tamil, Telugu, Malayalam, Marathi, Urdu (RTL) and Light/Dark themes with full UI persistence.',
      actionLabel: 'Test Hindi + Dark Theme',
      action: () => {
        setLanguage('hi');
        onClose();
      },
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-indigo-700 to-indigo-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/15 rounded-lg">
              <Sparkles className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">SIH Live Presentation Walkthrough</h3>
              <p className="text-xs text-amber-100">
                Official Smart India Hackathon (SIH) 29-Step Longitudinal Workflow Scenario
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white text-sm px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Step Cards */}
        <div className="p-5 overflow-y-auto space-y-3 divide-y divide-slate-100 dark:divide-slate-800">
          <div className="pb-3 text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-200 dark:border-slate-700/60">
            <span className="font-bold text-slate-800 dark:text-slate-200">Core Evaluation Concept: </span>
            JeevaSetu bridges community health surveys into continuous longitudinal care with doctor-only risk scoring, rural offline-first sync, and 10 Indian languages.
          </div>

          {demoSteps.map((item, idx) => {
            return (
              <div key={item.step} className="pt-3 first:pt-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {item.step}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">{item.title}</h4>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                        {item.role}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{item.desc}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={item.action}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-600 hover:text-white transition-all shrink-0 flex items-center gap-1.5 self-end sm:self-center"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  <span>{item.actionLabel}</span>
                </button>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs text-slate-500">
          <span>Click any 1-click shortcut to test live application state</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-800 dark:text-slate-200 font-semibold"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
