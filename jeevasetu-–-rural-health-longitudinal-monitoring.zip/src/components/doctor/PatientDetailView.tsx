import React, { useState } from 'react';
import { Patient, Visit, ClinicalNote, ReviewStatus } from '../../types';
import { StorageService } from '../../services/storageService';
import { calculateDoctorRiskScore } from '../../services/riskEngine';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { TrendChart } from '../common/TrendChart';
import {
  ArrowLeft,
  ShieldAlert,
  Activity,
  Heart,
  Wind,
  Thermometer,
  Droplets,
  Calendar,
  User,
  MapPin,
  Clock,
  CheckCircle2,
  FileEdit,
  Lock,
  Eye,
  AlertTriangle,
  History,
  TrendingDown,
  TrendingUp,
  Minus,
} from 'lucide-react';

interface PatientDetailViewProps {
  patientId: string;
  onBack: () => void;
  onRefresh?: () => void;
}

export const PatientDetailView: React.FC<PatientDetailViewProps> = ({ patientId, onBack, onRefresh }) => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  const [patient, setPatient] = useState<Patient | undefined>(() => StorageService.getPatientById(patientId));
  const [visits, setVisits] = useState<Visit[]>(() => StorageService.getVisitsByPatientId(patientId));
  const [notes, setNotes] = useState<ClinicalNote[]>(() => StorageService.getClinicalNotes(patientId));

  // Note authoring state
  const [newDoctorNote, setNewDoctorNote] = useState<string>('');
  const [newPatientNote, setNewPatientNote] = useState<string>('');
  const [prescriptionAdvice, setPrescriptionAdvice] = useState<string>('');
  const [followUpDate, setFollowUpDate] = useState<string>('');
  const [selectedReviewStatus, setSelectedReviewStatus] = useState<ReviewStatus>(
    patient?.current_status || 'within_range'
  );
  const [savingNote, setSavingNote] = useState<boolean>(false);
  const [noteSuccess, setNoteSuccess] = useState<string>('');

  if (!patient) {
    return (
      <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <p className="text-slate-500">Patient not found with ID: {patientId}</p>
        <button
          type="button"
          onClick={onBack}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-semibold"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  // Calculate Doctor-Only Clinical Risk Score (Longitudinal)
  const riskAssessment = calculateDoctorRiskScore(visits);
  const latestVisit = visits[0] || null;
  const previousVisit = visits[1] || null;

  const handleSaveClinicalNotes = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setSavingNote(true);

    if (newDoctorNote.trim()) {
      StorageService.addClinicalNote(
        {
          note_id: `NOTE-DOC-${Date.now()}`,
          patient_id: patient.patient_id,
          doctor_id: currentUser.id,
          doctor_name: currentUser.name,
          note: newDoctorNote.trim(),
          visibility: 'doctor_only',
          review_status: selectedReviewStatus,
          created_at: new Date().toISOString(),
        },
        currentUser
      );
    }

    if (newPatientNote.trim() || prescriptionAdvice.trim()) {
      StorageService.addClinicalNote(
        {
          note_id: `NOTE-PAT-${Date.now()}`,
          patient_id: patient.patient_id,
          doctor_id: currentUser.id,
          doctor_name: currentUser.name,
          note: newPatientNote.trim() || 'Dietary & lifestyle guidance updated.',
          visibility: 'patient_visible',
          prescription_advice: prescriptionAdvice.trim(),
          followUpDate: followUpDate || undefined,
          review_status: selectedReviewStatus,
          created_at: new Date().toISOString(),
        },
        currentUser
      );
    }

    // Refresh state
    setPatient(StorageService.getPatientById(patientId));
    setNotes(StorageService.getClinicalNotes(patientId));
    setNewDoctorNote('');
    setNewPatientNote('');
    setPrescriptionAdvice('');
    setSavingNote(false);
    setNoteSuccess('Clinical notes saved and review status updated successfully.');
    setTimeout(() => setNoteSuccess(''), 4000);
    if (onRefresh) onRefresh();
  };

  const handleMarkReviewed = () => {
    if (!currentUser) return;
    StorageService.addClinicalNote(
      {
        note_id: `NOTE-REV-${Date.now()}`,
        patient_id: patient.patient_id,
        doctor_id: currentUser.id,
        doctor_name: currentUser.name,
        note: 'Clinical review completed by physician after evaluating longitudinal vital trends.',
        visibility: 'doctor_only',
        review_status: 'within_range',
        created_at: new Date().toISOString(),
      },
      currentUser
    );

    setPatient(StorageService.getPatientById(patientId));
    setNotes(StorageService.getClinicalNotes(patientId));
    setNoteSuccess('Marked as Reviewed. Patient status updated.');
    setTimeout(() => setNoteSuccess(''), 3000);
    if (onRefresh) onRefresh();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Breadcrumb & Action Bar */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t('back', 'Back to Patient List')}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleMarkReviewed}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{t('markReviewed', 'Mark Review Completed')}</span>
          </button>
        </div>
      </div>

      {noteSuccess && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{noteSuccess}</span>
        </div>
      )}

      {/* Patient Profile Master Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-4">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-xl ${
              patient.sex === 'Female' ? 'bg-pink-100 text-pink-700 dark:bg-pink-950 dark:text-pink-300' : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
            }`}>
              {patient.name.charAt(0)}
            </div>

            <div>
              <div className="flex items-center flex-wrap gap-2">
                <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">
                  {patient.name}
                </h1>
                <span className="font-mono text-xs font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {patient.patient_id}
                </span>
                <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${
                  patient.current_status === 'requires_review'
                    ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950 dark:text-rose-300 dark:border-rose-800'
                    : patient.current_status === 'trend_attention'
                    ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                    : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800'
                }`}>
                  {patient.current_status === 'requires_review' ? t('requiresReview', 'Requires Clinical Review') :
                   patient.current_status === 'trend_attention' ? t('trendAttention', 'Trend Requires Attention') :
                   t('withinRange', 'Within Configured Range')}
                </span>
              </div>

              <div className="flex items-center flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-slate-600 dark:text-slate-400">
                <span><strong>{t('age', 'Age')}:</strong> {patient.age} yrs • {patient.sex}</span>
                <span><strong>{t('mobileNumber', 'Mobile')}:</strong> +91 {patient.mobile}</span>
                <span><strong>{t('village', 'Village')}:</strong> {patient.village}, {patient.district}</span>
                <span><strong>{t('assignedWorker', 'ASHA')}:</strong> {patient.assigned_worker_name}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 border-t lg:border-t-0 lg:border-l border-slate-100 dark:border-slate-800 pt-3 lg:pt-0 lg:pl-6 text-xs text-slate-500">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">{t('registrationDate', 'Registered')}</div>
              <div className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{patient.registrationDate}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">{t('totalVisits', 'Total Visits')}</div>
              <div className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{visits.length} Recorded</div>
            </div>
          </div>
        </div>
      </div>

      {/* DOCTOR-ONLY CLINICAL RISK SCORE CARD (RESTRICTED TO CLINICIANS) */}
      <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 text-white rounded-2xl p-6 border border-indigo-700/50 shadow-xl relative overflow-hidden">
        {/* Security / Confidentiality Watermark */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-wide text-white">
                  {t('clinicalRiskScore', 'DOCTOR-ONLY CLINICAL RISK SCORE')}
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  RESTRICTED TO CLINICAL USERS
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Rule-based longitudinal trend evaluation. Transparently calculated from configured multi-visit community surveys.
              </p>
            </div>
          </div>

          <div className="text-right hidden sm:block">
            <div className="text-xs text-slate-400">Assessment Timestamp</div>
            <div className="text-xs font-mono font-semibold text-slate-300">{new Date(riskAssessment.calculated_at).toLocaleTimeString()}</div>
          </div>
        </div>

        {/* Score & Status Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-6 items-center">
          {/* Main Numeric Score */}
          <div className="flex items-center gap-4">
            <div className={`w-24 h-24 rounded-2xl flex flex-col items-center justify-center font-black text-3xl shadow-inner border ${
              riskAssessment.score >= 65
                ? 'bg-rose-950/80 text-rose-300 border-rose-700'
                : riskAssessment.score >= 40
                ? 'bg-amber-950/80 text-amber-300 border-amber-700'
                : 'bg-emerald-950/80 text-emerald-300 border-emerald-700'
            }`}>
              <span>{riskAssessment.score}</span>
              <span className="text-[10px] font-normal text-slate-400 tracking-wider">/ 100</span>
            </div>

            <div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Evaluation Status</div>
              <div className={`text-lg font-black mt-0.5 ${
                riskAssessment.score >= 65 ? 'text-rose-400' : riskAssessment.score >= 40 ? 'text-amber-400' : 'text-emerald-400'
              }`}>
                {riskAssessment.status}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {riskAssessment.is_longitudinal ? 'Longitudinal Multi-Visit Model' : 'Single Visit Baseline'}
              </div>
            </div>
          </div>

          {/* Trend Indicators (e.g. SpO2 ↓, Heart Rate ↑, BP ↑) */}
          <div className="md:col-span-2 bg-slate-900/90 rounded-xl p-4 border border-slate-800 space-y-2">
            <div className="text-xs font-bold text-slate-300 flex items-center justify-between">
              <span>{t('trendIndicators', 'Longitudinal Trend Indicators')}:</span>
              <span className="text-[11px] text-slate-400">{visits.length} Visits Analyzed</span>
            </div>

            <div className="flex flex-wrap gap-2">
              {riskAssessment.trend_indicators.length > 0 ? (
                riskAssessment.trend_indicators.map((ind, idx) => (
                  <div
                    key={idx}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 border ${
                      ind.severity === 'high'
                        ? 'bg-rose-950/80 text-rose-200 border-rose-800'
                        : ind.severity === 'moderate'
                        ? 'bg-amber-950/80 text-amber-200 border-amber-800'
                        : 'bg-slate-800 text-slate-200 border-slate-700'
                    }`}
                  >
                    {ind.direction === 'up' && <TrendingUp className="w-3.5 h-3.5 text-rose-400" />}
                    {ind.direction === 'down' && <TrendingDown className="w-3.5 h-3.5 text-amber-400" />}
                    {ind.direction === 'stable' && <Minus className="w-3.5 h-3.5 text-emerald-400" />}
                    <span>{ind.parameter}</span>
                    <span className="text-[11px] opacity-80">({ind.note})</span>
                  </div>
                ))
              ) : (
                <div className="text-xs text-emerald-400 font-medium">
                  ✓ Vital trajectories show stable physiological trends across recorded survey visits.
                </div>
              )}
            </div>

            {/* Contributing Rationale */}
            <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-300">
              <strong>Clinical Rationale: </strong>
              {riskAssessment.contributing_factors.join('; ')}
            </div>
          </div>
        </div>

        {/* Rule Breakdown Table */}
        {riskAssessment.rule_breakdown.length > 0 && (
          <div className="mt-2 pt-3 border-t border-slate-800 text-xs">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Configured Rule Points Breakdown
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {riskAssessment.rule_breakdown.map((rb, idx) => (
                <div key={idx} className="p-2 rounded-lg bg-slate-900/60 border border-slate-800 flex items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold text-slate-200">{rb.factor}</div>
                    <div className="text-[11px] text-slate-400">{rb.reason}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-mono font-bold text-xs shrink-0">
                    +{rb.points} pts
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Medical Disclaimer on Score */}
        <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 italic">
          "Risk score is generated from configured measurement trends and is intended to support clinical review. It is not an autonomous diagnosis. The score is strictly hidden from patient portal views."
        </div>
      </div>

      {/* LONGITUDINAL TREND VISUALIZATION */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-indigo-600" />
              <span>{t('trends', 'Longitudinal Trend Visualization')}</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Interactive temporal tracking of biomedical parameters across consecutive community visits.
            </p>
          </div>
        </div>

        <TrendChart visits={visits} initialParam="spo2" />
      </div>

      {/* LATEST VS PREVIOUS VISIT DELTA CARDS */}
      {latestVisit && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
          {/* BP */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span className="font-bold flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-rose-500" />
                {t('bloodPressure', 'Blood Pressure')}
              </span>
              <span className="text-[10px]">mmHg</span>
            </div>
            <div className="text-xl font-extrabold text-slate-900 dark:text-white">
              {latestVisit.measurements.bp_systolic}/{latestVisit.measurements.bp_diastolic}
            </div>
            {previousVisit && (
              <div className="text-[11px] text-slate-500 mt-1">
                Prev: {previousVisit.measurements.bp_systolic}/{previousVisit.measurements.bp_diastolic}
                <span className={`ml-1 font-semibold ${
                  latestVisit.measurements.bp_systolic > previousVisit.measurements.bp_systolic ? 'text-rose-600' : 'text-emerald-600'
                }`}>
                  (Δ {latestVisit.measurements.bp_systolic - previousVisit.measurements.bp_systolic > 0 ? '+' : ''}
                  {latestVisit.measurements.bp_systolic - previousVisit.measurements.bp_systolic})
                </span>
              </div>
            )}
          </div>

          {/* SpO2 */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span className="font-bold flex items-center gap-1">
                <Wind className="w-3.5 h-3.5 text-sky-500" />
                {t('spo2', 'SpO₂')}
              </span>
              <span className="text-[10px]">%</span>
            </div>
            <div className={`text-xl font-extrabold ${latestVisit.measurements.spo2 <= 93 ? 'text-rose-600' : 'text-slate-900 dark:text-white'}`}>
              {latestVisit.measurements.spo2}%
            </div>
            {previousVisit && (
              <div className="text-[11px] text-slate-500 mt-1">
                Prev: {previousVisit.measurements.spo2}%
                <span className={`ml-1 font-semibold ${
                  latestVisit.measurements.spo2 < previousVisit.measurements.spo2 ? 'text-rose-600' : 'text-emerald-600'
                }`}>
                  (Δ {latestVisit.measurements.spo2 - previousVisit.measurements.spo2}%)
                </span>
              </div>
            )}
          </div>

          {/* Heart Rate */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span className="font-bold flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 text-emerald-500" />
                {t('heartRate', 'Heart Rate')}
              </span>
              <span className="text-[10px]">bpm</span>
            </div>
            <div className="text-xl font-extrabold text-slate-900 dark:text-white">
              {latestVisit.measurements.heart_rate} bpm
            </div>
            {previousVisit && (
              <div className="text-[11px] text-slate-500 mt-1">
                Prev: {previousVisit.measurements.heart_rate} bpm
                <span className={`ml-1 font-semibold ${
                  latestVisit.measurements.heart_rate > previousVisit.measurements.heart_rate ? 'text-rose-600' : 'text-emerald-600'
                }`}>
                  (Δ {latestVisit.measurements.heart_rate - previousVisit.measurements.heart_rate > 0 ? '+' : ''}
                  {latestVisit.measurements.heart_rate - previousVisit.measurements.heart_rate})
                </span>
              </div>
            )}
          </div>

          {/* Temperature & Glucose */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
              <span className="font-bold flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-amber-500" />
                {t('temperature', 'Temp')} / Glucose
              </span>
              <span className="text-[10px]">°F</span>
            </div>
            <div className="text-xl font-extrabold text-slate-900 dark:text-white">
              {latestVisit.measurements.temperature}°F
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Glucose: {latestVisit.measurements.blood_glucose ? `${latestVisit.measurements.blood_glucose} mg/dL` : 'Not tested'}
            </div>
          </div>
        </div>
      )}

      {/* CHRONOLOGICAL VISIT HISTORY LIST */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <History className="w-5 h-5 text-indigo-600" />
              <span>{t('previousVisits', 'Chronological Visit History')}</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Never overwritten. Every field survey creates a distinct, time-stamped visit record.
            </p>
          </div>
        </div>

        <div className="space-y-4 mt-4">
          {visits.map((v, index) => (
            <div
              key={v.visit_id}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 hover:border-indigo-300 transition-all"
            >
              <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-slate-200/60 dark:border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                    Visit #{visits.length - index} ({v.visit_id})
                  </span>
                  <span className="text-xs text-slate-500">
                    📅 {v.date} at {v.time}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-500 font-medium">📍 {v.location}</span>
                  <span className="text-slate-400">•</span>
                  <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                    Surveyor: {v.worker_name}
                  </span>
                </div>
              </div>

              {/* Grid of Measurements for this Visit */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 pt-3 text-xs">
                <div>
                  <div className="text-slate-400 text-[10px]">Blood Pressure</div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    {v.measurements.bp_systolic}/{v.measurements.bp_diastolic} mmHg
                  </div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">SpO₂ Saturation</div>
                  <div className={`font-bold ${v.measurements.spo2 <= 93 ? 'text-rose-600' : 'text-slate-800 dark:text-slate-200'}`}>
                    {v.measurements.spo2}%
                  </div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Heart Rate</div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    {v.measurements.heart_rate} bpm
                  </div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Temperature</div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    {v.measurements.temperature}°F
                  </div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Resp Rate</div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    {v.measurements.respiratory_rate} /min
                  </div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">Blood Glucose</div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">
                    {v.measurements.blood_glucose ? `${v.measurements.blood_glucose} mg/dL` : 'N/A'}
                  </div>
                </div>
              </div>

              {v.notes && (
                <div className="mt-2 pt-2 border-t border-slate-200/50 dark:border-slate-700/50 text-xs text-slate-600 dark:text-slate-400">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Field Worker Notes: </span>
                  {v.notes}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* CLINICAL NOTES AUTHORING & RECORD MANAGEMENT */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Author New Notes Form */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-1">
            <FileEdit className="w-5 h-5 text-indigo-600" />
            <span>{t('addClinicalNote', 'Author Clinical Evaluation & Guidance')}</span>
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Supports both physician-internal notes and patient-facing health instructions.
          </p>

          <form onSubmit={handleSaveClinicalNotes} className="space-y-4">
            {/* Status Update Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Set Clinical Review Status
              </label>
              <select
                value={selectedReviewStatus}
                onChange={(e) => setSelectedReviewStatus(e.target.value as ReviewStatus)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              >
                <option value="within_range">Within Configured Range (Stable)</option>
                <option value="trend_attention">Trend Requires Attention</option>
                <option value="requires_review">Requires Clinical Review (Active Attention)</option>
              </select>
            </div>

            {/* Doctor Internal Note */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5 text-rose-500" />
                  {t('doctorInternalNote', 'Doctor Internal Note (Restricted to Clinicians)')}
                </span>
                <span className="text-[10px] text-slate-400">Patients CANNOT see this</span>
              </label>
              <textarea
                rows={3}
                value={newDoctorNote}
                onChange={(e) => setNewDoctorNote(e.target.value)}
                placeholder="e.g. Longitudinal SpO2 drop and elevated systolic BP. Recommended 2D Echo and adjust ACE inhibitor dosage..."
                className="w-full p-3 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            {/* Patient-Facing Guidance */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-sky-500" />
                  {t('patientVisibleNote', 'Patient-Facing Health Advice (Visible to Patient)')}
                </span>
                <span className="text-[10px] text-slate-400">Displayed in Patient Portal</span>
              </label>
              <textarea
                rows={2}
                value={newPatientNote}
                onChange={(e) => setNewPatientNote(e.target.value)}
                placeholder="e.g. Please take prescribed medicines after breakfast. Reduce daily salt intake and visit PHC on Tuesday..."
                className="w-full p-3 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Prescription / Diet Advice
                </label>
                <input
                  type="text"
                  value={prescriptionAdvice}
                  onChange={(e) => setPrescriptionAdvice(e.target.value)}
                  placeholder="e.g. Tab Amlodipine 5mg OD"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Next Follow-up Date
                </label>
                <input
                  type="date"
                  value={followUpDate}
                  onChange={(e) => setFollowUpDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={savingNote}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md shadow-indigo-600/20 transition-all"
            >
              {savingNote ? 'Saving Record...' : t('saveNote', 'Save Clinical Evaluation')}
            </button>
          </form>
        </div>

        {/* 2. Existing Notes History */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col">
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
            {t('clinicalNotes', 'Clinical Records & Notes Log')}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Auditable history of doctor consultations and advice.
          </p>

          <div className="flex-1 overflow-y-auto space-y-3 max-h-96">
            {notes.length > 0 ? (
              notes.map((n) => (
                <div
                  key={n.note_id}
                  className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
                    n.visibility === 'doctor_only'
                      ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/40'
                      : 'bg-sky-50/50 dark:bg-sky-950/20 border-sky-200 dark:border-sky-900/40'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] font-bold">
                    <span className={`flex items-center gap-1 ${
                      n.visibility === 'doctor_only' ? 'text-rose-700 dark:text-rose-300' : 'text-sky-700 dark:text-sky-300'
                    }`}>
                      {n.visibility === 'doctor_only' ? <Lock className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      {n.visibility === 'doctor_only' ? 'Doctor Internal Note' : 'Patient Visible Advice'}
                    </span>
                    <span className="text-slate-400 font-normal">
                      {new Date(n.created_at).toLocaleDateString()} at {new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <p className="text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                    {n.note}
                  </p>

                  {n.prescription_advice && (
                    <div className="text-[11px] text-emerald-700 dark:text-emerald-300 font-semibold pt-1 border-t border-slate-200 dark:border-slate-800">
                      Prescription: {n.prescription_advice}
                    </div>
                  )}

                  <div className="text-[10px] text-slate-500 flex justify-between pt-1">
                    <span>By: {n.doctor_name}</span>
                    {n.follow_up_date && <span>Follow-up: {n.follow_up_date}</span>}
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400 text-xs">
                No clinical notes recorded yet for this patient.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
