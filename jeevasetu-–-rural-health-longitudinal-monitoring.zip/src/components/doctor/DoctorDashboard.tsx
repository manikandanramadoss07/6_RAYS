import React, { useState, useMemo } from 'react';
import { Patient, DashboardStats } from '../../types';
import { StorageService } from '../../services/storageService';
import { calculateDoctorRiskScore } from '../../services/riskEngine';
import { useLanguage } from '../../i18n/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { PatientDetailView } from './PatientDetailView';
import {
  Users,
  Search,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Activity,
  ArrowRight,
  Filter,
  Stethoscope,
  ChevronRight,
  Sparkles,
  Phone,
  Calendar,
} from 'lucide-react';

interface DoctorDashboardProps {
  selectedPatientId?: string | null;
  onClearSelectedPatient?: () => void;
}

export const DoctorDashboard: React.FC<DoctorDashboardProps> = ({
  selectedPatientId: propPatientId,
  onClearSelectedPatient,
}) => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(propPatientId || null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [villageFilter, setVillageFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [stats, setStats] = useState<DashboardStats>(() => StorageService.getDashboardStats());
  const [patients, setPatients] = useState<Patient[]>(() => StorageService.getPatients());

  const refreshData = () => {
    setStats(StorageService.getDashboardStats());
    setPatients(StorageService.getPatients());
  };

  // Compute live clinical review queue with risk scores
  const patientsWithRisk = useMemo(() => {
    return patients.map((p) => {
      const pVisits = StorageService.getVisitsByPatientId(p.patient_id);
      const risk = calculateDoctorRiskScore(pVisits);
      return {
        ...p,
        riskScore: risk.score,
        riskStatus: risk.status,
        trendIndicators: risk.trend_indicators,
        visitsCount: pVisits.length,
        latestVisit: pVisits[0] || null,
      };
    });
  }, [patients]);

  // Unique villages for filter
  const villages = useMemo(() => {
    const set = new Set(patients.map((p) => p.village));
    return Array.from(set);
  }, [patients]);

  // Filtered patients
  const filteredPatients = useMemo(() => {
    return patientsWithRisk.filter((p) => {
      // Search match
      const q = searchQuery.toLowerCase().trim();
      const cleanMobile = searchQuery.replace(/\D/g, '');
      const matchSearch =
        !q ||
        p.patient_id.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        p.village.toLowerCase().includes(q) ||
        (cleanMobile && p.mobile.includes(cleanMobile));

      // Village match
      const matchVillage = villageFilter === 'all' || p.village === villageFilter;

      // Status match
      const matchStatus =
        statusFilter === 'all' ||
        (statusFilter === 'review' && (p.riskScore >= 65 || p.current_status === 'requires_review')) ||
        (statusFilter === 'attention' && (p.riskScore >= 40 && p.riskScore < 65 || p.current_status === 'trend_attention')) ||
        (statusFilter === 'normal' && p.riskScore < 40);

      return matchSearch && matchVillage && matchStatus;
    });
  }, [patientsWithRisk, searchQuery, villageFilter, statusFilter]);

  // Priority Clinical Review Queue (Score >= 40)
  const clinicalReviewQueue = useMemo(() => {
    return [...patientsWithRisk]
      .filter((p) => p.riskScore >= 40 || p.current_status === 'requires_review')
      .sort((a, b) => b.riskScore - a.riskScore);
  }, [patientsWithRisk]);

  if (selectedPatientId) {
    return (
      <PatientDetailView
        patientId={selectedPatientId}
        onBack={() => {
          setSelectedPatientId(null);
          if (onClearSelectedPatient) onClearSelectedPatient();
          refreshData();
        }}
        onRefresh={refreshData}
      />
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-indigo-700/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs font-semibold mb-2">
              <Stethoscope className="w-3.5 h-3.5" />
              <span>{currentUser?.specialization || 'Clinical Review Dashboard'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {currentUser?.name || 'Dr. Priya Sharma'}
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200 mt-1">
              {currentUser?.facility || 'Rampur Primary Health Centre'} • Longitudinal Rural Health Evaluation
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-right bg-white/10 backdrop-blur-xs px-4 py-2 rounded-xl border border-white/10">
              <div className="text-[11px] text-indigo-200 font-semibold uppercase tracking-wider">Active Clinical Queue</div>
              <div className="text-xl font-black text-rose-300">
                {stats.requiresReviewCount + stats.trendAttentionCount} Patients
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* METRIC STATS CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold">{t('totalPatients', 'Total Patients')}</span>
            <Users className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {stats.totalPatients}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Under community monitoring</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-rose-200 dark:border-rose-900/60 shadow-xs">
          <div className="flex items-center justify-between text-xs text-rose-600 mb-1">
            <span className="font-bold">{t('requiresReview', 'Requires Review')}</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400">
            {stats.requiresReviewCount}
          </div>
          <div className="text-[11px] text-rose-500 font-medium mt-1">High risk trajectory score</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-amber-200 dark:border-amber-900/60 shadow-xs">
          <div className="flex items-center justify-between text-xs text-amber-600 mb-1">
            <span className="font-bold">{t('trendAttention', 'Trend Attention')}</span>
            <TrendingUp className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400">
            {stats.trendAttentionCount}
          </div>
          <div className="text-[11px] text-amber-500 font-medium mt-1">Sub-optimal vital trajectory</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span className="font-semibold">{t('totalVisits', 'Total Field Surveys')}</span>
            <Activity className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {stats.totalVisits}
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-1">
            All records synchronized
          </div>
        </div>
      </div>

      {/* CLINICAL REVIEW PRIORITY QUEUE (DOCTOR ONLY) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between flex-wrap gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                Clinical Review Priority Queue
              </h2>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                {clinicalReviewQueue.length} Pending
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Ranked by doctor-only longitudinal clinical risk score algorithm.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 mt-4">
          {clinicalReviewQueue.slice(0, 6).map((p) => (
            <div
              key={p.patient_id}
              onClick={() => setSelectedPatientId(p.patient_id)}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800 transition-all cursor-pointer shadow-xs group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                    {p.patient_id}
                  </span>

                  {/* Doctor-Only Risk Score Badge */}
                  <div className={`px-2.5 py-0.5 rounded-full font-bold text-xs flex items-center gap-1 border ${
                    p.riskScore >= 65
                      ? 'bg-rose-100 text-rose-800 border-rose-300 dark:bg-rose-950 dark:text-rose-300 dark:border-rose-800'
                      : 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                  }`}>
                    <span>Risk: {p.riskScore}/100</span>
                  </div>
                </div>

                <div className="mt-2.5">
                  <div className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                    {p.name}
                  </div>
                  <div className="text-xs text-slate-500">
                    {p.age} yrs • {p.sex} • Village: {p.village}
                  </div>
                </div>

                {/* Latest Vitals Strip */}
                {p.latestVisit && (
                  <div className="mt-3 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-[11px] grid grid-cols-3 text-center">
                    <div>
                      <div className="text-slate-400">BP</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200">
                        {p.latestVisit.measurements.bp_systolic}/{p.latestVisit.measurements.bp_diastolic}
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-400">SpO₂</div>
                      <div className={`font-bold ${p.latestVisit.measurements.spo2 <= 93 ? 'text-rose-600' : 'text-slate-800 dark:text-slate-200'}`}>
                        {p.latestVisit.measurements.spo2}%
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-400">Heart Rate</div>
                      <div className="font-bold text-slate-800 dark:text-slate-200">
                        {p.latestVisit.measurements.heart_rate} bpm
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                <span>{p.visitsCount} Longitudinal Visits</span>
                <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  Review <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* PATIENT SEARCH & COMPLETE ROSTER */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
              {t('patients', 'Longitudinal Patient Directory')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Search by Patient ID (e.g. PAT-2026-001), Name, or Mobile Number (multi-patient phone search supported).
            </p>
          </div>

          {/* Search Bar & Filters */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search Input */}
            <div className="relative min-w-64">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('searchPlaceholder', 'Search ID, name, or phone...')}
                className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            {/* Village Filter */}
            <select
              value={villageFilter}
              onChange={(e) => setVillageFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">All Villages</option>
              {villages.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">All Statuses</option>
              <option value="review">Requires Review (Risk ≥ 65)</option>
              <option value="attention">Trend Attention (Risk 40-64)</option>
              <option value="normal">Within Range (Risk &lt; 40)</option>
            </select>
          </div>
        </div>

        {/* Patients Table */}
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-3.5 rounded-l-lg">{t('patientId', 'Patient ID')}</th>
                <th className="py-3 px-3.5">{t('fullName', 'Patient Name')}</th>
                <th className="py-3 px-3.5">{t('age', 'Age / Sex')}</th>
                <th className="py-3 px-3.5">{t('village', 'Village')}</th>
                <th className="py-3 px-3.5">{t('mobileNumber', 'Mobile Number')}</th>
                <th className="py-3 px-3.5">Latest Vitals</th>
                <th className="py-3 px-3.5">Clinical Risk</th>
                <th className="py-3 px-3.5 text-right rounded-r-lg">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredPatients.length > 0 ? (
                filteredPatients.map((p) => (
                  <tr
                    key={p.patient_id}
                    onClick={() => setSelectedPatientId(p.patient_id)}
                    className="hover:bg-indigo-50/40 dark:hover:bg-indigo-950/20 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-3.5 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {p.patient_id}
                    </td>
                    <td className="py-3 px-3.5 font-bold text-slate-900 dark:text-white">
                      {p.name}
                    </td>
                    <td className="py-3 px-3.5 text-slate-600 dark:text-slate-300">
                      {p.age} yrs • {p.sex}
                    </td>
                    <td className="py-3 px-3.5 text-slate-600 dark:text-slate-300">
                      {p.village}
                    </td>
                    <td className="py-3 px-3.5 text-slate-500 font-mono">
                      +91 {p.mobile}
                    </td>
                    <td className="py-3 px-3.5">
                      {p.latestVisit ? (
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          BP {p.latestVisit.measurements.bp_systolic}/{p.latestVisit.measurements.bp_diastolic} • SpO₂ {p.latestVisit.measurements.spo2}%
                        </span>
                      ) : (
                        <span className="text-slate-400">No visits</span>
                      )}
                    </td>
                    <td className="py-3 px-3.5">
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[11px] border ${
                        p.riskScore >= 65
                          ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950 dark:text-rose-300 dark:border-rose-800'
                          : p.riskScore >= 40
                          ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800'
                      }`}>
                        {p.riskScore}/100 • {p.riskScore >= 65 ? 'Review Needed' : p.riskScore >= 40 ? 'Attention' : 'Within Range'}
                      </span>
                    </td>
                    <td className="py-3 px-3.5 text-right">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPatientId(p.patient_id);
                        }}
                        className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-600 hover:text-white transition-all"
                      >
                        {t('viewDetails', 'Evaluate')}
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No matching patient records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
