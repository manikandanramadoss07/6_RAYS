import React, { useState } from 'react';
import { StorageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { calculateDoctorRiskScore } from '../../services/riskEngine';
import {
  ShieldCheck,
  Building,
  Users,
  Activity,
  AlertTriangle,
  RefreshCw,
  FileCheck2,
  MapPin,
  Clock,
  RotateCcw,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  const [stats, setStats] = useState(() => StorageService.getDashboardStats());
  const [patients, setPatients] = useState(() => StorageService.getPatients());
  const [auditLogs, setAuditLogs] = useState(() => StorageService.getAuditLogs());
  const [resetMessage, setResetMessage] = useState<string>('');

  const refresh = () => {
    setStats(StorageService.getDashboardStats());
    setPatients(StorageService.getPatients());
    setAuditLogs(StorageService.getAuditLogs());
  };

  const handleResetDemoData = () => {
    if (confirm('Are you sure you want to reset all data back to the default SIH demonstration baseline?')) {
      StorageService.resetDemoData();
      refresh();
      setResetMessage('Database reset to SIH demo seed baseline successfully.');
      setTimeout(() => setResetMessage(''), 4000);
    }
  };

  // Village summary
  const villageSummary = [
    { village: 'Rampur', patients: 4, highRisk: 2, worker: 'Anita Devi (ASHA)', phc: 'Rampur PHC' },
    { village: 'Sitapur', patients: 3, highRisk: 1, worker: 'Sunita Rawat (ASHA)', phc: 'Rampur PHC' },
    { village: 'Madhopur', patients: 2, highRisk: 0, worker: 'Ramesh Kumar (HW)', phc: 'Rampur PHC' },
    { village: 'Kalyanpur', patients: 2, highRisk: 1, worker: 'Pooja Verma (ASHA)', phc: 'Rampur PHC' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-800 via-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-md border border-amber-600/30">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-200 text-xs font-semibold mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Block Health Supervisory Administration</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {currentUser?.name || 'Dr. Murthy (Block Medical Officer)'}
            </h1>
            <p className="text-xs sm:text-sm text-amber-200 mt-1">
              Sector: {currentUser?.facility || 'Varanasi District Block A'} • Comprehensive Longitudinal Care Administration
            </p>
          </div>

          <button
            type="button"
            onClick={handleResetDemoData}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-600/90 hover:bg-rose-700 text-white flex items-center gap-1.5 self-start sm:self-auto shadow-xs"
            title="Reset database to default state"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo Baseline</span>
          </button>
        </div>
      </div>

      {resetMessage && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl flex items-center gap-2">
          <FileCheck2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{resetMessage}</span>
        </div>
      )}

      {/* METRIC ROW */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="text-xs text-slate-500 font-semibold mb-1">Total Registered Patients</div>
          <div className="text-2xl font-black text-slate-900 dark:text-white">{stats.totalPatients}</div>
          <div className="text-[11px] text-slate-400 mt-1">Across 4 rural villages</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="text-xs text-slate-500 font-semibold mb-1">Total Completed Surveys</div>
          <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">{stats.totalVisits}</div>
          <div className="text-[11px] text-slate-400 mt-1">Continuous longitudinal tracking</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-rose-200 dark:border-rose-900/50 shadow-xs">
          <div className="text-xs text-rose-600 font-bold mb-1">Clinical Risk Alerts</div>
          <div className="text-2xl font-black text-rose-600 dark:text-rose-400">
            {stats.requiresReviewCount + stats.trendAttentionCount}
          </div>
          <div className="text-[11px] text-rose-500 mt-1">Requiring physician review</div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/50 shadow-xs">
          <div className="text-xs text-emerald-600 font-bold mb-1">Central Sync Integrity</div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
            {stats.syncPendingCount === 0 ? '100% Synced' : `${stats.syncPendingCount} Pending`}
          </div>
          <div className="text-[11px] text-emerald-500 mt-1">Offline-first enabled</div>
        </div>
      </div>

      {/* VILLAGE-WISE SUMMARY */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <h3 className="text-base font-extrabold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-indigo-600" />
          <span>Village Sector Monitoring & Health Worker Coverage</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-3.5 rounded-l-lg">Village</th>
                <th className="py-3 px-3.5">PHC Unit</th>
                <th className="py-3 px-3.5">Registered Villagers</th>
                <th className="py-3 px-3.5">High Risk Flagged</th>
                <th className="py-3 px-3.5 rounded-r-lg">Assigned ASHA / HW</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {villageSummary.map((v, i) => (
                <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                  <td className="py-3 px-3.5 font-bold text-slate-900 dark:text-white">{v.village}</td>
                  <td className="py-3 px-3.5 text-slate-600 dark:text-slate-400">{v.phc}</td>
                  <td className="py-3 px-3.5 font-semibold text-slate-800 dark:text-slate-200">{v.patients}</td>
                  <td className="py-3 px-3.5">
                    <span className="px-2 py-0.5 rounded-full font-bold text-[11px] bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
                      {v.highRisk} Alerts
                    </span>
                  </td>
                  <td className="py-3 px-3.5 text-slate-700 dark:text-slate-300 font-medium">{v.worker}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SYSTEM AUDIT TRAIL */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <h3 className="text-base font-extrabold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-indigo-600" />
          <span>System Audit Trail & Synchronization Logs</span>
        </h3>

        <div className="space-y-2 max-h-72 overflow-y-auto">
          {auditLogs.map((log) => (
            <div
              key={log.log_id}
              className="p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/30 text-xs flex items-center justify-between gap-3"
            >
              <div>
                <div className="font-semibold text-slate-800 dark:text-slate-200">
                  <span className="font-mono text-indigo-600 dark:text-indigo-400 mr-2">[{log.action}]</span>
                  {log.details}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Actor: <strong>{log.actor_name}</strong> ({log.actor_role}) {log.patient_id ? `• Patient: ${log.patient_id}` : ''}
                </div>
              </div>
              <div className="text-[10px] text-slate-400 shrink-0">
                {new Date(log.timestamp).toLocaleTimeString()}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
