import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { useTheme, ThemeMode } from '../../context/ThemeContext';
import { StorageService } from '../../services/storageService';
import {
  Globe,
  Sun,
  Moon,
  Laptop,
  LogOut,
  Wifi,
  WifiOff,
  RefreshCw,
  Sparkles,
  User as UserIcon,
  ShieldCheck,
  Building2,
  Stethoscope,
  MapPin,
  Check,
} from 'lucide-react';
import { LanguageCode } from '../../types';

interface HeaderProps {
  onOpenSihDemoGuide?: () => void;
  onSyncTriggered?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSihDemoGuide, onSyncTriggered }) => {
  const { currentUser, currentPatient, role, logout } = useAuth();
  const { language, setLanguage, languages, t } = useLanguage();
  const { theme, isDark, setTheme, toggleTheme } = useTheme();

  const [isOffline, setIsOffline] = useState<boolean>(() => StorageService.isOfflineMode());
  const [syncing, setSyncing] = useState<boolean>(false);
  const [syncQueueCount, setSyncQueueCount] = useState<number>(() => StorageService.getSyncQueue().length);
  const [showLangMenu, setShowLangMenu] = useState<boolean>(false);
  const [showThemeMenu, setShowThemeMenu] = useState<boolean>(false);

  const toggleOfflineState = () => {
    const nextState = !isOffline;
    setIsOffline(nextState);
    StorageService.setOfflineMode(nextState);
  };

  const handleManualSync = async () => {
    if (syncing) return;
    setSyncing(true);
    try {
      await StorageService.processSyncQueue();
      setSyncQueueCount(0);
      if (onSyncTriggered) onSyncTriggered();
    } catch (err) {
      console.error('Sync failed', err);
    } finally {
      setSyncing(false);
    }
  };

  const getRoleBadge = () => {
    switch (role) {
      case 'doctor':
        return {
          label: t('doctor', 'Doctor'),
          bg: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800',
          icon: <Stethoscope className="w-3.5 h-3.5 mr-1" />,
        };
      case 'surveyor':
        return {
          label: t('surveyor', 'Health Worker'),
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
          icon: <MapPin className="w-3.5 h-3.5 mr-1" />,
        };
      case 'patient':
        return {
          label: t('patient', 'Patient'),
          bg: 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950/60 dark:text-sky-300 dark:border-sky-800',
          icon: <UserIcon className="w-3.5 h-3.5 mr-1" />,
        };
      case 'admin':
        return {
          label: t('admin', 'Supervisor'),
          bg: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800',
          icon: <ShieldCheck className="w-3.5 h-3.5 mr-1" />,
        };
      default:
        return null;
    }
  };

  const roleBadge = getRoleBadge();

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 shadow-xs">
      {/* Top Government Tricolor Stripe */}
      <div className="h-1 w-full bg-gradient-to-r from-amber-500 via-white to-emerald-600"></div>

      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Government Mission Branding */}
          <div className="flex items-center gap-3">
            {/* Emblem / Bridge Icon */}
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-indigo-700 to-indigo-900 text-white flex items-center justify-center shadow-md shadow-indigo-900/20 border border-indigo-500/30 shrink-0">
              <Building2 className="w-5 h-5 sm:w-6 sm:h-6 text-amber-300" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-slate-900 dark:text-white">
                  {t('appName', 'JeevaSetu')}
                </span>
                <span className="hidden md:inline-block text-[11px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                  {t('govMission', 'Government of India Mission')}
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium line-clamp-1">
                {t('tagline', 'Bridging Community Health to Continuous Care.')}
              </p>
            </div>
          </div>

          {/* Controls: Offline Toggle, Sync, Language, Theme, Role Profile, Logout */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* SIH 29-Step Interactive Live Demo Trigger */}
            {onOpenSihDemoGuide && (
              <button
                type="button"
                onClick={onOpenSihDemoGuide}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 hover:bg-amber-100 dark:hover:bg-amber-900/50 transition-all shadow-xs"
                title="Open Smart India Hackathon guided walkthrough scenario"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 animate-pulse" />
                <span>SIH Demo Guide</span>
              </button>
            )}

            {/* Offline Simulation Button */}
            <button
              type="button"
              onClick={toggleOfflineState}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                isOffline
                  ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-300 dark:border-rose-800'
                  : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800'
              }`}
              title={isOffline ? 'Click to switch back to Online Mode' : 'Click to simulate field Offline Mode'}
            >
              {isOffline ? (
                <>
                  <WifiOff className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Offline Mode</span>
                </>
              ) : (
                <>
                  <Wifi className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Online</span>
                </>
              )}
            </button>

            {/* Sync Trigger when pending records exist or on demand */}
            {syncQueueCount > 0 && !isOffline && (
              <button
                type="button"
                onClick={handleManualSync}
                disabled={syncing}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-all animate-bounce"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
                <span>Sync ({syncQueueCount})</span>
              </button>
            )}

            {/* Language Selector Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 transition-all"
                title="Change Language (10 Indian Languages)"
              >
                <Globe className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden md:inline font-semibold">{languages.find((l) => l.code === language)?.nativeName || 'English'}</span>
                <span className="md:hidden uppercase font-bold">{language}</span>
              </button>

              {showLangMenu && (
                <div
                  className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in slide-in-from-top-2"
                  onMouseLeave={() => setShowLangMenu(false)}
                >
                  <div className="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                    Select Language (भाषा)
                  </div>
                  {languages.map((l) => (
                    <button
                      key={l.code}
                      type="button"
                      onClick={() => {
                        setLanguage(l.code as LanguageCode);
                        setShowLangMenu(false);
                      }}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                        language === l.code
                          ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold'
                          : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                      }`}
                    >
                      <span>{l.nativeName}</span>
                      <span className="text-[10px] text-slate-400">{l.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Theme Selector (Light / Dark / System) */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowThemeMenu(!showThemeMenu)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-all"
                title={`Current theme: ${theme} mode. Click to change.`}
              >
                {isDark ? (
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                ) : (
                  <Moon className="w-3.5 h-3.5 text-indigo-600" />
                )}
                <span className="hidden sm:inline capitalize">
                  {theme === 'system' ? 'System' : isDark ? 'Dark' : 'Light'}
                </span>
              </button>

              {showThemeMenu && (
                <div
                  className="absolute right-0 mt-2 w-44 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in slide-in-from-top-2"
                  onMouseLeave={() => setShowThemeMenu(false)}
                >
                  <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-700">
                    Theme / रंग रूप
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setTheme('light');
                      setShowThemeMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                      theme === 'light'
                        ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 font-bold'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Sun className="w-4 h-4 text-amber-500" />
                      <span>Light Mode</span>
                    </div>
                    {theme === 'light' && <Check className="w-3.5 h-3.5 text-amber-600" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTheme('dark');
                      setShowThemeMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                      theme === 'dark'
                        ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Moon className="w-4 h-4 text-indigo-500" />
                      <span>Dark Mode</span>
                    </div>
                    {theme === 'dark' && <Check className="w-3.5 h-3.5 text-indigo-500" />}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setTheme('system');
                      setShowThemeMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                      theme === 'system'
                        ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 font-bold'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Laptop className="w-4 h-4 text-sky-500" />
                      <span>System Default</span>
                    </div>
                    {theme === 'system' && <Check className="w-3.5 h-3.5 text-sky-500" />}
                  </button>
                </div>
              )}
            </div>


            {/* User Profile / Logout */}
            {currentUser && (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
                {roleBadge && (
                  <div className={`hidden lg:flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${roleBadge.bg}`}>
                    {roleBadge.icon}
                    <span>{roleBadge.label}</span>
                  </div>
                )}

                <div className="hidden sm:block text-right">
                  <div className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                    {currentPatient ? currentPatient.name : currentUser.name}
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400">
                    {currentPatient ? currentPatient.patient_id : currentUser.facility || currentUser.role}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={logout}
                  className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/60 border border-rose-200 dark:border-rose-900/60 transition-all flex items-center gap-1"
                  title={t('logout', 'Logout')}
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden md:inline">{t('logout', 'Logout')}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
