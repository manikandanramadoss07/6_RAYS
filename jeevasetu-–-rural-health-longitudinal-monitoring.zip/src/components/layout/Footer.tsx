import React from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { ShieldCheck, HeartHandshake, FileCheck2 } from 'lucide-react';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-6 text-xs text-slate-500 dark:text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              {t('appName', 'JeevaSetu')} – {t('govMission', 'Government of India Mission')}
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-center md:text-right">
            <span className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-400">
              <FileCheck2 className="w-3.5 h-3.5 text-emerald-600" />
              {t('prototypeNote', 'SIH Healthcare Innovation Demonstration Prototype')}
            </span>
            <span className="hidden sm:inline text-slate-300 dark:text-slate-700">|</span>
            <span>Continuous Longitudinal Rural Health Monitoring</span>
          </div>
        </div>

        {/* Medical and Prototype Disclaimer */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 text-[11px] leading-relaxed text-slate-400 dark:text-slate-500 text-center sm:text-left">
          <p>
            <strong>{t('medicalDisclaimer', 'JeevaSetu is a longitudinal health information and clinical-support platform. It is not an autonomous diagnostic system. Final clinical decisions remain with qualified medical practitioners.')}</strong>
          </p>
          <p className="mt-1 text-[10px]">
            Demonstration prototype developed for evaluation. All test patient profiles are simulated for healthcare workflow demonstration.
          </p>
        </div>
      </div>
    </footer>
  );
};
