import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { StorageService } from '../../services/storageService';
import { TrendChart } from '../common/TrendChart';
import { PatientOtpModal } from '../auth/PatientOtpModal';
import {
  User,
  Heart,
  Wind,
  Activity,
  Thermometer,
  Calendar,
  Phone,
  MapPin,
  CheckCircle2,
  FileText,
  Clock,
  Sparkles,
  Users,
} from 'lucide-react';

export const PatientDashboard: React.FC = () => {
  const { currentPatient } = useAuth();
  const { t } = useLanguage();

  const [isOtpModalOpen, setIsOtpModalOpen] = useState<boolean>(false);

  if (!currentPatient) {
    return (
      <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <p className="text-slate-500">No active patient session found.</p>
      </div>
    );
  }

  const visits = StorageService.getVisitsByPatientId(currentPatient.patient_id);
  const notes = StorageService.getClinicalNotes(currentPatient.patient_id);
  const patientVisibleNotes = notes.filter((n) => n.visibility === 'patient_visible');
  const latestVisit = visits[0] || null;

  // Check if multiple family members share this mobile number
  const familyMembers = StorageService.getPatientsByMobile(currentPatient.mobile);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Patient Welcome Header */}
      <div className="bg-gradient-to-r from-sky-700 via-indigo-700 to-indigo-900 text-white rounded-2xl p-6 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center font-bold text-2xl">
              {currentPatient.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-extrabold">{currentPatient.name}</h1>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-md bg-white/20 text-white">
                  {currentPatient.patient_id}
                </span>
              </div>
              <p className="text-xs text-sky-100 mt-1">
                {currentPatient.age} {t('yearsOld', 'years old')} • {currentPatient.sex} • Village: {currentPatient.village}
              </p>
            </div>
          </div>

          {familyMembers.length > 1 && (
            <button
              type="button"
              onClick={() => setIsOtpModalOpen(true)}
              className="px-3.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-xs font-semibold border border-white/20 text-white flex items-center gap-1.5 transition-all self-start sm:self-auto"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Switch Profile ({familyMembers.length} on this phone)</span>
            </button>
          )}
        </div>
      </div>

      {/* REASSURING LATEST VITAL SUMMARY (PATIENT-FRIENDLY) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-sky-600" />
              <span>{t('latestVitals', 'Your Latest Health Measurements')}</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Recorded during community health survey on {latestVisit?.date || 'N/A'}.
            </p>
          </div>
        </div>

        {latestVisit ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
            {/* Blood Pressure */}
            <div className="p-4 rounded-xl bg-sky-50/60 dark:bg-slate-800/60 border border-sky-100 dark:border-slate-700">
              <div className="flex items-center gap-1.5 text-xs text-sky-700 dark:text-sky-300 font-semibold mb-1">
                <Activity className="w-4 h-4" />
                <span>{t('bloodPressure', 'Blood Pressure')}</span>
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {latestVisit.measurements.bp_systolic}/{latestVisit.measurements.bp_diastolic}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Normal range: 120/80 mmHg
              </div>
            </div>

            {/* Oxygen Saturation */}
            <div className="p-4 rounded-xl bg-sky-50/60 dark:bg-slate-800/60 border border-sky-100 dark:border-slate-700">
              <div className="flex items-center gap-1.5 text-xs text-sky-700 dark:text-sky-300 font-semibold mb-1">
                <Wind className="w-4 h-4" />
                <span>{t('spo2', 'Oxygen Level (SpO₂)')}</span>
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {latestVisit.measurements.spo2}%
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Healthy range: 95% - 100%
              </div>
            </div>

            {/* Heart Rate */}
            <div className="p-4 rounded-xl bg-sky-50/60 dark:bg-slate-800/60 border border-sky-100 dark:border-slate-700">
              <div className="flex items-center gap-1.5 text-xs text-sky-700 dark:text-sky-300 font-semibold mb-1">
                <Heart className="w-4 h-4" />
                <span>{t('heartRate', 'Heart Rate')}</span>
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {latestVisit.measurements.heart_rate} bpm
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Resting pulse: 60 - 100 bpm
              </div>
            </div>

            {/* Body Temperature */}
            <div className="p-4 rounded-xl bg-sky-50/60 dark:bg-slate-800/60 border border-sky-100 dark:border-slate-700">
              <div className="flex items-center gap-1.5 text-xs text-sky-700 dark:text-sky-300 font-semibold mb-1">
                <Thermometer className="w-4 h-4" />
                <span>{t('temperature', 'Body Temperature')}</span>
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {latestVisit.measurements.temperature}°F
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                Normal: 98.6°F (37°C)
              </div>
            </div>
          </div>
        ) : (
          <div className="p-8 text-center text-slate-400 text-xs">
            No survey records available yet. Your community health worker will record your first survey soon.
          </div>
        )}
      </div>

      {/* LONGITUDINAL HEALTH PROGRESS (REASSURING TREND GRAPH) */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
              {t('trends', 'Your Longitudinal Health Timeline')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Review your vital records across consecutive community visits.
            </p>
          </div>
        </div>

        <TrendChart visits={visits} initialParam="spo2" />
      </div>

      {/* DOCTOR GUIDANCE & LIFESTYLE ADVICE */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-600" />
              <span>{t('doctorAdvice', 'Doctor Advice & Health Guidance')}</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Personalized instructions from your Primary Health Centre physician.
            </p>
          </div>
        </div>

        <div className="space-y-3 mt-4">
          {patientVisibleNotes.length > 0 ? (
            patientVisibleNotes.map((n) => (
              <div
                key={n.note_id}
                className="p-4 rounded-xl bg-indigo-50/60 dark:bg-slate-800/60 border border-indigo-100 dark:border-slate-700 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between font-bold text-indigo-900 dark:text-indigo-200">
                  <span>Dr. {n.doctor_name}</span>
                  <span className="text-slate-400 font-normal">
                    {new Date(n.created_at).toLocaleDateString()}
                  </span>
                </div>

                <p className="text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
                  "{n.note}"
                </p>

                {n.prescription_advice && (
                  <div className="p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-emerald-800 dark:text-emerald-300 font-semibold">
                    💊 Medicine / Dietary Plan: {n.prescription_advice}
                  </div>
                )}

                {n.follow_up_date && (
                  <div className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Next recommended health checkup: <strong>{n.follow_up_date}</strong></span>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="p-6 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 text-center text-xs text-slate-500">
              No specific instructions recorded yet. Continue your regular diet and hydration as advised by your ASHA worker.
            </div>
          )}
        </div>
      </div>

      {/* ASHA WORKER CONTACT CARD */}
      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
            <Phone className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-emerald-900 dark:text-emerald-100">
              Your Village Health Worker (ASHA)
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300">
              {currentPatient.assigned_worker_name} • Available for doorstep health surveys and routine inquiries.
            </p>
          </div>
        </div>

        <div className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-600 text-white shadow-xs">
          Rampur PHC Sector
        </div>
      </div>

      {/* Switch profile modal */}
      <PatientOtpModal isOpen={isOtpModalOpen} onClose={() => setIsOtpModalOpen(false)} />
    </div>
  );
};
