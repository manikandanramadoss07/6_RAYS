import React, { useState, useEffect } from 'react';
import { StorageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Patient } from '../../types';
import { UserPlus, Sparkles, CheckCircle2, AlertCircle, MapPin, Phone, User, Building } from 'lucide-react';

interface PatientRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPatientRegistered: (patient: Patient) => void;
}

export const PatientRegistrationModal: React.FC<PatientRegistrationModalProps> = ({
  isOpen,
  onClose,
  onPatientRegistered,
}) => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  const [generatedId, setGeneratedId] = useState<string>('');
  const [name, setName] = useState<string>('Lakshmi');
  const [age, setAge] = useState<string>('62');
  const [sex, setSex] = useState<'Male' | 'Female' | 'Other'>('Female');
  const [mobile, setMobile] = useState<string>('9876543210');
  const [village, setVillage] = useState<string>('Rampur');
  const [district, setDistrict] = useState<string>('Varanasi');
  const [state, setState] = useState<string>('Uttar Pradesh');
  const [address, setAddress] = useState<string>('House #22, Basti Tola, Rampur');
  const [emergencyContact, setEmergencyContact] = useState<string>('9876543210 (Husband)');
  const [medicalHistory, setMedicalHistory] = useState<string>('Hypertension, Occasional shortness of breath');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      const nextId = StorageService.generateNextPatientId();
      setGeneratedId(nextId);
      setError('');
      setSuccess('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError(t('missingName', 'Patient full name is required.'));
      return;
    }
    const parsedAge = parseInt(age, 10);
    if (isNaN(parsedAge) || parsedAge <= 0 || parsedAge > 120) {
      setError('Please enter a valid age between 1 and 120.');
      return;
    }
    const cleanMobile = mobile.replace(/\D/g, '');
    if (cleanMobile.length !== 10) {
      setError('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!village.trim()) {
      setError('Village name is required.');
      return;
    }

    setLoading(true);

    const newPatient: Patient = {
      patient_id: generatedId,
      name: name.trim(),
      age: parsedAge,
      sex,
      mobile: cleanMobile,
      village: village.trim(),
      district: district.trim() || 'Varanasi',
      state: state.trim() || 'Uttar Pradesh',
      address: address.trim(),
      emergencyContact: emergencyContact.trim(),
      registrationDate: new Date().toISOString().split('T')[0],
      assigned_worker_id: currentUser?.id || 'SURV-001',
      assigned_worker_name: currentUser?.name || 'Anita Devi (ASHA)',
      current_status: 'within_range',
      medical_history: medicalHistory ? medicalHistory.split(',').map((s) => s.trim()) : [],
    };

    const { patient, isOffline } = StorageService.addPatient(newPatient, currentUser || {
      id: 'SURV-001',
      name: 'ASHA Worker',
      role: 'surveyor',
    });

    setLoading(false);
    setSuccess(
      isOffline
        ? `Patient ${patient.name} registered locally (${patient.patient_id}) and queued for offline sync.`
        : `Patient ${patient.name} (${patient.patient_id}) registered successfully!`
    );

    setTimeout(() => {
      onPatientRegistered(patient);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-700 to-teal-800 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/15 rounded-xl">
              <UserPlus className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold">
                {t('registerPatient', 'Register New Patient')}
              </h3>
              <p className="text-xs text-emerald-100">
                Auto-assigned Unique Patient ID: <strong className="font-mono bg-white/20 px-2 py-0.5 rounded text-white">{generatedId}</strong>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white text-sm px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Full Name */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('fullName', 'Full Name')} *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Lakshmi Devi"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                required
              />
            </div>

            {/* Age */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('age', 'Age (Years)')} *
              </label>
              <input
                type="number"
                min={1}
                max={120}
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                required
              />
            </div>

            {/* Sex */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('sex', 'Sex')} *
              </label>
              <select
                value={sex}
                onChange={(e) => setSex(e.target.value as any)}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              >
                <option value="Female">{t('female', 'Female')}</option>
                <option value="Male">{t('male', 'Male')}</option>
                <option value="Other">{t('other', 'Other')}</option>
              </select>
            </div>

            {/* Mobile Number */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('mobileNumber', 'Mobile Number')} * (For OTP Login)
              </label>
              <div className="flex rounded-xl shadow-xs border border-slate-300 dark:border-slate-700 overflow-hidden focus-within:ring-2 focus-within:ring-emerald-500">
                <span className="inline-flex items-center px-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-xs border-r border-slate-300 dark:border-slate-700">
                  +91
                </span>
                <input
                  type="tel"
                  maxLength={10}
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                  placeholder="9876543210"
                  className="w-full px-3 py-2.5 text-sm bg-white dark:bg-slate-900 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden font-mono"
                  required
                />
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                Multiple family members may share this number. The Unique Patient ID will differentiate them.
              </p>
            </div>

            {/* Village */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('village', 'Village')} *
              </label>
              <input
                type="text"
                value={village}
                onChange={(e) => setVillage(e.target.value)}
                placeholder="e.g. Rampur"
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                required
              />
            </div>

            {/* District */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('district', 'District')}
              </label>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              />
            </div>

            {/* Address */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {t('address', 'Local Address / Landmark')}
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="e.g. Near Panchayat Bhavan, House #14"
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              />
            </div>

            {/* Known Medical History */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Known Medical History / Symptoms (Comma separated)
              </label>
              <input
                type="text"
                value={medicalHistory}
                onChange={(e) => setMedicalHistory(e.target.value)}
                placeholder="e.g. Hypertension, Diabetes, Asthma"
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {t('cancel', 'Cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>{loading ? 'Registering...' : 'Register Patient & Assign ID'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
