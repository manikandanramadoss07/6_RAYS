import React, { useState, useEffect } from 'react';
import { StorageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Patient, Visit } from '../../types';
import {
  Activity,
  Heart,
  Wind,
  Thermometer,
  Droplets,
  Bluetooth,
  WifiOff,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';

interface NewVisitModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId?: string;
  onVisitAdded: (visit: Visit) => void;
}

export const NewVisitModal: React.FC<NewVisitModalProps> = ({
  isOpen,
  onClose,
  patientId: initialPatientId,
  onVisitAdded,
}) => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatientId, setSelectedPatientId] = useState<string>(initialPatientId || '');

  // Measurements
  const [systolic, setSystolic] = useState<string>('140');
  const [diastolic, setDiastolic] = useState<string>('90');
  const [spo2, setSpo2] = useState<string>('92');
  const [heartRate, setHeartRate] = useState<string>('88');
  const [temperature, setTemperature] = useState<string>('98.6');
  const [respiratoryRate, setRespiratoryRate] = useState<string>('20');
  const [bloodGlucose, setBloodGlucose] = useState<string>('');
  const [hemoglobin, setHemoglobin] = useState<string>('');
  const [measurementSource, setMeasurementSource] = useState<'manual' | 'bluetooth_device'>('bluetooth_device');
  const [notes, setNotes] = useState<string>('Patient reports mild dizziness and breathlessness when walking upstairs.');

  const [isOffline, setIsOffline] = useState<boolean>(() => StorageService.isOfflineMode());
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [btSimulating, setBtSimulating] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      const allPatients = StorageService.getPatients();
      setPatients(allPatients);
      if (initialPatientId) {
        setSelectedPatientId(initialPatientId);
      } else if (allPatients.length > 0 && !selectedPatientId) {
        setSelectedPatientId(allPatients[0].patient_id);
      }
      setIsOffline(StorageService.isOfflineMode());
      setError('');
      setSuccess('');
    }
  }, [isOpen, initialPatientId]);

  if (!isOpen) return null;

  // Simulate Bluetooth device telemetry capture
  const handleSimulateBluetoothCapture = () => {
    setBtSimulating(true);
    setTimeout(() => {
      setSystolic('138');
      setDiastolic('88');
      setSpo2('93');
      setHeartRate('84');
      setTemperature('98.4');
      setRespiratoryRate('19');
      setMeasurementSource('bluetooth_device');
      setBtSimulating(false);
    }, 600);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!selectedPatientId) {
      setError('Please select a patient.');
      return;
    }

    const sys = parseInt(systolic, 10);
    const dia = parseInt(diastolic, 10);
    const sp = parseInt(spo2, 10);
    const hr = parseInt(heartRate, 10);
    const temp = parseFloat(temperature);
    const rr = parseInt(respiratoryRate, 10);

    if (isNaN(sys) || sys < 50 || sys > 260) {
      setError('Please enter a realistic Systolic BP (50 - 260 mmHg).');
      return;
    }
    if (isNaN(dia) || dia < 30 || dia > 150) {
      setError('Please enter a realistic Diastolic BP (30 - 150 mmHg).');
      return;
    }
    if (isNaN(sp) || sp < 50 || sp > 100) {
      setError('Please enter a realistic SpO₂ percentage (50 - 100%).');
      return;
    }
    if (isNaN(hr) || hr < 30 || hr > 220) {
      setError('Please enter a realistic Heart Rate (30 - 220 bpm).');
      return;
    }

    setLoading(true);

    const targetPatient = StorageService.getPatientById(selectedPatientId);
    const visitId = `VISIT-${Date.now()}`;
    const now = new Date();

    const newVisit: Visit = {
      visit_id: visitId,
      patient_id: selectedPatientId,
      date: now.toISOString().split('T')[0],
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      worker_id: currentUser?.id || 'SURV-001',
      worker_name: currentUser?.name || 'Anita Devi (ASHA)',
      location: targetPatient ? `${targetPatient.village} Health Center` : 'Community Camp',
      measurements: {
        bp_systolic: sys,
        bp_diastolic: dia,
        spo2: sp,
        heart_rate: hr,
        temperature: isNaN(temp) ? 98.6 : temp,
        respiratory_rate: isNaN(rr) ? 18 : rr,
        blood_glucose: bloodGlucose ? parseFloat(bloodGlucose) : undefined,
        hemoglobin: hemoglobin ? parseFloat(hemoglobin) : undefined,
        measurement_source: measurementSource,
      },
      notes: notes.trim(),
      sync_status: isOffline ? 'pending' : 'synced',
    };

    const { visit, isOffline: addedOffline } = StorageService.addVisit(newVisit, currentUser || {
      id: 'SURV-001',
      name: 'ASHA Worker',
      role: 'surveyor',
    });

    setLoading(false);
    setSuccess(
      addedOffline
        ? `Field survey saved locally (${visit.visit_id}) and queued for offline sync.`
        : `Field survey recorded and synchronized with central server.`
    );

    setTimeout(() => {
      onVisitAdded(visit);
      onClose();
    }, 1200);
  };

  const selectedPatient = patients.find((p) => p.patient_id === selectedPatientId);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-700 to-indigo-800 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/15 rounded-xl">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold">
                {t('recordVisit', 'Record Community Health Survey')}
              </h3>
              <p className="text-xs text-teal-100">
                Longitudinal vital tracking with automated doctor risk score derivation
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white text-sm px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Offline Banner */}
        {isOffline && (
          <div className="bg-rose-500 text-white px-4 py-2 text-xs font-semibold flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <WifiOff className="w-4 h-4" />
              <span>Offline Mode Active: Survey will be saved in local storage queue.</span>
            </div>
            <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded">Local Storage</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          {/* Patient Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {t('patient', 'Select Patient')} *
            </label>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(e.target.value)}
              className="w-full px-3.5 py-2.5 text-xs font-medium rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500"
              required
            >
              {patients.map((p) => (
                <option key={p.patient_id} value={p.patient_id}>
                  {p.name} ({p.patient_id}) • {p.age} yrs, {p.sex} • Village: {p.village}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Bluetooth / Device Auto-Capture Bar */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Bluetooth className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Connected Biomedical Device
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-semibold">
                PulseOx BT-400
              </span>
            </div>

            <button
              type="button"
              onClick={handleSimulateBluetoothCapture}
              disabled={btSimulating}
              className="px-3 py-1 rounded-lg text-xs font-bold bg-sky-600 hover:bg-sky-700 text-white transition-all flex items-center gap-1.5"
            >
              <Sparkles className={`w-3.5 h-3.5 ${btSimulating ? 'animate-spin' : ''}`} />
              <span>{btSimulating ? 'Capturing...' : 'Auto-Read Telemetry'}</span>
            </button>
          </div>

          {/* BIOMEDICAL INPUT GRID */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {/* Systolic BP */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-rose-500" />
                <span>Systolic BP *</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={systolic}
                  onChange={(e) => setSystolic(e.target.value)}
                  placeholder="120"
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  required
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">mmHg</span>
              </div>
            </div>

            {/* Diastolic BP */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-rose-500" />
                <span>Diastolic BP *</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={diastolic}
                  onChange={(e) => setDiastolic(e.target.value)}
                  placeholder="80"
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  required
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">mmHg</span>
              </div>
            </div>

            {/* SpO2 */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Wind className="w-3.5 h-3.5 text-sky-500" />
                <span>SpO₂ Saturation *</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={spo2}
                  onChange={(e) => setSpo2(e.target.value)}
                  placeholder="98"
                  className={`w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border bg-white dark:bg-slate-900 ${
                    parseInt(spo2, 10) <= 93
                      ? 'border-rose-400 text-rose-600'
                      : 'border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white'
                  }`}
                  required
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">%</span>
              </div>
            </div>

            {/* Heart Rate */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 text-emerald-500" />
                <span>Heart Rate *</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={heartRate}
                  onChange={(e) => setHeartRate(e.target.value)}
                  placeholder="72"
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  required
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">bpm</span>
              </div>
            </div>

            {/* Temperature */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5 text-amber-500" />
                <span>Temperature</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(e.target.value)}
                  placeholder="98.6"
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">°F</span>
              </div>
            </div>

            {/* Respiratory Rate */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Resp Rate
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={respiratoryRate}
                  onChange={(e) => setRespiratoryRate(e.target.value)}
                  placeholder="18"
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">/min</span>
              </div>
            </div>

            {/* Blood Glucose (Optional) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Blood Glucose (RBS)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={bloodGlucose}
                  onChange={(e) => setBloodGlucose(e.target.value)}
                  placeholder="e.g. 130"
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">mg/dL</span>
              </div>
            </div>

            {/* Hemoglobin (Optional) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Hemoglobin (Hb)
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  value={hemoglobin}
                  onChange={(e) => setHemoglobin(e.target.value)}
                  placeholder="e.g. 12.5"
                  className="w-full px-3 py-2 text-sm font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
                <span className="absolute right-3 top-2.5 text-[10px] text-slate-400">g/dL</span>
              </div>
            </div>

            {/* Measurement Source */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Source Device
              </label>
              <select
                value={measurementSource}
                onChange={(e) => setMeasurementSource(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              >
                <option value="bluetooth_device">Bluetooth Device</option>
                <option value="manual">Manual Entry</option>
              </select>
            </div>
          </div>

          {/* Surveyor Observations & Symptoms */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Field Observations & Patient Symptoms
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Record any specific complaints, compliance issues, or lifestyle remarks..."
              className="w-full p-3 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {t('cancel', 'Cancel')}
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-md shadow-teal-600/20 transition-all flex items-center gap-2"
            >
              <Activity className="w-4 h-4" />
              <span>{loading ? 'Submitting...' : 'Save Health Survey Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
