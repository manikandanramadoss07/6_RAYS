import React, { useState } from 'react';
import { Patient, Visit, SyncQueueItem } from '../../types';
import { StorageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { PatientRegistrationModal } from './PatientRegistrationModal';
import { NewVisitModal } from './NewVisitModal';
import {
  UserPlus,
  Activity,
  Wifi,
  WifiOff,
  RefreshCw,
  Search,
  Users,
  MapPin,
  Clock,
  CheckCircle2,
  Calendar,
  Phone,
  Plus,
} from 'lucide-react';

export const SurveyorDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();

  const [patients, setPatients] = useState<Patient[]>(() => StorageService.getPatients());
  const [syncQueue, setSyncQueue] = useState<SyncQueueItem[]>(() => StorageService.getSyncQueue());
  const [isOffline, setIsOffline] = useState<boolean>(() => StorageService.isOfflineMode());
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [isRegModalOpen, setIsRegModalOpen] = useState<boolean>(false);
  const [isVisitModalOpen, setIsVisitModalOpen] = useState<boolean>(false);
  const [selectedPatientForVisit, setSelectedPatientForVisit] = useState<string | undefined>(undefined);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncMessage, setSyncMessage] = useState<string>('');

  const refreshData = () => {
    setPatients(StorageService.getPatients());
    setSyncQueue(StorageService.getSyncQueue());
    setIsOffline(StorageService.isOfflineMode());
  };

  const handleToggleOffline = () => {
    const next = !isOffline;
    setIsOffline(next);
    StorageService.setOfflineMode(next);
  };

  const handleProcessSync = async () => {
    if (isSyncing || isOffline) return;
    setIsSyncing(true);
    setSyncMessage('');

    try {
      const count = await StorageService.processSyncQueue();
      refreshData();
      setSyncMessage(`Successfully synchronized ${count} offline records with central PHC database.`);
      setTimeout(() => setSyncMessage(''), 4000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSyncing(false);
    }
  };

  const filteredPatients = patients.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      !q ||
      p.patient_id.toLowerCase().includes(q) ||
      p.name.toLowerCase().includes(q) ||
      p.village.toLowerCase().includes(q) ||
      p.mobile.includes(searchQuery.replace(/\D/g, ''))
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-emerald-700/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-200 text-xs font-semibold mb-2">
              <MapPin className="w-3.5 h-3.5" />
              <span>Community Health Worker Portal</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {currentUser?.name || 'Anita Devi (ASHA Worker)'}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-200 mt-1">
              Sector: {currentUser?.facility || 'Rampur Village Primary Health Sector'} • Field Health Survey Pad
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleToggleOffline}
              className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 shadow-xs ${
                isOffline
                  ? 'bg-rose-600 text-white border-rose-500 hover:bg-rose-700'
                  : 'bg-emerald-600 text-white border-emerald-500 hover:bg-emerald-700'
              }`}
            >
              {isOffline ? <WifiOff className="w-4 h-4" /> : <Wifi className="w-4 h-4" />}
              <span>{isOffline ? 'Offline Mode (Local Storage)' : 'Online Mode'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sync Notification Banner */}
      {syncMessage && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{syncMessage}</span>
        </div>
      )}

      {/* THREE PRIMARY BIG ACTION TILES (FIELD TABLET / MOBILE OPTIMIZED) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 1. Register Patient Button */}
        <button
          type="button"
          onClick={() => setIsRegModalOpen(true)}
          className="p-5 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white shadow-md shadow-emerald-700/20 text-left transition-all hover:scale-[1.01] flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <UserPlus className="w-6 h-6 text-white" />
            </div>
            <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/20 text-white">
              Auto ID Generator
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-lg font-extrabold">{t('registerPatient', 'Register New Patient')}</h3>
            <p className="text-xs text-emerald-100 mt-1">
              Add rural villager, assign Unique Patient ID & baseline survey.
            </p>
          </div>
        </button>

        {/* 2. Record New Visit / Survey Button */}
        <button
          type="button"
          onClick={() => {
            setSelectedPatientForVisit(undefined);
            setIsVisitModalOpen(true);
          }}
          className="p-5 rounded-2xl bg-gradient-to-br from-indigo-600 to-indigo-800 hover:from-indigo-700 hover:to-indigo-900 text-white shadow-md shadow-indigo-700/20 text-left transition-all hover:scale-[1.01] flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/20 text-white">
              Biomedical Vitals
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-lg font-extrabold">{t('recordVisit', 'New Health Survey / Visit')}</h3>
            <p className="text-xs text-indigo-100 mt-1">
              Capture BP, SpO₂, HR, Temperature, Glucose & symptoms.
            </p>
          </div>
        </button>

        {/* 3. Offline Sync Queue Status */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 flex items-center justify-center">
              <RefreshCw className={`w-6 h-6 ${isSyncing ? 'animate-spin' : ''}`} />
            </div>
            <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
              syncQueue.length > 0
                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
            }`}>
              {syncQueue.length} Pending Records
            </span>
          </div>

          <div className="mt-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Local Offline Sync Engine
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {isOffline
                ? 'Offline mode is active. Records stay safely in browser local storage.'
                : syncQueue.length > 0
                ? 'Connectivity restored. Ready to upload pending surveys.'
                : 'All community records synchronized with Central PHC.'}
            </p>

            <button
              type="button"
              onClick={handleProcessSync}
              disabled={syncQueue.length === 0 || isOffline || isSyncing}
              className="mt-3 w-full py-2 px-3 rounded-xl text-xs font-bold bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white transition-all flex items-center justify-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Synchronizing...' : `Sync Pending Records (${syncQueue.length})`}</span>
            </button>
          </div>
        </div>
      </div>

      {/* PATIENT DIRECTORY & QUICK SURVEY ACTIONS */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
              Assigned Village Patients ({filteredPatients.length})
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Select any patient to record follow-up visits or review survey timelines.
            </p>
          </div>

          <div className="relative min-w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('searchPlaceholder', 'Search patient ID, name, or phone...')}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>
        </div>

        {/* Patient Cards / Rows */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 mt-4">
          {filteredPatients.map((p) => {
            const pVisits = StorageService.getVisitsByPatientId(p.patient_id);
            const latestVisit = pVisits[0] || null;

            return (
              <div
                key={p.patient_id}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-emerald-400 dark:hover:border-emerald-600 transition-all shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                      {p.patient_id}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1 font-mono">
                      <Phone className="w-3 h-3 text-slate-400" />
                      +91 {p.mobile}
                    </span>
                  </div>

                  <div className="mt-2">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      {p.name}
                    </h4>
                    <p className="text-xs text-slate-500">
                      {p.age} yrs • {p.sex} • Village: {p.village}
                    </p>
                  </div>

                  {latestVisit ? (
                    <div className="mt-2.5 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300">
                      <div className="flex items-center justify-between text-slate-400 text-[10px] mb-1">
                        <span>Last Survey: {latestVisit.date}</span>
                        <span>{pVisits.length} visits</span>
                      </div>
                      <div className="font-semibold">
                        BP: {latestVisit.measurements.bp_systolic}/{latestVisit.measurements.bp_diastolic} mmHg • SpO₂: {latestVisit.measurements.spo2}%
                      </div>
                    </div>
                  ) : (
                    <div className="mt-2.5 p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 italic">
                      No visits recorded yet.
                    </div>
                  )}
                </div>

                <div className="mt-3 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">
                    ASHA: {p.assigned_worker_name}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedPatientForVisit(p.patient_id);
                      setIsVisitModalOpen(true);
                    }}
                    className="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add Survey</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modals */}
      <PatientRegistrationModal
        isOpen={isRegModalOpen}
        onClose={() => setIsRegModalOpen(false)}
        onPatientRegistered={(p) => {
          refreshData();
        }}
      />

      <NewVisitModal
        isOpen={isVisitModalOpen}
        onClose={() => setIsVisitModalOpen(false)}
        patientId={selectedPatientForVisit}
        onVisitAdded={(v) => {
          refreshData();
        }}
      />
    </div>
  );
};
