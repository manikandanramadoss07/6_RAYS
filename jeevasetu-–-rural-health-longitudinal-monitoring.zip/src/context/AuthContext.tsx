import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Patient, UserRole } from '../types';
import { DEMO_USERS, StorageService } from '../services/storageService';

interface AuthContextType {
  currentUser: User | null;
  currentPatient: Patient | null;
  role: UserRole | null;
  isAuthenticated: boolean;
  loginDoctor: (emailOrUsername: string) => Promise<{ success: boolean; error?: string }>;
  loginSurveyor: (emailOrUsername: string) => Promise<{ success: boolean; error?: string }>;
  loginAdmin: (emailOrUsername: string) => Promise<{ success: boolean; error?: string }>;
  loginPatientWithOtp: (patientId: string) => void;
  logout: () => void;
  setCurrentPatient: (patient: Patient | null) => void;
}

const STORAGE_AUTH_USER = 'jeevasetu_auth_user_v1';
const STORAGE_AUTH_PATIENT = 'jeevasetu_auth_patient_v1';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_AUTH_USER);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return null;
  });

  const [currentPatient, setCurrentPatientState] = useState<Patient | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_AUTH_PATIENT);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return null;
  });

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_AUTH_USER, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_AUTH_USER);
    }
  }, [currentUser]);

  useEffect(() => {
    if (currentPatient) {
      localStorage.setItem(STORAGE_AUTH_PATIENT, JSON.stringify(currentPatient));
    } else {
      localStorage.removeItem(STORAGE_AUTH_PATIENT);
    }
  }, [currentPatient]);

  const loginDoctor = async (emailOrUsername: string): Promise<{ success: boolean; error?: string }> => {
    const q = emailOrUsername.trim().toLowerCase();
    const doc = DEMO_USERS.find(
      (u) =>
        u.role === 'doctor' &&
        (u.username?.toLowerCase() === q || u.email?.toLowerCase() === q || u.name.toLowerCase().includes(q))
    ) || DEMO_USERS.find((u) => u.role === 'doctor'); // fallback to first demo doctor

    if (doc) {
      setCurrentUser(doc);
      setCurrentPatientState(null);
      return { success: true };
    }
    return { success: false, error: 'Doctor credentials not recognized.' };
  };

  const loginSurveyor = async (emailOrUsername: string): Promise<{ success: boolean; error?: string }> => {
    const q = emailOrUsername.trim().toLowerCase();
    const surv = DEMO_USERS.find(
      (u) =>
        u.role === 'surveyor' &&
        (u.username?.toLowerCase() === q || u.phone === q || u.name.toLowerCase().includes(q))
    ) || DEMO_USERS.find((u) => u.role === 'surveyor'); // fallback to first demo surveyor

    if (surv) {
      setCurrentUser(surv);
      setCurrentPatientState(null);
      return { success: true };
    }
    return { success: false, error: 'Surveyor credentials not recognized.' };
  };

  const loginAdmin = async (emailOrUsername: string): Promise<{ success: boolean; error?: string }> => {
    const q = emailOrUsername.trim().toLowerCase();
    const admin = DEMO_USERS.find(
      (u) =>
        u.role === 'admin' &&
        (u.username?.toLowerCase() === q || u.email?.toLowerCase() === q || u.name.toLowerCase().includes(q))
    ) || DEMO_USERS.find((u) => u.role === 'admin');

    if (admin) {
      setCurrentUser(admin);
      setCurrentPatientState(null);
      return { success: true };
    }
    return { success: false, error: 'Supervisor credentials not recognized.' };
  };

  const loginPatientWithOtp = (patientId: string) => {
    const patient = StorageService.getPatientById(patientId);
    if (patient) {
      const patientUser: User = {
        id: patient.patient_id,
        name: patient.name,
        role: 'patient',
        phone: patient.mobile,
      };
      setCurrentUser(patientUser);
      setCurrentPatientState(patient);
    }
  };

  const setCurrentPatient = (patient: Patient | null) => {
    setCurrentPatientState(patient);
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentPatientState(null);
    localStorage.removeItem(STORAGE_AUTH_USER);
    localStorage.removeItem(STORAGE_AUTH_PATIENT);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentPatient,
        role: currentUser?.role || null,
        isAuthenticated: !!currentUser,
        loginDoctor,
        loginSurveyor,
        loginAdmin,
        loginPatientWithOtp,
        logout,
        setCurrentPatient,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
