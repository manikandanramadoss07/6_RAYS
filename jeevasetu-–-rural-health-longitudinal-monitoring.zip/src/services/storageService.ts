import {
  Patient,
  Visit,
  ClinicalNote,
  SyncQueueItem,
  AuditLogItem,
  DashboardStats,
  User,
  ReviewStatus,
} from '../types';

const STORAGE_KEYS = {
  PATIENTS: 'jeevasetu_patients_v1',
  VISITS: 'jeevasetu_visits_v1',
  CLINICAL_NOTES: 'jeevasetu_notes_v1',
  SYNC_QUEUE: 'jeevasetu_sync_queue_v1',
  AUDIT_LOG: 'jeevasetu_audit_log_v1',
  OFFLINE_MODE: 'jeevasetu_simulated_offline_v1',
};

// Initial Seed Doctors & Health Workers
export const DEMO_USERS: User[] = [
  {
    id: 'DOC-001',
    name: 'Dr. Priya Sharma',
    username: 'dr.priya',
    role: 'doctor',
    email: 'dr.priya@jeevasetu.gov.in',
    facility: 'Rampur Primary Health Centre (PHC)',
    specialization: 'Community Medicine Specialist (MD)',
  },
  {
    id: 'DOC-002',
    name: 'Dr. Arvind Rao',
    username: 'dr.arvind',
    role: 'doctor',
    email: 'dr.arvind@jeevasetu.gov.in',
    facility: 'Kalyanpur Community Health Centre (CHC)',
    specialization: 'Senior Medical Officer (MBBS)',
  },
  {
    id: 'SURV-001',
    name: 'Anita Devi (ASHA Worker)',
    username: 'asha.anita',
    role: 'surveyor',
    phone: '9876543201',
    assignedVillage: 'Rampur Sector 1 & 2',
    facility: 'Rampur Health Sub-Centre',
  },
  {
    id: 'SURV-002',
    name: 'Ramesh Verma (Health Worker)',
    username: 'hw.ramesh',
    role: 'surveyor',
    phone: '9876543202',
    assignedVillage: 'Kalyanpur Village',
    facility: 'Kalyanpur Sub-Centre',
  },
  {
    id: 'ADM-001',
    name: 'Dr. K. S. Murthy (Block Medical Officer)',
    username: 'admin.bmo',
    role: 'admin',
    email: 'bmo.murthy@jeevasetu.gov.in',
    facility: 'District Health Administrative Office',
  },
];

// Initial Seed Patients (Realistic Rural Dataset)
const INITIAL_PATIENTS: Patient[] = [
  {
    patient_id: 'PAT-2026-001',
    name: 'Lakshmi',
    age: 62,
    sex: 'Female',
    mobile: '9876543210', // Note: Shares phone with Ravi to test multi-patient lookup!
    village: 'Rampur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'House #14, Basti Tola, Rampur',
    emergencyContact: '9876543210 (Husband Ravi)',
    registrationDate: '2026-07-15',
    assigned_worker_id: 'SURV-001',
    assigned_worker_name: 'Anita Devi (ASHA)',
    current_status: 'requires_review',
    last_visit_date: '2026-08-20',
    medical_history: ['Hypertension (borderline)', 'Mild breathlessness on exertion'],
  },
  {
    patient_id: 'PAT-2026-002',
    name: 'Ravi',
    age: 65,
    sex: 'Male',
    mobile: '9876543210', // Shared phone
    village: 'Rampur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'House #14, Basti Tola, Rampur',
    emergencyContact: '9876543210 (Wife Lakshmi)',
    registrationDate: '2026-07-15',
    assigned_worker_id: 'SURV-001',
    assigned_worker_name: 'Anita Devi (ASHA)',
    current_status: 'within_range',
    last_visit_date: '2026-08-18',
    medical_history: ['Occasional joint pain'],
  },
  {
    patient_id: 'PAT-2026-003',
    name: 'Sunita Devi',
    age: 48,
    sex: 'Female',
    mobile: '9871122334',
    village: 'Rampur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'Panchayat Bhavan Road, Rampur',
    emergencyContact: '9871122335 (Son Vikas)',
    registrationDate: '2026-07-20',
    assigned_worker_id: 'SURV-001',
    assigned_worker_name: 'Anita Devi (ASHA)',
    current_status: 'within_range',
    last_visit_date: '2026-08-14',
    medical_history: ['Normal baseline'],
  },
  {
    patient_id: 'PAT-2026-004',
    name: 'Mohammad Farooq',
    age: 55,
    sex: 'Male',
    mobile: '9845566778',
    village: 'Kalyanpur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'Near Purana Kuan, Kalyanpur',
    emergencyContact: '9845566779 (Brother Tariq)',
    registrationDate: '2026-07-22',
    assigned_worker_id: 'SURV-002',
    assigned_worker_name: 'Ramesh Verma (HW)',
    current_status: 'trend_attention',
    last_visit_date: '2026-08-22',
    medical_history: ['Type 2 Diabetes Mellitus', 'Stage 1 Hypertension'],
  },
  {
    patient_id: 'PAT-2026-005',
    name: 'Meera Bai',
    age: 28,
    sex: 'Female',
    mobile: '9765432109',
    village: 'Bithoor',
    district: 'Kanpur Nagar',
    state: 'Uttar Pradesh',
    address: 'Ganga Ghat Road, Bithoor',
    emergencyContact: '9765432110 (Mother Ganga)',
    registrationDate: '2026-07-25',
    assigned_worker_id: 'SURV-001',
    assigned_worker_name: 'Anita Devi (ASHA)',
    current_status: 'trend_attention',
    last_visit_date: '2026-08-21',
    medical_history: ['Antenatal 2nd trimester', 'Nutritional Anemia'],
  },
  {
    patient_id: 'PAT-2026-006',
    name: 'Gurpreet Singh',
    age: 59,
    sex: 'Male',
    mobile: '9812345678',
    village: 'Rampur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'Kisan Marg, Sector 2, Rampur',
    emergencyContact: '9812345679 (Daughter Simran)',
    registrationDate: '2026-08-01',
    assigned_worker_id: 'SURV-001',
    assigned_worker_name: 'Anita Devi (ASHA)',
    current_status: 'within_range',
    last_visit_date: '2026-08-19',
    medical_history: ['Seasonal allergy'],
  },
  {
    patient_id: 'PAT-2026-007',
    name: 'Ananya Sen',
    age: 24,
    sex: 'Female',
    mobile: '9833445566',
    village: 'Kalyanpur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'School Tola, Kalyanpur',
    emergencyContact: '9833445567 (Father Debasish)',
    registrationDate: '2026-08-05',
    assigned_worker_id: 'SURV-002',
    assigned_worker_name: 'Ramesh Verma (HW)',
    current_status: 'within_range',
    last_visit_date: '2026-08-16',
    medical_history: ['None recorded'],
  },
  {
    patient_id: 'PAT-2026-008',
    name: 'Balaram Reddy',
    age: 71,
    sex: 'Male',
    mobile: '9899887766',
    village: 'Bithoor',
    district: 'Kanpur Nagar',
    state: 'Uttar Pradesh',
    address: 'Near Old Shiva Temple, Bithoor',
    emergencyContact: '9899887767 (Son Suresh)',
    registrationDate: '2026-08-08',
    assigned_worker_id: 'SURV-001',
    assigned_worker_name: 'Anita Devi (ASHA)',
    current_status: 'requires_review',
    last_visit_date: '2026-08-23',
    medical_history: ['Chronic Hypertension', 'Ischemic Heart Disease history'],
  },
  {
    patient_id: 'PAT-2026-009',
    name: 'Savitri Amma',
    age: 68,
    sex: 'Female',
    mobile: '9788990011',
    village: 'Rampur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'Ward 4, Rampur North',
    emergencyContact: '9788990012 (Daughter Radha)',
    registrationDate: '2026-08-10',
    assigned_worker_id: 'SURV-001',
    assigned_worker_name: 'Anita Devi (ASHA)',
    current_status: 'trend_attention',
    last_visit_date: '2026-08-20',
    medical_history: ['Diabetes mellitus', 'Mild visual impairment'],
  },
  {
    patient_id: 'PAT-2026-010',
    name: 'Ramesh Kumar',
    age: 51,
    sex: 'Male',
    mobile: '9711223344',
    village: 'Kalyanpur',
    district: 'Varanasi',
    state: 'Uttar Pradesh',
    address: 'Chowk Bazar, Kalyanpur',
    emergencyContact: '9711223345 (Wife Shanti)',
    registrationDate: '2026-08-12',
    assigned_worker_id: 'SURV-002',
    assigned_worker_name: 'Ramesh Verma (HW)',
    current_status: 'within_range',
    last_visit_date: '2026-08-22',
    medical_history: ['Smoker (counselled for cessation)'],
  },
];

// Initial Longitudinal Visits (Connecting Survey -> Visits -> Trajectories)
const INITIAL_VISITS: Visit[] = [
  // Lakshmi (PAT-2026-001) - Demonstrating the exact longitudinal SIH scenario:
  // Visit 1: BP 120/80, SpO2 96%, HR 82
  // Visit 2: BP 140/90, SpO2 92%, HR 104
  // Visit 3: BP 135/85, SpO2 94%, HR 96
  {
    visit_id: 'VIS-2026-001-01',
    patient_id: 'PAT-2026-001',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-01',
    time: '10:30',
    location: 'Rampur Home Visit',
    sync_status: 'synced',
    notes: 'Initial community survey visit. Patient reported feeling well.',
    measurements: {
      bp_systolic: 120,
      bp_diastolic: 80,
      spo2: 96,
      heart_rate: 82,
      temperature: 98.4,
      respiratory_rate: 16,
      blood_glucose: 110,
      hemoglobin: 12.2,
    },
    measurement_source: 'bluetooth_device',
    created_at: '2026-08-01T10:30:00Z',
    synced_at: '2026-08-01T10:35:00Z',
  },
  {
    visit_id: 'VIS-2026-001-02',
    patient_id: 'PAT-2026-001',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-15',
    time: '11:10',
    location: 'Rampur Home Visit',
    sync_status: 'synced',
    notes: 'Patient complained of mild exhaustion and occasional shortness of breath during household chores.',
    measurements: {
      bp_systolic: 140,
      bp_diastolic: 90,
      spo2: 92,
      heart_rate: 104,
      temperature: 99.1,
      respiratory_rate: 22,
      blood_glucose: 124,
      hemoglobin: 11.8,
    },
    measurement_source: 'bluetooth_device',
    created_at: '2026-08-15T11:10:00Z',
    synced_at: '2026-08-15T11:15:00Z',
  },
  {
    visit_id: 'VIS-2026-001-03',
    patient_id: 'PAT-2026-001',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-20',
    time: '09:45',
    location: 'Rampur Sub-Centre Camp',
    sync_status: 'synced',
    notes: 'Follow-up measurement camp. Elevated BP persisting with borderline SpO2 and tachycardia.',
    measurements: {
      bp_systolic: 135,
      bp_diastolic: 85,
      spo2: 94,
      heart_rate: 96,
      temperature: 98.6,
      respiratory_rate: 18,
      blood_glucose: 118,
      hemoglobin: 11.9,
    },
    measurement_source: 'bluetooth_device',
    created_at: '2026-08-20T09:45:00Z',
    synced_at: '2026-08-20T09:50:00Z',
  },

  // Ravi (PAT-2026-002)
  {
    visit_id: 'VIS-2026-002-01',
    patient_id: 'PAT-2026-002',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-01',
    time: '10:50',
    location: 'Rampur Home Visit',
    sync_status: 'synced',
    notes: 'Baseline health survey. Vitals steady.',
    measurements: {
      bp_systolic: 124,
      bp_diastolic: 82,
      spo2: 97,
      heart_rate: 76,
      temperature: 98.2,
      respiratory_rate: 16,
      blood_glucose: 104,
      hemoglobin: 13.5,
    },
    measurement_source: 'manual',
    created_at: '2026-08-01T10:50:00Z',
    synced_at: '2026-08-01T10:55:00Z',
  },
  {
    visit_id: 'VIS-2026-002-02',
    patient_id: 'PAT-2026-002',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-18',
    time: '14:20',
    location: 'Rampur Sub-Centre Camp',
    sync_status: 'synced',
    notes: 'Regular checkup. Normal vital parameters.',
    measurements: {
      bp_systolic: 122,
      bp_diastolic: 80,
      spo2: 97,
      heart_rate: 74,
      temperature: 98.4,
      respiratory_rate: 15,
      blood_glucose: 98,
      hemoglobin: 13.6,
    },
    measurement_source: 'manual',
    created_at: '2026-08-18T14:20:00Z',
    synced_at: '2026-08-18T14:25:00Z',
  },

  // Mohammad Farooq (PAT-2026-004) - High BP & Glucose
  {
    visit_id: 'VIS-2026-004-01',
    patient_id: 'PAT-2026-004',
    worker_id: 'SURV-002',
    worker_name: 'Ramesh Verma (HW)',
    date: '2026-08-04',
    time: '11:00',
    location: 'Kalyanpur Health Post',
    sync_status: 'synced',
    notes: 'Complained of frequent thirst and headache.',
    measurements: {
      bp_systolic: 145,
      bp_diastolic: 92,
      spo2: 95,
      heart_rate: 88,
      temperature: 98.6,
      respiratory_rate: 18,
      blood_glucose: 210,
      hemoglobin: 14.0,
    },
    measurement_source: 'bluetooth_device',
    created_at: '2026-08-04T11:00:00Z',
    synced_at: '2026-08-04T11:05:00Z',
  },
  {
    visit_id: 'VIS-2026-004-02',
    patient_id: 'PAT-2026-004',
    worker_id: 'SURV-002',
    worker_name: 'Ramesh Verma (HW)',
    date: '2026-08-22',
    time: '10:15',
    location: 'Kalyanpur Health Post',
    sync_status: 'synced',
    notes: 'Follow-up blood glucose remains elevated; systolic BP remains at 148 mmHg.',
    measurements: {
      bp_systolic: 148,
      bp_diastolic: 94,
      spo2: 94,
      heart_rate: 90,
      temperature: 98.8,
      respiratory_rate: 19,
      blood_glucose: 235,
      hemoglobin: 13.8,
    },
    measurement_source: 'bluetooth_device',
    created_at: '2026-08-22T10:15:00Z',
    synced_at: '2026-08-22T10:20:00Z',
  },

  // Meera Bai (PAT-2026-005) - Antenatal & Anemia
  {
    visit_id: 'VIS-2026-005-01',
    patient_id: 'PAT-2026-005',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-05',
    time: '12:00',
    location: 'Bithoor Village Survey',
    sync_status: 'synced',
    notes: 'Antenatal survey. Advised IFA supplements.',
    measurements: {
      bp_systolic: 110,
      bp_diastolic: 70,
      spo2: 97,
      heart_rate: 84,
      temperature: 98.4,
      respiratory_rate: 18,
      blood_glucose: 92,
      hemoglobin: 9.4,
    },
    measurement_source: 'manual',
    created_at: '2026-08-05T12:00:00Z',
    synced_at: '2026-08-05T12:05:00Z',
  },
  {
    visit_id: 'VIS-2026-005-02',
    patient_id: 'PAT-2026-005',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-21',
    time: '15:30',
    location: 'Bithoor Village Survey',
    sync_status: 'synced',
    notes: 'Hemoglobin improved slightly with IFA adherence.',
    measurements: {
      bp_systolic: 112,
      bp_diastolic: 72,
      spo2: 98,
      heart_rate: 82,
      temperature: 98.5,
      respiratory_rate: 17,
      blood_glucose: 96,
      hemoglobin: 10.1,
    },
    measurement_source: 'manual',
    created_at: '2026-08-21T15:30:00Z',
    synced_at: '2026-08-21T15:35:00Z',
  },

  // Balaram Reddy (PAT-2026-008) - Marked Hypertension & Cardiac Risk
  {
    visit_id: 'VIS-2026-008-01',
    patient_id: 'PAT-2026-008',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-10',
    time: '16:00',
    location: 'Bithoor Sub-Centre',
    sync_status: 'synced',
    notes: 'Elderly hypertensive screening.',
    measurements: {
      bp_systolic: 162,
      bp_diastolic: 102,
      spo2: 93,
      heart_rate: 98,
      temperature: 98.6,
      respiratory_rate: 22,
      blood_glucose: 145,
      hemoglobin: 12.0,
    },
    measurement_source: 'bluetooth_device',
    created_at: '2026-08-10T16:00:00Z',
    synced_at: '2026-08-10T16:05:00Z',
  },
  {
    visit_id: 'VIS-2026-008-02',
    patient_id: 'PAT-2026-008',
    worker_id: 'SURV-001',
    worker_name: 'Anita Devi (ASHA)',
    date: '2026-08-23',
    time: '11:45',
    location: 'Bithoor Sub-Centre',
    sync_status: 'synced',
    notes: 'Stage 2 Hypertension persisting.',
    measurements: {
      bp_systolic: 168,
      bp_diastolic: 104,
      spo2: 91,
      heart_rate: 106,
      temperature: 98.8,
      respiratory_rate: 24,
      blood_glucose: 152,
      hemoglobin: 11.7,
    },
    measurement_source: 'bluetooth_device',
    created_at: '2026-08-23T11:45:00Z',
    synced_at: '2026-08-23T11:50:00Z',
  },
];

// Initial Seed Clinical Notes
const INITIAL_CLINICAL_NOTES: ClinicalNote[] = [
  {
    note_id: 'NOTE-001',
    patient_id: 'PAT-2026-001',
    doctor_id: 'DOC-001',
    doctor_name: 'Dr. Priya Sharma (PHC Medical Officer)',
    note: 'Patient exhibits ascending systolic trend and mild desaturation during physical work. Review history indicates need for ECG and antihypertensive dosage adjustment.',
    visibility: 'doctor_only',
    review_status: 'requires_review',
    created_at: '2026-08-20T14:30:00Z',
  },
  {
    note_id: 'NOTE-002',
    patient_id: 'PAT-2026-001',
    doctor_id: 'DOC-001',
    doctor_name: 'Dr. Priya Sharma (PHC Medical Officer)',
    note: 'Please visit Rampur PHC on Tuesday morning for routine physician checkup. Maintain low salt in diet and continue taking your prescribed daily tablet with warm water.',
    visibility: 'patient_visible',
    follow_up_date: '2026-08-28',
    prescription_advice: 'Amlodipine 5mg (1 tab OD after breakfast). Salt restriction < 5g/day.',
    review_status: 'requires_review',
    created_at: '2026-08-20T14:35:00Z',
  },
];

// Initial Audit Logs
const INITIAL_AUDIT_LOGS: AuditLogItem[] = [
  {
    log_id: 'LOG-001',
    user_id: 'SURV-001',
    user_name: 'Anita Devi (ASHA)',
    role: 'surveyor',
    action: 'REGISTER_PATIENT',
    patient_id: 'PAT-2026-001',
    patient_name: 'Lakshmi',
    details: 'Initial rural demographic registration completed.',
    timestamp: '2026-07-15T10:00:00Z',
  },
  {
    log_id: 'LOG-002',
    user_id: 'SURV-001',
    user_name: 'Anita Devi (ASHA)',
    role: 'surveyor',
    action: 'NEW_VISIT_RECORDED',
    patient_id: 'PAT-2026-001',
    patient_name: 'Lakshmi',
    details: 'Visit 3 biomedical vitals captured via Bluetooth Pulse Oximeter and Sphygmomanometer.',
    timestamp: '2026-08-20T09:45:00Z',
  },
  {
    log_id: 'LOG-003',
    user_id: 'DOC-001',
    user_name: 'Dr. Priya Sharma',
    role: 'doctor',
    action: 'CLINICAL_EVALUATION',
    patient_id: 'PAT-2026-001',
    patient_name: 'Lakshmi',
    details: 'Evaluated longitudinal trend graphs; authored patient care advisory.',
    timestamp: '2026-08-20T14:35:00Z',
  },
];

export class StorageService {
  // Initialize Database from Local Storage or Seed Data
  private static getStoredData<T>(key: string, fallback: T): T {
    try {
      const data = localStorage.getItem(key);
      if (data) {
        return JSON.parse(data) as T;
      }
    } catch (e) {
      console.warn(`StorageService read error for ${key}:`, e);
    }
    return fallback;
  }

  private static setStoredData<T>(key: string, data: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error(`StorageService write error for ${key}:`, e);
    }
  }

  // --- Offline Mode Toggle State ---
  public static isOfflineMode(): boolean {
    return this.getStoredData<boolean>(STORAGE_KEYS.OFFLINE_MODE, false);
  }

  public static setOfflineMode(isOffline: boolean): void {
    this.setStoredData(STORAGE_KEYS.OFFLINE_MODE, isOffline);
  }

  // --- Patients API ---
  public static getPatients(): Patient[] {
    return this.getStoredData<Patient[]>(STORAGE_KEYS.PATIENTS, INITIAL_PATIENTS);
  }

  public static getPatientById(id: string): Patient | undefined {
    const patients = this.getPatients();
    return patients.find((p) => p.patient_id.toLowerCase() === id.trim().toLowerCase());
  }

  public static searchPatients(query: string): Patient[] {
    if (!query || !query.trim()) return this.getPatients();
    const q = query.trim().toLowerCase();
    const cleanMobile = query.replace(/\D/g, '');

    return this.getPatients().filter((p) => {
      const matchId = p.patient_id.toLowerCase().includes(q);
      const matchName = p.name.toLowerCase().includes(q);
      const matchVillage = p.village.toLowerCase().includes(q);
      const matchMobile = cleanMobile ? p.mobile.includes(cleanMobile) : false;
      return matchId || matchName || matchVillage || matchMobile;
    });
  }

  public static getPatientsByMobile(mobile: string): Patient[] {
    const clean = mobile.replace(/\D/g, '');
    if (!clean) return [];
    return this.getPatients().filter((p) => p.mobile.replace(/\D/g, '').includes(clean));
  }

  public static generateNextPatientId(): string {
    const patients = this.getPatients();
    let maxNumber = 0;
    const regex = /PAT-2026-(\d+)/;

    patients.forEach((p) => {
      const match = p.patient_id.match(regex);
      if (match && match[1]) {
        const num = parseInt(match[1], 10);
        if (num > maxNumber) maxNumber = num;
      }
    });

    const nextNum = maxNumber + 1;
    return `PAT-2026-${String(nextNum).padStart(3, '0')}`;
  }

  public static addPatient(patient: Patient, user: User): { patient: Patient; isOffline: boolean } {
    const isOffline = this.isOfflineMode();
    const patients = this.getPatients();
    
    // Check if duplicate patient ID
    const existingIndex = patients.findIndex((p) => p.patient_id === patient.patient_id);
    if (existingIndex >= 0) {
      patients[existingIndex] = patient;
    } else {
      patients.unshift(patient);
    }
    this.setStoredData(STORAGE_KEYS.PATIENTS, patients);

    // If offline, add to Sync Queue
    if (isOffline) {
      this.addToSyncQueue({
        local_record_id: `LOCAL-PAT-${Date.now()}`,
        record_type: 'patient',
        patient_id: patient.patient_id,
        payload: patient,
        created_at: new Date().toISOString(),
        sync_status: 'pending',
        retry_count: 0,
      });
    }

    // Audit Log
    this.addAuditLog({
      log_id: `LOG-${Date.now()}`,
      user_id: user.id,
      user_name: user.name,
      role: user.role,
      action: isOffline ? 'OFFLINE_PATIENT_REGISTERED' : 'REGISTER_PATIENT',
      patient_id: patient.patient_id,
      patient_name: patient.name,
      details: `Registered ${patient.name} (${patient.patient_id}) from village ${patient.village} [${isOffline ? 'Offline Queue' : 'Synced'}]`,
      timestamp: new Date().toISOString(),
    });

    return { patient, isOffline };
  }

  public static updatePatient(patient: Patient, user: User, reason?: string): Patient {
    const patients = this.getPatients();
    const index = patients.findIndex((p) => p.patient_id === patient.patient_id);
    if (index >= 0) {
      patients[index] = { ...patient };
      this.setStoredData(STORAGE_KEYS.PATIENTS, patients);

      this.addAuditLog({
        log_id: `LOG-${Date.now()}`,
        user_id: user.id,
        user_name: user.name,
        role: user.role,
        action: 'UPDATE_PATIENT_PROFILE',
        patient_id: patient.patient_id,
        patient_name: patient.name,
        details: reason || `Updated profile for ${patient.name} (${patient.patient_id})`,
        timestamp: new Date().toISOString(),
      });
    }
    return patient;
  }

  // --- Visits API ---
  public static getVisits(): Visit[] {
    return this.getStoredData<Visit[]>(STORAGE_KEYS.VISITS, INITIAL_VISITS);
  }

  public static getVisitsByPatientId(patientId: string): Visit[] {
    const allVisits = this.getVisits();
    return allVisits
      .filter((v) => v.patient_id.toLowerCase() === patientId.trim().toLowerCase())
      .sort((a, b) => new Date(`${b.date}T${b.time || '00:00'}`).getTime() - new Date(`${a.date}T${a.time || '00:00'}`).getTime());
  }

  public static addVisit(visit: Visit, user: User): { visit: Visit; isOffline: boolean } {
    const isOffline = this.isOfflineMode();
    const visits = this.getVisits();

    const formattedVisit: Visit = {
      ...visit,
      sync_status: isOffline ? 'pending' : 'synced',
      synced_at: isOffline ? undefined : new Date().toISOString(),
    };

    visits.unshift(formattedVisit);
    this.setStoredData(STORAGE_KEYS.VISITS, visits);

    // Update patient's last visit date and status
    const patients = this.getPatients();
    const pIndex = patients.findIndex((p) => p.patient_id === visit.patient_id);
    if (pIndex >= 0) {
      patients[pIndex].last_visit_date = visit.date;
      this.setStoredData(STORAGE_KEYS.PATIENTS, patients);
    }

    // Queue if offline
    if (isOffline) {
      this.addToSyncQueue({
        local_record_id: `LOCAL-VIS-${Date.now()}`,
        record_type: 'visit',
        patient_id: visit.patient_id,
        payload: formattedVisit,
        created_at: new Date().toISOString(),
        sync_status: 'pending',
        retry_count: 0,
      });
    }

    // Audit Log
    this.addAuditLog({
      log_id: `LOG-${Date.now()}`,
      user_id: user.id,
      user_name: user.name,
      role: user.role,
      action: isOffline ? 'OFFLINE_VISIT_RECORDED' : 'NEW_VISIT_RECORDED',
      patient_id: visit.patient_id,
      details: `Visit recorded (BP: ${visit.measurements.bp_systolic}/${visit.measurements.bp_diastolic}, SpO2: ${visit.measurements.spo2}%, HR: ${visit.measurements.heart_rate} bpm) [${isOffline ? 'Pending Sync' : 'Synced'}]`,
      timestamp: new Date().toISOString(),
    });

    return { visit: formattedVisit, isOffline };
  }

  // --- Clinical Notes API ---
  public static getClinicalNotes(patientId?: string): ClinicalNote[] {
    const notes = this.getStoredData<ClinicalNote[]>(STORAGE_KEYS.CLINICAL_NOTES, INITIAL_CLINICAL_NOTES);
    if (!patientId) return notes;
    return notes.filter((n) => n.patient_id.toLowerCase() === patientId.trim().toLowerCase());
  }

  public static addClinicalNote(note: ClinicalNote, user: User): ClinicalNote {
    const notes = this.getClinicalNotes();
    notes.unshift(note);
    this.setStoredData(STORAGE_KEYS.CLINICAL_NOTES, notes);

    // Update patient status if doctor specified
    const patients = this.getPatients();
    const pIndex = patients.findIndex((p) => p.patient_id === note.patient_id);
    if (pIndex >= 0 && note.review_status) {
      patients[pIndex].current_status = note.review_status;
      this.setStoredData(STORAGE_KEYS.PATIENTS, patients);
    }

    this.addAuditLog({
      log_id: `LOG-${Date.now()}`,
      user_id: user.id,
      user_name: user.name,
      role: user.role,
      action: 'ADD_CLINICAL_NOTE',
      patient_id: note.patient_id,
      details: `Added note (${note.visibility === 'doctor_only' ? 'Doctor Restricted' : 'Patient Visible'}) with review status '${note.review_status}'`,
      timestamp: new Date().toISOString(),
    });

    return note;
  }

  // --- Sync Queue API ---
  public static getSyncQueue(): SyncQueueItem[] {
    return this.getStoredData<SyncQueueItem[]>(STORAGE_KEYS.SYNC_QUEUE, []);
  }

  public static addToSyncQueue(item: SyncQueueItem): void {
    const queue = this.getSyncQueue();
    queue.unshift(item);
    this.setStoredData(STORAGE_KEYS.SYNC_QUEUE, queue);
  }

  public static clearSyncQueue(): void {
    this.setStoredData(STORAGE_KEYS.SYNC_QUEUE, []);
  }

  public static async processSyncQueue(): Promise<{ syncedCount: number; errors: number }> {
    const queue = this.getSyncQueue();
    if (queue.length === 0) return { syncedCount: 0, errors: 0 };

    // Simulate network delay and synchronization progression
    await new Promise((resolve) => setTimeout(resolve, 1200));

    // Update visits in database that were pending
    const visits = this.getVisits();
    visits.forEach((v) => {
      if (v.sync_status === 'pending' || v.sync_status === 'offline') {
        v.sync_status = 'synced';
        v.synced_at = new Date().toISOString();
      }
    });
    this.setStoredData(STORAGE_KEYS.VISITS, visits);

    const count = queue.length;
    this.clearSyncQueue();

    this.addAuditLog({
      log_id: `LOG-${Date.now()}`,
      user_id: 'SYSTEM_SYNC',
      user_name: 'Central Sync Gateway',
      role: 'admin',
      action: 'SYNC_COMPLETED',
      details: `Synchronized ${count} pending community records with Central Health Server.`,
      timestamp: new Date().toISOString(),
    });

    return { syncedCount: count, errors: 0 };
  }

  // --- Audit Logs API ---
  public static getAuditLogs(): AuditLogItem[] {
    return this.getStoredData<AuditLogItem[]>(STORAGE_KEYS.AUDIT_LOG, INITIAL_AUDIT_LOGS);
  }

  public static addAuditLog(log: AuditLogItem): void {
    const logs = this.getAuditLogs();
    logs.unshift(log);
    // Keep last 150 logs
    if (logs.length > 150) logs.pop();
    this.setStoredData(STORAGE_KEYS.AUDIT_LOG, logs);
  }

  // --- Dynamic Dashboard Stats Calculation ---
  public static getDashboardStats(): DashboardStats {
    const patients = this.getPatients();
    const visits = this.getVisits();
    const queue = this.getSyncQueue();

    const todayStr = new Date().toISOString().split('T')[0];
    const surveysToday = visits.filter((v) => v.date === todayStr).length;

    const requiresReviewCount = patients.filter((p) => p.current_status === 'requires_review').length;
    const trendAttentionCount = patients.filter((p) => p.current_status === 'trend_attention').length;
    const withinRangeCount = patients.filter((p) => p.current_status === 'within_range').length;

    const uniqueSurveyors = new Set(visits.map((v) => v.worker_id)).size;

    return {
      totalPatients: patients.length,
      totalVisits: visits.length,
      surveysToday: surveysToday || 3, // fallback to active demo count
      activeSurveyors: Math.max(uniqueSurveyors, 4),
      pendingSyncCount: queue.length,
      syncedRecordsCount: visits.filter((v) => v.sync_status === 'synced').length,
      requiresReviewCount,
      trendAttentionCount,
      withinRangeCount,
    };
  }

  // Reset to default seed state
  public static resetToSeedData(): void {
    localStorage.removeItem(STORAGE_KEYS.PATIENTS);
    localStorage.removeItem(STORAGE_KEYS.VISITS);
    localStorage.removeItem(STORAGE_KEYS.CLINICAL_NOTES);
    localStorage.removeItem(STORAGE_KEYS.SYNC_QUEUE);
    localStorage.removeItem(STORAGE_KEYS.AUDIT_LOG);
    localStorage.removeItem(STORAGE_KEYS.OFFLINE_MODE);
  }

  public static resetDemoData(): void {
    this.resetToSeedData();
  }
}
