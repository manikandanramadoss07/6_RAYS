import { Visit, DoctorRiskAssessment, RiskTrendIndicator, RiskFactorBreakdown } from '../types';

export function calculateDoctorRiskScore(visits: Visit[]): DoctorRiskAssessment {
  if (!visits || visits.length === 0) {
    return {
      score: 0,
      status: 'Within Configured Range',
      trend_indicators: [],
      contributing_factors: ['No visit records available for assessment.'],
      rule_breakdown: [],
      calculated_at: new Date().toISOString(),
      is_longitudinal: false,
      consecutive_abnormal_count: 0,
    };
  }

  // Sort chronologically ascending (oldest to newest)
  const sortedVisits = [...visits].sort((a, b) => {
    const timeA = new Date(`${a.date}T${a.time || '00:00'}`).getTime();
    const timeB = new Date(`${b.date}T${b.time || '00:00'}`).getTime();
    return timeA - timeB;
  });

  const latestVisit = sortedVisits[sortedVisits.length - 1];
  const previousVisit = sortedVisits.length > 1 ? sortedVisits[sortedVisits.length - 2] : null;
  const isLongitudinal = sortedVisits.length > 1;

  let rawPoints = 0;
  const ruleBreakdown: RiskFactorBreakdown[] = [];
  const trendIndicators: RiskTrendIndicator[] = [];
  const contributingFactors: string[] = [];

  const mLatest = latestVisit.measurements;
  const mPrev = previousVisit ? previousVisit.measurements : null;

  // 1. SpO2 Assessment
  if (mLatest.spo2) {
    if (mLatest.spo2 < 90) {
      rawPoints += 35;
      ruleBreakdown.push({
        factor: 'Severe Hypoxemia Alert',
        points: 35,
        reason: `Latest SpO₂ is critically low at ${mLatest.spo2}% (< 90% threshold)`,
      });
      contributingFactors.push(`Critical SpO₂ of ${mLatest.spo2}%`);
    } else if (mLatest.spo2 <= 93) {
      rawPoints += 22;
      ruleBreakdown.push({
        factor: 'Sub-optimal Oxygen Saturation',
        points: 22,
        reason: `Latest SpO₂ is low at ${mLatest.spo2}% (90-93% reference zone)`,
      });
      contributingFactors.push(`Sub-optimal SpO₂ of ${mLatest.spo2}%`);
    }

    // Longitudinal SpO2 Trajectory
    if (mPrev && mPrev.spo2) {
      const spo2Delta = mLatest.spo2 - mPrev.spo2;
      if (spo2Delta <= -3) {
        rawPoints += 15;
        trendIndicators.push({
          parameter: 'SpO₂',
          direction: 'down',
          note: `Oxygen saturation dropped from ${mPrev.spo2}% to ${mLatest.spo2}% (Δ ${spo2Delta}%)`,
          severity: 'high',
        });
        ruleBreakdown.push({
          factor: 'Downward SpO₂ Trajectory',
          points: 15,
          reason: `Progressive oxygen desaturation across visits (${mPrev.spo2}% → ${mLatest.spo2}%)`,
        });
        contributingFactors.push(`Downward SpO₂ trajectory (Δ ${spo2Delta}%)`);
      } else if (spo2Delta >= 3) {
        trendIndicators.push({
          parameter: 'SpO₂',
          direction: 'up',
          note: `Oxygen saturation improved from ${mPrev.spo2}% to ${mLatest.spo2}%`,
          severity: 'low',
        });
      } else {
        trendIndicators.push({
          parameter: 'SpO₂',
          direction: 'stable',
          note: `Oxygen saturation stable at ${mLatest.spo2}%`,
          severity: 'low',
        });
      }
    }
  }

  // 2. Blood Pressure Assessment
  if (mLatest.bp_systolic && mLatest.bp_diastolic) {
    const sys = mLatest.bp_systolic;
    const dia = mLatest.bp_diastolic;

    if (sys >= 160 || dia >= 100) {
      rawPoints += 30;
      ruleBreakdown.push({
        factor: 'Stage 2 Hypertension Range',
        points: 30,
        reason: `Latest BP ${sys}/${dia} mmHg meets Stage 2 threshold (≥160 or ≥100 mmHg)`,
      });
      contributingFactors.push(`Elevated Blood Pressure (${sys}/${dia} mmHg)`);
    } else if (sys >= 140 || dia >= 90) {
      rawPoints += 18;
      ruleBreakdown.push({
        factor: 'Stage 1 Hypertension Range',
        points: 18,
        reason: `Latest BP ${sys}/${dia} mmHg is elevated (≥140/90 mmHg)`,
      });
      contributingFactors.push(`Stage 1 Elevated BP (${sys}/${dia} mmHg)`);
    } else if (sys >= 130 || dia >= 85) {
      rawPoints += 8;
      ruleBreakdown.push({
        factor: 'Pre-hypertension Trend',
        points: 8,
        reason: `Latest BP ${sys}/${dia} mmHg is borderline pre-hypertensive`,
      });
    }

    // Longitudinal BP Trajectory
    if (mPrev && mPrev.bp_systolic && mPrev.bp_diastolic) {
      const sysDelta = sys - mPrev.bp_systolic;
      const diaDelta = dia - mPrev.bp_diastolic;

      if (sysDelta >= 15 || diaDelta >= 10) {
        rawPoints += 14;
        trendIndicators.push({
          parameter: 'Blood Pressure',
          direction: 'up',
          note: `Blood pressure escalated from ${mPrev.bp_systolic}/${mPrev.bp_diastolic} to ${sys}/${dia} mmHg`,
          severity: 'high',
        });
        ruleBreakdown.push({
          factor: 'Ascending Blood Pressure Trend',
          points: 14,
          reason: `Systolic increase +${sysDelta} mmHg / Diastolic increase +${diaDelta} mmHg`,
        });
        contributingFactors.push(`Ascending Blood Pressure trend (+${sysDelta}/+${diaDelta} mmHg)`);
      } else if (sysDelta <= -15 && diaDelta <= -10) {
        trendIndicators.push({
          parameter: 'Blood Pressure',
          direction: 'down',
          note: `Blood pressure normalized from ${mPrev.bp_systolic}/${mPrev.bp_diastolic} to ${sys}/${dia} mmHg`,
          severity: 'low',
        });
      } else {
        trendIndicators.push({
          parameter: 'Blood Pressure',
          direction: 'stable',
          note: `Blood pressure consistent (${sys}/${dia} mmHg)`,
          severity: 'low',
        });
      }
    }
  }

  // 3. Heart Rate Assessment
  if (mLatest.heart_rate) {
    const hr = mLatest.heart_rate;
    if (hr > 110) {
      rawPoints += 20;
      ruleBreakdown.push({
        factor: 'Marked Tachycardia',
        points: 20,
        reason: `Resting heart rate ${hr} bpm is high (>110 bpm)`,
      });
      contributingFactors.push(`Elevated Heart Rate (${hr} bpm)`);
    } else if (hr > 95) {
      rawPoints += 10;
      ruleBreakdown.push({
        factor: 'Mild Tachycardia / Elevated Pulse',
        points: 10,
        reason: `Heart rate ${hr} bpm is above standard 60-90 baseline`,
      });
    } else if (hr < 50) {
      rawPoints += 18;
      ruleBreakdown.push({
        factor: 'Bradycardia Range',
        points: 18,
        reason: `Heart rate ${hr} bpm is low (<50 bpm)`,
      });
      contributingFactors.push(`Bradycardia (${hr} bpm)`);
    }

    // Longitudinal HR Trajectory
    if (mPrev && mPrev.heart_rate) {
      const hrDelta = hr - mPrev.heart_rate;
      if (hrDelta >= 15) {
        rawPoints += 12;
        trendIndicators.push({
          parameter: 'Heart Rate',
          direction: 'up',
          note: `Heart rate escalated from ${mPrev.heart_rate} to ${hr} bpm (+${hrDelta} bpm)`,
          severity: 'moderate',
        });
        ruleBreakdown.push({
          factor: 'Escalating Pulse Rate',
          points: 12,
          reason: `Pulse rate rose by ${hrDelta} bpm since previous visit`,
        });
        contributingFactors.push(`Escalating pulse (+${hrDelta} bpm)`);
      } else if (hrDelta <= -15) {
        trendIndicators.push({
          parameter: 'Heart Rate',
          direction: 'down',
          note: `Heart rate declined from ${mPrev.heart_rate} to ${hr} bpm`,
          severity: 'low',
        });
      }
    }
  }

  // 4. Temperature Assessment
  if (mLatest.temperature) {
    const temp = mLatest.temperature;
    if (temp >= 101.5) {
      rawPoints += 20;
      ruleBreakdown.push({
        factor: 'Significant Febrile Episode',
        points: 20,
        reason: `Body temperature is ${temp}°F (≥101.5°F fever threshold)`,
      });
      contributingFactors.push(`Fever of ${temp}°F`);
    } else if (temp >= 99.8) {
      rawPoints += 10;
      ruleBreakdown.push({
        factor: 'Low-grade Fever',
        points: 10,
        reason: `Body temperature ${temp}°F is above normal range`,
      });
      contributingFactors.push(`Mild temperature elevation (${temp}°F)`);
    }
  }

  // 5. Respiratory Rate Assessment
  if (mLatest.respiratory_rate) {
    const rr = mLatest.respiratory_rate;
    if (rr >= 24) {
      rawPoints += 20;
      ruleBreakdown.push({
        factor: 'Tachypnea (Elevated Breathing Rate)',
        points: 20,
        reason: `Respiratory rate is ${rr} breaths/min (≥24 threshold)`,
      });
      contributingFactors.push(`Tachypnea (${rr} bpm)`);
    } else if (rr <= 10) {
      rawPoints += 18;
      ruleBreakdown.push({
        factor: 'Bradypnea (Depressed Breathing Rate)',
        points: 18,
        reason: `Respiratory rate is ${rr} breaths/min (≤10 threshold)`,
      });
      contributingFactors.push(`Depressed respiratory rate (${rr} bpm)`);
    }
  }

  // 6. Blood Glucose Assessment
  if (mLatest.blood_glucose) {
    const bg = mLatest.blood_glucose;
    if (bg >= 250) {
      rawPoints += 25;
      ruleBreakdown.push({
        factor: 'Marked Hyperglycemia',
        points: 25,
        reason: `Blood glucose is ${bg} mg/dL (≥250 mg/dL)`,
      });
      contributingFactors.push(`High Blood Glucose (${bg} mg/dL)`);
    } else if (bg >= 180) {
      rawPoints += 14;
      ruleBreakdown.push({
        factor: 'Elevated Blood Glucose',
        points: 14,
        reason: `Blood glucose is ${bg} mg/dL (180-249 mg/dL)`,
      });
      contributingFactors.push(`Elevated Glucose (${bg} mg/dL)`);
    } else if (bg < 70) {
      rawPoints += 20;
      ruleBreakdown.push({
        factor: 'Hypoglycemia Alert',
        points: 20,
        reason: `Blood glucose is ${bg} mg/dL (<70 mg/dL)`,
      });
      contributingFactors.push(`Low Blood Glucose (${bg} mg/dL)`);
    }
  }

  // 7. Hemoglobin Assessment
  if (mLatest.hemoglobin) {
    const hb = mLatest.hemoglobin;
    if (hb < 8.0) {
      rawPoints += 25;
      ruleBreakdown.push({
        factor: 'Severe Anemia Threshold',
        points: 25,
        reason: `Hemoglobin is critically low at ${hb} g/dL (<8.0 g/dL)`,
      });
      contributingFactors.push(`Severe Anemia (${hb} g/dL)`);
    } else if (hb < 10.5) {
      rawPoints += 14;
      ruleBreakdown.push({
        factor: 'Moderate Anemia Range',
        points: 14,
        reason: `Hemoglobin is ${hb} g/dL (10.5-8.0 g/dL)`,
      });
      contributingFactors.push(`Moderate Anemia (${hb} g/dL)`);
    }
  }

  // 8. Consecutive Abnormal Multi-Visit Penalty
  let consecutiveAbnormals = 0;
  sortedVisits.forEach((v) => {
    const m = v.measurements;
    const isAbnormal =
      (m.spo2 && m.spo2 <= 93) ||
      (m.bp_systolic && m.bp_systolic >= 140) ||
      (m.bp_diastolic && m.bp_diastolic >= 90) ||
      (m.heart_rate && (m.heart_rate > 95 || m.heart_rate < 55)) ||
      (m.temperature && m.temperature >= 100.0) ||
      (m.blood_glucose && m.blood_glucose >= 180) ||
      (m.hemoglobin && m.hemoglobin < 10.5);

    if (isAbnormal) {
      consecutiveAbnormals++;
    } else {
      consecutiveAbnormals = 0;
    }
  });

  if (consecutiveAbnormals >= 2) {
    const penalty = Math.min(consecutiveAbnormals * 8, 20);
    rawPoints += penalty;
    ruleBreakdown.push({
      factor: 'Repeated Longitudinal Abnormalities',
      points: penalty,
      reason: `${consecutiveAbnormals} consecutive field visits show measurements outside standard reference parameters`,
    });
    contributingFactors.push(`Repeated measurements outside reference parameters (${consecutiveAbnormals} consecutive visits)`);
  }

  // Bound score between 0 and 100
  const finalScore = Math.min(Math.max(rawPoints, 0), 100);

  let status: 'Within Configured Range' | 'Trend Requires Attention' | 'Requires Clinical Review' = 'Within Configured Range';
  if (finalScore >= 65) {
    status = 'Requires Clinical Review';
  } else if (finalScore >= 40) {
    status = 'Trend Requires Attention';
  }

  if (contributingFactors.length === 0) {
    contributingFactors.push('All measured vital parameters reside within standard community health reference ranges.');
  }

  return {
    score: finalScore,
    status,
    trend_indicators: trendIndicators,
    contributing_factors: contributingFactors,
    rule_breakdown: ruleBreakdown,
    calculated_at: new Date().toISOString(),
    is_longitudinal: isLongitudinal,
    consecutive_abnormal_count: consecutiveAbnormals,
  };
}
