import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { LanguageProvider } from './i18n/LanguageContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { LoginPage } from './components/auth/LoginPage';
import { DoctorDashboard } from './components/doctor/DoctorDashboard';
import { SurveyorDashboard } from './components/surveyor/SurveyorDashboard';
import { PatientDashboard } from './components/patient/PatientDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { SihDemoGuideModal } from './components/common/SihDemoGuideModal';

const AppContent: React.FC = () => {
  const { isAuthenticated, role } = useAuth();
  const [isSihGuideOpen, setIsSihGuideOpen] = useState<boolean>(false);
  const [doctorSelectedPatientId, setDoctorSelectedPatientId] = useState<string | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-slate-100/60 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-200">
      {!isAuthenticated ? (
        <LoginPage onOpenSihDemoGuide={() => setIsSihGuideOpen(true)} />
      ) : (
        <>
          <Header onOpenSihDemoGuide={() => setIsSihGuideOpen(true)} />

          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
            {role === 'doctor' && (
              <DoctorDashboard
                selectedPatientId={doctorSelectedPatientId}
                onClearSelectedPatient={() => setDoctorSelectedPatientId(null)}
              />
            )}
            {role === 'surveyor' && <SurveyorDashboard />}
            {role === 'patient' && <PatientDashboard />}
            {role === 'admin' && <AdminDashboard />}
          </main>

          <Footer />
        </>
      )}

      {/* SIH 29-Step Interactive Live Walkthrough Modal */}
      <SihDemoGuideModal
        isOpen={isSihGuideOpen}
        onClose={() => setIsSihGuideOpen(false)}
        onSelectPatientForDoctor={(patientId) => {
          setDoctorSelectedPatientId(patientId);
        }}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
