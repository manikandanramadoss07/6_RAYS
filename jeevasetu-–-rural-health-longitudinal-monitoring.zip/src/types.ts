export type UserRole = 'doctor' | 'surveyor' | 'patient' | 'admin';

export type LanguageCode =
  | 'en' // English
  | 'ta' // Tamil (தமிழ்)
  | 'hi' // Hindi (हिन्दी)
  | 'ml' // Malayalam (മലയാളം)
  | 'te' // Telugu (తెలుగు)
  | 'ur' // Urdu (اردو)
  | 'mr' // Marathi (मराठी)
  | 'pa' // Punjabi (ਪੰਜਾਬੀ)
  | 'gu' // Gujarati (ગુજરાતી)
  | 'kn'; // Kannada (ಕನ್ನಡ)

export interface User {
  id: string;
  name: string;
  username?: string;
  role: UserRole;
  email?: string;
  phone?: string;
  facility?: string;
  specialization?: string;
  assignedVillage?: string;
  avatarUrl?: string;
}

export type ReviewStatus = 'within_range' | 'trend_attention' | 'requires_review';

export interface BiomedicalMeasurement {
  measurement_id: string;
  visit_id: string;
  patient_id: string;
  parameter: 'bp_systolic' | 'bp_diastolic' | 'spo2' | 'heart_rate' | 'temperature' | 'respiratory_rate' | 'blood_glucose' | 'hemoglobin';
  value: number;
  unit: string;
  recorded_at: string;
  source: 'manual' | 'bluetooth_device' | 'usb_device';
  sync_status: 'synced' | 'pending' | 'offline';
}

export interface VisitMeasurements {
  bp_systolic: number;
  bp_diastolic: number;
  spo2: number;
  heart_rate: number;
  temperature: number; // °F
  respiratory_rate: number;
  blood_glucose?: number; // mg/dL
  hemoglobin?: number; // g/dL
  measurement_source?: 'manual' | 'bluetooth_device' | 'usb_device';
}

export interface Visit {
  visit_id: string;
  patient_id: string;
  worker_id: string;
  worker_name: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  location: string;
  sync_status: 'synced' | 'pending' | 'offline';
  notes?: string;
  measurements: VisitMeasurements;
  measurement_source?: 'manual' | 'bluetooth_device' | 'usb_device';
  created_at?: string;
  synced_at?: string;
}

export interface ClinicalNote {
  note_id: string;
  patient_id: string;
  doctor_id: string;
  doctor_name: string;
  note: string;
  visibility: 'doctor_only' | 'patient_visible';
  follow_up_date?: string;
  followUpDate?: string;
  review_status: ReviewStatus;
  prescription_advice?: string;
  created_at: string;
  updated_at?: string;
}

export interface RiskTrendIndicator {
  parameter: string;
  direction: 'up' | 'down' | 'unstable' | 'stable';
  note: string;
  severity: 'low' | 'moderate' | 'high';
}

export interface RiskFactorBreakdown {
  factor: string;
  points: number;
  reason: string;
}

export interface DoctorRiskAssessment {
  score: number; // 0 - 100
  status: 'Within Configured Range' | 'Trend Requires Attention' | 'Requires Clinical Review';
  trend_indicators: RiskTrendIndicator[];
  contributing_factors: string[];
  rule_breakdown: RiskFactorBreakdown[];
  calculated_at: string;
  is_longitudinal: boolean;
  consecutive_abnormal_count: number;
}

export interface Patient {
  patient_id: string; // e.g. PAT-2026-001
  name: string;
  age: number;
  sex: 'Male' | 'Female' | 'Other';
  dob?: string;
  mobile: string;
  village: string;
  district: string;
  state: string;
  address: string;
  emergency_contact?: string;
  emergencyContact?: string;
  registration_date?: string;
  registrationDate?: string;
  assigned_worker_id: string;
  assigned_worker_name: string;
  medical_history?: string[];
  current_status: ReviewStatus;
  last_visit_date?: string;
  is_offline_created?: boolean;
}

export interface SyncQueueItem {
  local_record_id: string;
  record_type: 'patient' | 'visit' | 'clinical_note';
  patient_id: string;
  payload: any;
  created_at: string;
  sync_status: 'pending' | 'syncing' | 'synced' | 'failed';
  error_message?: string;
  retry_count: number;
}

export interface AuditLogItem {
  log_id: string;
  user_id?: string;
  user_name?: string;
  role?: UserRole;
  actor_name?: string;
  actor_role?: UserRole | string;
  action: string;
  patient_id?: string;
  patient_name?: string;
  details: string;
  timestamp: string;
}

export interface DashboardStats {
  totalPatients: number;
  totalVisits: number;
  surveysToday: number;
  activeSurveyors: number;
  pendingSyncCount: number;
  syncPendingCount?: number;
  syncedRecordsCount: number;
  requiresReviewCount: number;
  trendAttentionCount: number;
  withinRangeCount: number;
}
